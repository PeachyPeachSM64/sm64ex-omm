E_MODEL_LLL_SECRET = smlua_model_util_get_id("lll_secret_geo")
