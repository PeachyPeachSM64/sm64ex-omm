-- name: Lug's Delightful Dioramas
-- description: ROM hack made by Lugmillord in November 2020.\nPorted to PC by jesusyoshi54.\nPorted to Coop by PeachyPeach.\n\nLug's Delightful Dioramas features 7 main levels, 7 special levels and 74 stars.\n\nThe Coop port comes with a Story mode (enabled by default) that makes all players in a current main course advance to the next act after collecting the current act star.
-- incompatible: romhack

------------------
-- level values --
------------------

gLevelValues.entryLevel = LEVEL_CASTLE
gLevelValues.exitCastleLevel = LEVEL_CASTLE
gLevelValues.exitCastleArea = 1
gLevelValues.exitCastleWarpNode = 0x0A
gLevelValues.skipCreditsAt = LEVEL_BOB
gLevelValues.coinsRequiredForCoinStar = 74

------------------
-- trajectories --
------------------

gBehaviorValues.trajectories.KoopaBobTrajectory = get_trajectory("KoopaBoB_path")
gBehaviorValues.trajectories.KoopaThiTrajectory = get_trajectory("KoopaTHI_path")
gBehaviorValues.trajectories.PlatformRrTrajectory = get_trajectory("rr_seg7_trajectory_0702EC3C_RM2C_path")
gBehaviorValues.trajectories.PlatformRr2Trajectory = get_trajectory("rr_seg7_trajectory_0702ECC0_RM2C_path")
gBehaviorValues.trajectories.PlatformRr3Trajectory = get_trajectory("rr_seg7_trajectory_0702ED9C_RM2C_path")
gBehaviorValues.trajectories.PlatformRr4Trajectory = get_trajectory("rr_seg7_trajectory_0702EEE0_RM2C_path")
gBehaviorValues.trajectories.PlatformCcmTrajectory = get_trajectory("ccm_seg7_trajectory_0701669C_RM2C_path")
gBehaviorValues.trajectories.PlatformBitfsTrajectory = get_trajectory("bitfs_seg7_trajectory_070159AC_RM2C_path")
gBehaviorValues.trajectories.PlatformHmcTrajectory = get_trajectory("hmc_seg7_trajectory_0702B86C_RM2C_path")
gBehaviorValues.trajectories.PlatformLllTrajectory = get_trajectory("lll_seg7_trajectory_0702856C_RM2C_path")
gBehaviorValues.trajectories.PlatformLll2Trajectory = get_trajectory("lll_seg7_trajectory_07028660_RM2C_path")
gBehaviorValues.trajectories.RacingPenguinTrajectory = get_trajectory("ccm_seg7_trajectory_penguin_race_RM2C_path")

-------------
-- movtexs --
-------------

movtexqc_register("bbh_1_Movtex_0", LEVEL_BBH, 1, 0)
movtexqc_register("bbh_1_Movtex_1", LEVEL_BBH, 1, 1)
movtexqc_register("bbh_1_Movtex_2", LEVEL_BBH, 1, 2)
movtexqc_register("ccm_1_Movtex_0", LEVEL_CCM, 1, 0)
movtexqc_register("ccm_1_Movtex_1", LEVEL_CCM, 1, 1)
movtexqc_register("ccm_1_Movtex_2", LEVEL_CCM, 1, 2)
movtexqc_register("castle_inside_1_Movtex_0", LEVEL_CASTLE, 1, 0)
movtexqc_register("castle_inside_1_Movtex_1", LEVEL_CASTLE, 1, 1)
movtexqc_register("castle_inside_1_Movtex_2", LEVEL_CASTLE, 1, 2)
movtexqc_register("castle_inside_2_Movtex_0", LEVEL_CASTLE, 2, 0)
movtexqc_register("castle_inside_2_Movtex_1", LEVEL_CASTLE, 2, 1)
movtexqc_register("castle_inside_2_Movtex_2", LEVEL_CASTLE, 2, 2)
movtexqc_register("hmc_1_Movtex_0", LEVEL_HMC, 1, 0)
movtexqc_register("hmc_1_Movtex_1", LEVEL_HMC, 1, 1)
movtexqc_register("hmc_1_Movtex_2", LEVEL_HMC, 1, 2)
movtexqc_register("bob_1_Movtex_0", LEVEL_BOB, 1, 0)
movtexqc_register("bob_1_Movtex_1", LEVEL_BOB, 1, 1)
movtexqc_register("bob_1_Movtex_2", LEVEL_BOB, 1, 2)
movtexqc_register("jrb_1_Movtex_0", LEVEL_JRB, 1, 0)
movtexqc_register("jrb_1_Movtex_1", LEVEL_JRB, 1, 1)
movtexqc_register("jrb_1_Movtex_2", LEVEL_JRB, 1, 2)
movtexqc_register("bitdw_1_Movtex_0", LEVEL_BITDW, 1, 0)
movtexqc_register("bitdw_1_Movtex_1", LEVEL_BITDW, 1, 1)
movtexqc_register("bitdw_1_Movtex_2", LEVEL_BITDW, 1, 2)
movtexqc_register("vcutm_1_Movtex_0", LEVEL_VCUTM, 1, 0)
movtexqc_register("vcutm_1_Movtex_1", LEVEL_VCUTM, 1, 1)
movtexqc_register("vcutm_1_Movtex_2", LEVEL_VCUTM, 1, 2)
movtexqc_register("bitfs_1_Movtex_0", LEVEL_BITFS, 1, 0)
movtexqc_register("bitfs_1_Movtex_1", LEVEL_BITFS, 1, 1)
movtexqc_register("bitfs_1_Movtex_2", LEVEL_BITFS, 1, 2)
movtexqc_register("sa_1_Movtex_0", LEVEL_SA, 1, 0)
movtexqc_register("sa_1_Movtex_1", LEVEL_SA, 1, 1)
movtexqc_register("sa_1_Movtex_2", LEVEL_SA, 1, 2)
movtexqc_register("bits_1_Movtex_0", LEVEL_BITS, 1, 0)
movtexqc_register("bits_1_Movtex_1", LEVEL_BITS, 1, 1)
movtexqc_register("bits_1_Movtex_2", LEVEL_BITS, 1, 2)
movtexqc_register("lll_1_Movtex_0", LEVEL_LLL, 1, 0)
movtexqc_register("lll_1_Movtex_1", LEVEL_LLL, 1, 1)
movtexqc_register("lll_1_Movtex_2", LEVEL_LLL, 1, 2)
movtexqc_register("wf_1_Movtex_0", LEVEL_WF, 1, 0)
movtexqc_register("wf_1_Movtex_1", LEVEL_WF, 1, 1)
movtexqc_register("wf_1_Movtex_2", LEVEL_WF, 1, 2)
movtexqc_register("castle_courtyard_1_Movtex_0", LEVEL_CASTLE_COURTYARD, 1, 0)
movtexqc_register("castle_courtyard_1_Movtex_1", LEVEL_CASTLE_COURTYARD, 1, 1)
movtexqc_register("castle_courtyard_1_Movtex_2", LEVEL_CASTLE_COURTYARD, 1, 2)
movtexqc_register("pss_1_Movtex_0", LEVEL_PSS, 1, 0)
movtexqc_register("pss_1_Movtex_1", LEVEL_PSS, 1, 1)
movtexqc_register("pss_1_Movtex_2", LEVEL_PSS, 1, 2)
movtexqc_register("cotmc_1_Movtex_0", LEVEL_COTMC, 1, 0)
movtexqc_register("cotmc_1_Movtex_1", LEVEL_COTMC, 1, 1)
movtexqc_register("cotmc_1_Movtex_2", LEVEL_COTMC, 1, 2)
movtexqc_register("totwc_1_Movtex_0", LEVEL_TOTWC, 1, 0)
movtexqc_register("totwc_1_Movtex_1", LEVEL_TOTWC, 1, 1)
movtexqc_register("totwc_1_Movtex_2", LEVEL_TOTWC, 1, 2)
movtexqc_register("wmotr_1_Movtex_0", LEVEL_WMOTR, 1, 0)
movtexqc_register("wmotr_1_Movtex_1", LEVEL_WMOTR, 1, 1)
movtexqc_register("wmotr_1_Movtex_2", LEVEL_WMOTR, 1, 2)

-----------
-- music --
-----------

smlua_audio_utils_replace_sequence(0x02, 0x25, 75, "02_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x03, 0x25, 75, "03_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x04, 0x13, 75, "04_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x05, 0x25, 75, "05_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x06, 0x11, 80, "06_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x07, 0x1A, 55, "07_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x08, 0x25, 70, "08_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x09, 0x25, 55, "09_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x0A, 0x1A, 75, "0A_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x0B, 0x11, 75, "0B_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x0C, 0x11, 70, "0C_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x0D, 0x16, 75, "0D_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x0E, 0x25, 75, "0E_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x0F, 0x18, 75, "0F_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x10, 0x12, 75, "10_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x11, 0x25, 65, "11_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x13, 0x25, 55, "13_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x14, 0x1A, 75, "14_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x16, 0x25, 75, "16_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x17, 0x0D, 70, "17_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x18, 0x19, 65, "18_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x1B, 0x14, 75, "1B_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x1D, 0x1E, 75, "1D_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x1E, 0x1B, 75, "1E_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x1F, 0x1A, 75, "1F_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x20, 0x23, 75, "20_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x21, 0x25, 75, "21_Seq_LDD_custom")
smlua_audio_utils_replace_sequence(0x22, 0x12, 60, "22_Seq_LDD_custom")

------------
-- camera --
------------

camera_set_use_course_specific_settings(false)

----------------------------------

function get_star_collection_dialog() return 0 end
hook_event(HOOK_GET_STAR_COLLECTION_DIALOG, get_star_collection_dialog)
