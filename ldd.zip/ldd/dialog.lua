smlua_text_utils_dialog_replace(DIALOG_000,1,4,30,200, "- QUANTUM QUBE -\
Fun in 6 directions!\
This area contains three\
stars for you to find.\
When you collect a star\
or die, you aren't thrown\
out of the level, but put\
back on the top.\
You also keep red coins\
and inverted stars in\
this case.\
Neat, isn't it?\
You can ignore the black\
sides of the level. They\
aren't of interest for\
now.\
Leave the level via\
『Exit Course』 in the\
pause menu or the pipe\
(if one exists).")

smlua_text_utils_dialog_replace(DIALOG_001,1,4,95,200, "1")

smlua_text_utils_dialog_replace(DIALOG_002,1,4,95,200, "2")

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, "3")

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, "4")

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, "5\
\
//Go!////Don't Go")

smlua_text_utils_dialog_replace(DIALOG_006,1,6,30,200, "6")

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, "7")

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, "Warning! Swimming in\
this icy water is only\
recommended for crazy\
people and Icelanders.\
Like, seriously, these\
Viking people can walk\
through the snow topless\
without feeling cold.")

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, "9\
\
//Go//// Don't Go")

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, "Ah yes, the red switch.\
It doesn't just give your\
hat wings. No, it does\
more than that!\
It also super glues the\
hat to your head.\
Otherwise the hat would\
fly away on its own.\
Does that sound\
save-worthy?\
\
//Yup////Nooo")

smlua_text_utils_dialog_replace(DIALOG_011,1,3,30,200, "Ah yes, the green switch.\
So, this cap turns you\
into metal right?\
Then why does lava\
NOT hurt you? It\
makes no sense.\
In any movie, the robot\
is done for when it falls\
into stuff like that.\
Anyways... save shimasu?\
\
//hai////iie")

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, "Ah yes, the blue switch.\
You will be surprised that\
it functions completely \
differently in this hack.\
\
...just kidding. It's the\
same as usual.\
\
You can also save, if\
you want to.\
\
//Indeed////Nope")

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, "74 coins for a star?\
What an odd number!\
...no, actually it's even,\
nevermind. Wanna save?\
//Yup////Nah")

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, "One more pale star to\
add to your collection!\
Keep it in the shade to\
avoid sunburn.\
\
Save and stuff?\
\
//Heck yes//Heck no")

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, "Oh no! What happened?\
This is all wrong!\
What do we do,\
what do we do?\
Hmm, I have an idea.\
I placed coins that lead\
to the stars. Try to\
follow the trail somehow.\
We'll get through this\
together!\
Onwards to the last of\
the 74 stars!\
The pipe in front of you\
leads back to the hub\
world.")

smlua_text_utils_dialog_replace(DIALOG_016,1,4,30,200, "This is the end of the\
tourist trail. Only\
experienced climbers\
may proceed.\
Reaching the top requires\
wall jumping. Press [A]\
at the moment you\
touch the wall.\
Also consider the angle\
at which you approach\
the wall.")

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, "You dare to challenge me,\
the almighty king brick\
guy, amidst my bricky\
building arena thing?\
You fool! I shall expel you\
from this sacred place!\
Are you thoroughly\
scared yet?\
And if you try to throw\
me off the cliff, I may\
just take that star with\
me forever. So be warned!")

smlua_text_utils_dialog_replace(DIALOG_018,1,5,30,200, "Koopa shells are currently\
out of stock! Come back\
when the new order\
arrived. Hopefully that\
does not take too long.\
Well, you wouldn't have\
to wait in the first place,\
if a certain someone\
didn't crash them into\
walls all the time.\
We all know who I'm\
talking about.\
Stop it, Steven! We won't\
pay for your accidents\
anymore! Go home!\
We do NOT recommend\
to explore the quicksand\
bridge without a proper\
reptilian protection\
unit.")

smlua_text_utils_dialog_replace(DIALOG_019,1,4,30,200, "19")

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, "Dear Mario:\
Please come to the\
castle. I've baked\
a cake for you.\
Yours truly--\
Princess Toadstool")

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, "21")

smlua_text_utils_dialog_replace(DIALOG_022,1,3,95,200, "This is one sturdy door!\
You need 64 stars to\
open it.")

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, "This is one sturdy door!\
You need 64 stars to\
open it.")

smlua_text_utils_dialog_replace(DIALOG_024,1,2,95,200, "Huh, this text shouldn't\
show up. Weird.")

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, "Huh, this text shouldn't\
show up. Weird.")

smlua_text_utils_dialog_replace(DIALOG_026,1,6,95,200, "I know you are curious to\
see what is behind this\
door, but first you must\
reach the very traditional\
threshold of 8 stars.\
You are [%] short.")

smlua_text_utils_dialog_replace(DIALOG_027,1,5,95,200, "You aren't ready for this\
fiery level yet. To prove\
your worth, you need\
30 stars.\
You are missing [%].")

smlua_text_utils_dialog_replace(DIALOG_028,1,6,95,200, "The final challenge awaits\
behind this door. You\
better collect 50 stars,\
if you want to see it.\
You need to find [%]\
more Stars.")

smlua_text_utils_dialog_replace(DIALOG_029,1,2,95,200, "Huh, this text shouldn't\
show up. Weird.")

smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, "30")

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, "31")

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, "Our contestant has\
finally arrived!\
A round of applause\
for Mister Italian man\
person guy over here!\
He has come to the\
legendary, the insane, the\
SHIFTY SHOW FLOOR!\
Can he overcome all odds\
and reach the finale?\
Our first task should be\
easy for him, a simple\
King Bob-Omb fight\
among his obedient\
bomb army!\
...wait, what's that?\
Really? Oh...\
Dear viewer, it appears\
there are some technical\
difficulties. Bummer!\
Apparently our budget\
is too limited to handle\
conflicting object banks.\
Whatever that means,\
who cares!\
Instead, we'll try a\
boring Whomp boss,\
which is even easier.\
I can see the ratings\
tank already...")

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, "33")

smlua_text_utils_dialog_replace(DIALOG_034,1,4,30,200, "34")

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, "Welcome back to our\
absolutely amazing show!\
In the first round, Mister\
Italian guy dude defeated\
King 『Bob-Omb』.\
But brute force alone\
won't get him far!\
Now he must show,\
whether there's anything\
inside of his skull!\
I present to you the\
treacherous, the tricky,\
THE FRAGILE TOWER!\
The goal is right at the\
very top! So high! Wow!\
Our contestant must\
make smart decisions\
and break the right\
boxes or else he's out!\
Can he do it?\
Also, this tower will show,\
whether the player has\
set the lag reduction\
options correctly, as des-\
scribed on the hub world.\
This tower should NOT\
cause severe lag.\
If it does, please check\
your settings.")

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, "Apparently our dear 7\
viewers weren't too\
excited about our last\
challenge, but this one\
will be a blast, I'm sure!\
Mister guy dude person\
must now show that he\
is a true team player.\
The only way to reach\
the star is with help.\
We assorted our best and\
most helpful killer, err,\
I mean, throwing robots!\
I know you'll love to see\
this spectacle.\
Watch, as our contestant\
is squashed by gravity\
or thrown off the arena\
entirely. That sounds\
splendid!")

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, "37")

smlua_text_utils_dialog_replace(DIALOG_038,1,4,95,200, "Weird. Did that star\
just explode?\
But your star count\
hasn't decreased!\
I'm confused and the\
door is confused, too.\
It even forgot, it's\
supposed to stop you.")

smlua_text_utils_dialog_replace(DIALOG_039,1,5,30,200, "Only few contestants\
make it to round 4, but\
dude guy person fellow\
pulled it off, how truly\
incredible! Applause!\
And this round is special\
as there are actually\
two prizes! Incredible!\
This time it's all about\
hard cash! Moneyyyyy!\
For one, there are eight\
red coins scattered\
across the area in the\
most dangerous places!\
Scary, scary!\
In addition, there are\
12 blue coins but it\
requires ninja precision\
to get them all in time!\
No easy task!\
If he can collect coins\
worth 74 single coins,\
he'll earn the bonus\
jackpot star! Let's get\
right into the action!")

smlua_text_utils_dialog_replace(DIALOG_040,1,5,30,200, "This is what our great 3\
viewers have all waited\
for! The final round of\
SHIFTY SHOW FLOOR!\
I'm so excited!\
Nobody has pulled this\
challenge off so far.\
Will guy person Italian\
misternchap fellow dude\
be the very first?\
There is a lot of pressure\
on our contestant.\
In fact, it's a lot of\
PARKOUR PRESSURE!\
I can't believe it!\
The whole obstacle course\
is only present for a very\
limited amount of time.\
Prepare to see our\
supposed hero fail!\
He will fall and fail and\
fall and fail! And he will\
get frustrated and also\
scream! And we? We\
laught at him!\
Because that is what\
SHIFTY SHOW FLOOR\
is all about! Mocking\
people who want to get\
famous. So funny!\
Because our ratings are\
more important than\
your misery. Our two\
viewers whole-heartedly\
agree!")

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, "41")

smlua_text_utils_dialog_replace(DIALOG_042,1,4,30,200, "Welcome to the\
Levora Sphere, the\
mechanical temple of\
levitation.\
This place has been\
abandoned for a long,\
long time. Quite a sight\
to behold.\
This is for all the SM74\
fans who liked the sphere\
levels. Here's a new\
rotation for you. Enjoy.\
There are 4 red coins in\
the lower half and 4 of\
them in the upper half.\
Sounds manageable.\
And you probably already\
figured out that there\
are more than 64 stars\
in this hack.")

smlua_text_utils_dialog_replace(DIALOG_043,1,4,30,200, "This is the 『Kubus of\
levitation』. It keeps all\
those floating video game\
platforms in the air.\
That includes this very\
level. So don't mess with\
this cube or everything\
will fall down and crash.")

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, "44")

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, "45")

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, "Careful, the outer tissue\
can be a bit sticky.\
If you wall jump too\
close to it, it may hinder\
your next jump.\
Oh wait, that's true for\
all of SM64. Wall jumping\
while touching a third\
wall often refuses to work.")

smlua_text_utils_dialog_replace(DIALOG_047,1,3,95,200, "You freed me! Thank you\
so much! I have been\
imprisoned for years!\
And only because I\
accidently bombed the\
gas station.\
It wasn't my fault, I\
swear! You trust me,\
right?\
As a reward, you can use\
this cannon and recklessly\
shoot stuff. Such fun!\
I mean, be careful and\
don't do anything stupid\
that gets you jailed, ok?")

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, "48")

smlua_text_utils_dialog_replace(DIALOG_049,1,4,30,200, "NO TRESPASSING!\
Danger of imminent\
collapse of nearby\
buildings!\
If we see anyone in our\
spotlights, they will be\
removed from the area\
immediately!\
Do not hinder our\
investigations into\
paranormal activities!")

smlua_text_utils_dialog_replace(DIALOG_050,1,3,30,200, "We are all anticipating\
the start of the\
『Wings'n'Horns』 festival.\
It shouldn't take much\
longer until an angel-like\
figure shows up.\
The elegance will be\
breathtaking!")

smlua_text_utils_dialog_replace(DIALOG_051,1,4,30,200, "10 out of 10 Fly Guys\
say, that you should NOT\
jump on their heads to\
fly around the level.\
10 out of 10 Fly Guy\
haters disagree.\
Who do you trust more?\
Choose now!")

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, "52")

smlua_text_utils_dialog_replace(DIALOG_053,1,4,30,200, "Are you ready for your\
final test?\
This is the thrilling\
SPECTRAL SPECTACLE!\
8 different challenges\
await our brave player.\
All tasks have to be\
completed in one go!\
Ah yes, this is much more\
demanding than the\
same old Bowser fight\
we are so used to by now.\
Instead we will test\
whether you aquired a\
wide variety of skills.\
Let the spectacle begin!")

smlua_text_utils_dialog_replace(DIALOG_054,1,4,30,200, "Hi there, Lugmillord here!\
Thanks for checking out\
this diorama hack. I hope\
you'll like the concept.\
You can find 64 stars.\
Each main course has a\
hidden pipe that leads to\
a side level with 3 stars.\
In addition, you only need\
74 coins for the coin star.\
Because... well, 74 is a\
really cool number.\
That's all I have to say\
for now.\
Have fun!")

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, "55\
\
//Go//// Don't Go")

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, "56")

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, "My baby! Where is my\
baby?! I was just looking\
the other way for a mere\
second! Now she's gone!\
Kids are so much hard\
work, sigh. Mister pesky\
plumber guy, can you go\
look for her?\
She can't be too far away.\
This area is so tiny.\
I'm already getting\
claustrophobic.")

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, "There you are,\
Jaqueline Chantal\
Augusta Loredana!\
Why'd you run away?\
Thank you, mister Italian,\
take this white can\
opener I found.\
Celebration pizza time!")

smlua_text_utils_dialog_replace(DIALOG_059,1,3,30,200, "What are you doing with\
that ugly brat? And it\
smells like a wild animal!\
Yuck! My little girl is\
clean and beautiful, you\
dummy.")

smlua_text_utils_dialog_replace(DIALOG_060,1,12,30,200, "- Credits -\
Hack by Lugmillord.\
\
SM64 ROM Manager\
- Pilzinsel64\
Parallel Lakitu Cam\
- Aglab2\
Helpful Tips\
- BroDute\
Original Game\
- Nintendo\
\
Music\
- cpuHacka101\
- CGTB Productions\
- Marios Hub - Sanji02\
- TheGael95 - pieordie1\
- ShrooboidBrat\
- Miles Gaming\
- MrGreenThunder\
- EDARK900\
- mosky2000\
- Pablo's Corner\
\
Textures\
- MrGreenThunder\
- UED\
- cpuHacka101\
\
Additional thanks\
- FrittenFriseurLPs\
- Wiihawk\
- Everyone who is kind\
  enough to make videos\
  about this hack\
- YOU, of course!")

smlua_text_utils_dialog_replace(DIALOG_061,1,6,30,200, "-  Public Service  -\
-   Announcement  -\
-  Lag Reduction  -\
\
Relevant for everyone\
using Project 64.\
Make sure that\
Options\
> Settings...\
> Rom Settings\
> Counter Factor\
is set to 1.\
You need to restart the\
ROM afterwards to\
activate the option.\
This will get rid of most\
of the lag you can\
encounter in this hack.\
Thank you for your\
attention.")

smlua_text_utils_dialog_replace(DIALOG_062,1,2,30,200, "Take a seat and relax\
for a moment.")

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, "Automatic voice message\
detected. Playing voice\
message number one.\
Recorded yesterday,\
11:26 am.\
Hi Mario,\
if you are listening to\
this message, then I'm\
already on vacation.\
I'm so sorry!\
I wanted to text you\
earlier, but you still have\
no smart phone.\
Really, it's your own\
fault!\
I tried everything for\
like 5 minutes and I\
believe that is more than\
enough work for a\
princess like me.\
I'm at the beach with\
Rosalina and Daisy right\
now, trying out our new\
bikinis, hihi.\
You'd love to see it.\
Anyways, I guess you did\
your compulsive star\
searching, didn't you?\
I told you, we have more\
than enough right now.\
Well, I'll thank you still.\
You can put them in the\
bank if that's not too\
much to ask of you.\
Be a nice boy.\
And to prove, that I'm\
honestly super duper\
sorry, you can have the\
cake on the table for\
yourself. Go ahead.\
Take your seat and eat\
it. But don't you dare\
touch my pink armchair!\
We just cleaned it and\
you are probably dirty.\
If you need company\
to enjoy the cake, just\
start a conversation with\
this cardboard stand-up.\
That'll do.\
Well, that's all.\
I'll see you in a month\
or something.\
Bye bye.\
- smooch\
End of voice message one,\
recorded yesterday,\
11:26 am.\
No new messages\
recorded.")

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, "Hey, It's me again,\
Lugmillord!\
Congratulations for\
reaching the end of the\
hack. Did you have fun?\
You can now talk to\
Princess Peach and eat\
that delicious cake.\
Of course, that doesn't\
mean there isn't more...\
There's this suspicious\
door at the other side.\
I wonder where it leads.\
Oh, and if you still need\
more things to do:\
You can check out the\
Achievements text file\
for some additional tasks,\
some of which are really\
challenging.\
And if we don't meet\
again, I'll wish you a\
great day and thanks a\
lot for playing! I hope it\
was... delightful. ☆★☆")

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, "65")

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, "66")

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, "67")

smlua_text_utils_dialog_replace(DIALOG_068,1,4,30,200, "Psst! I heard spiral\
staircases are a great\
way to get to the top\
of frail towers safely.\
Tip 1: Press [A] and [B]\
at the same time to\
break a box directly\
above you.\
Tip 2: A double jump\
can break a box that's\
a little higher above\
you.")

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, "69")

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, "70")

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, "The inverted stars are\
spread all across the\
cube!\
Three of the five can be\
found here at the\
underside.")

smlua_text_utils_dialog_replace(DIALOG_072,1,3,30,200, "This warp plate will\
bring you back to the\
top.")

smlua_text_utils_dialog_replace(DIALOG_073,1,1,95,200, "Back to the hub world")

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, "Are you a friend of\
secrets? Do you enjoy\
the hunt for...\
easter eggs?\
I've got you covered!\
There's a Pixel-Luigi\
hidden in every area\
of the game.\
Can you find all 20?\
\
...wait, that doesn't\
add up properly, huh.\
Anyways, when it comes\
to a certain 『Qube』, only\
check the top side.")

smlua_text_utils_dialog_replace(DIALOG_075,1,4,30,200, "Ah, here's the outlier\
of the Pixel-Luigi hunt!\
Levora Sphere has\
two of them!\
One in the lower section,\
one in the upper section.\
Good luck finding them!")

smlua_text_utils_dialog_replace(DIALOG_076,1,5,30,200, "Hey, this is my secret\
social distancing spot.\
Don't come too close or\
I'll report it to the\
princess. No joke!\
\
...\
... ...\
... ... ...\
\
I see. You are one of\
THOSE guys. Sigh. Okay,\
here's the deal: I give you\
this star and you leave\
me alone. Alright?")

smlua_text_utils_dialog_replace(DIALOG_077,1,4,150,200, "Depending on which\
chapter you choose upon\
entering a course, the\
level will change a bit.\
Are you looking for\
something specific?\
Make sure to select the\
correct mission.")

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, "78")

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, "79\
\
//Free him/ Hold on")

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, "80")

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, "81")

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, "Help me! That bully down\
there trapped me on\
this rooftop and acts like\
nothing happened!\
I don't know how to get\
back down! Just look at\
my short arms and legs,\
they are so useless.\
Uhm, you don't look like\
you are willing to help...\
how about a bribe? Here's\
a star. Is that enough?")

smlua_text_utils_dialog_replace(DIALOG_083,1,5,30,200, "Hey mate! Isn't it so\
thrilling to jump over\
deadly lava pits? I feel\
so alive when I'm close\
to death!\
Since you seem to agree\
with me, I'll give you this\
little prize. See it as an\
encouragement to ignore\
all safety measures.")

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, "84")

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, "85")

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, "86")

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, "87")

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, "88")

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, "89")

smlua_text_utils_dialog_replace(DIALOG_090,1,4,30,200, "90")

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, "91")

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, "92")

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, "93")

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, "94")

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, "95")

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, "96")

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, "97")

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, "98")

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, "99")

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, "100")

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, "101")

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, "102")

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, "103")

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, "104")

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, "105")

smlua_text_utils_dialog_replace(DIALOG_106,1,4,95,200, "You will follow all safety\
guidelines, right?\
I take no responsibility\
for your actions!")

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, "107")

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, "108")

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, "109")

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, "110")

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, "111")

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, "112")

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, "113")

smlua_text_utils_dialog_replace(DIALOG_114,1,4,95,200, "You dare to interrupt my\
glorious henchmen\
parade? Don't you know\
who I am?\
I am the almighty King...\
uhm, Bomb... guy.\
King Bonbon. Bomby.\
You know the name...\
I bet you can't grab me\
from behind and throw\
me three times! ...yeah,\
that sounds unlikely.")

smlua_text_utils_dialog_replace(DIALOG_115,1,4,95,200, "Hey, you didn't throw\
me! That's against the\
rules, I think. And now\
my back hurts.\
They don't pay me nearly\
enough for this crap.\
The working conditions\
are just terrible.\
No hazard pay, no sick\
leave, barely any vacation\
days. I've had enough.\
I quit!")

smlua_text_utils_dialog_replace(DIALOG_116,1,3,95,200, "Ouch! My back! How did\
you know that is my\
big weakness?\
Attacking my weak point\
for massive damage is a\
cruel strategy.\
Do you have a clue what\
my medical bill is going\
to be?! Show some mercy!")

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, "117")

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, "118")

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, "119")

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, "120")

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, "121")

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, "122")

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, "123")

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, "124")

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, "125")

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, "126")

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, "127")

smlua_text_utils_dialog_replace(DIALOG_128,1,3,95,200, "Ha! You thought I would\
not be able to jump back\
up, didn't you?\
Well, I thought that, too. \
I guess I have physics-\
denying powers. Fear me!")

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, "129")

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, "130")

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, "131")

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, "132")

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, "Hey there, red Luigi!\
Haven't seen you in a\
while. The princess was\
asking where you are.\
I think she made another\
cake.\
Oh, and don't worry\
about Bowser. He's on\
vacation right now.\
Actually, today is just a\
peaceful day without any\
problems whatsoever.\
...you look a bit surprised.\
As if there's supposed to\
be an apocalypse wherever\
you go. But no, that\
happens on Tuesdays\
only.\
Well, there is one thing\
that did occur. For some\
reason all the worlds have\
become really tiny. I think\
that's great. Now I don't\
feel like a dwarf anymore.")

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, "134")

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, "135")

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, "136")

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, "137")

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, "138")

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, "139")

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, "140")

smlua_text_utils_dialog_replace(DIALOG_141,1,6,150,200, "You found your first star!\
That is fantastic, you are\
doing such a great job!\
I bet you'll have little\
trouble getting tons of\
them! Go get 'em!")

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, "Wow, you got three stars!\
And so quickly, too! You\
must be a very skilled\
player. I'm tremendously\
impressed.")

smlua_text_utils_dialog_replace(DIALOG_143,1,5,150,200, "Holy crap, 8 stars?!?!\
Man, you are crazy good\
at this game. A real\
legend. Feel free to go\
through the star door!")

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, "Oh my God, did you\
really get 30 stars,\
you madman? It's like\
nothing will ever stop\
you! I'm getting goose-\
bumps from watching you.")

smlua_text_utils_dialog_replace(DIALOG_145,1,5,150,200, "Whaaaaaaaaaaaaaaat?!\
You collected the FIFTY\
stars needed for the final\
level? Man, you are un-\
beatable.\
Are you the best player\
on the planet or what?\
Generations will tell\
stories about your\
glorious gameplay.")

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, "My amazement knows\
no limits! 70 stars...\
Only four more stars to\
finish this hack. You\
must be the best player\
in the universe.\
If that's still not enough,\
you could still try out\
the achievements text\
file, but still, my excite-\
ment is overwhelming.\
I'm about to pass out!\
Seriously, my oxygen level\
is critically low after this\
constant hyperventilation.\
Your ultra skill may end\
up killing me but it was\
still worth it.\
Urgh...\
...\
cough...\
....................\
ooph...\
phew...\
\
\
\
\
\
ded")

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, "147")

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, "148")

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, "149")

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, "150")

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, "151")

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, "152")

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, "153")

smlua_text_utils_dialog_replace(DIALOG_154,1,6,30,200, "Y-you still aren't helping\
me? But... but I gave you\
a star! That's all I had.\
Are you in cahoots with\
that guy down there?\
Such a betrayal... D:")

smlua_text_utils_dialog_replace(DIALOG_155,1,5,30,200, "SERIOUSLY, there are so\
many empty places\
nearby! Why do you\
have to come so close?\
Away with you!")

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, "You know what would be\
really sick? Building up\
speed for 12 hours to\
reach a parallel universe.\
I wished I could do that.")

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, "157")

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, "158")

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, "159")

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, "160")

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, "161")

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, "162")

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, "163")

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, "164\
\
//Go//// Don't Go")

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, "165")

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, "166")

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, "167")

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, "168")

smlua_text_utils_dialog_replace(DIALOG_169,1,4,30,200, "169")

