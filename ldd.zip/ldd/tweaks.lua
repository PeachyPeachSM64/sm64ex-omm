gGlobalSyncTable.lddStoryMode = true
gGlobalSyncTable.lddActWarp = {}
for i = COURSE_BOB, COURSE_RR do
    gGlobalSyncTable.lddActWarp[i] = {}
    for j = 1, 5 do
        gGlobalSyncTable.lddActWarp[i][j] = 0
    end
end

sLddActWarp = {
    timer = 0,
    level = 0,
    course = 0,
    act = 0,
}

-- Lug's Delightful Dioramas main courses work as stories.
-- Each level builds itself as Mario collects stars, so enabling all stars for every act doesn't make sense.
-- The following code is a special feature: when a player collects the current act star, every player in
-- the same level "advances" to the next act, so players don't need to exit the level every time.
function mario_check_act_warp_and_advance(m)
    if m.playerIndex == 0 then
        local np = gNetworkPlayers[m.playerIndex]
        if sLddActWarp.timer > 0 then
            if sLddActWarp.level == np.currLevelNum then
                sLddActWarp.timer = sLddActWarp.timer - 1
                if sLddActWarp.timer == 30 then
                    play_transition(0x09, 30, 0, 0, 0)
                elseif sLddActWarp.timer == 0 then
                    m.health = 0x880
                    warp_to_level(sLddActWarp.level, 1, sLddActWarp.act + 1)
                    print("warping to level " .. sLddActWarp.level .. " - act " .. sLddActWarp.act + 1)
                end
            else
                sLddActWarp.timer = 0
                print("exit level: warp canceled")
            end
            if sLddActWarp.timer == 0 then
                local warpInfo = gGlobalSyncTable.lddActWarp[sLddActWarp.course][sLddActWarp.act]
                if warpInfo == np.globalIndex + 1 then
                    gGlobalSyncTable.lddActWarp[sLddActWarp.course][sLddActWarp.act] = 0
                    print("clearing warp info")
                end
            end
        else
            if np.currCourseNum >= COURSE_BOB and np.currCourseNum <= COURSE_RR and np.currActNum >= 1 and np.currActNum <= 5 then
                local warpInfo = gGlobalSyncTable.lddActWarp[np.currCourseNum][np.currActNum]
                if warpInfo ~= 0 then
                    sLddActWarp.timer = 150
                    sLddActWarp.level = np.currLevelNum
                    sLddActWarp.course = np.currCourseNum
                    sLddActWarp.act = np.currActNum
                    print("received warp info: level " .. sLddActWarp.level .. " - act " .. sLddActWarp.act + 1)
                    local i = network_local_index_from_global(warpInfo - 1)
                    djui_popup_create(network_get_player_text_color_string(i) .. gNetworkPlayers[i].name .. "\\#ffffff\\ collected the Star!\nAdvancing to the next Act...", 2)
                end
            end
        end
    end
end

function on_star_collect(m, obj, type, res)
    if gGlobalSyncTable.lddStoryMode and gServerSettings.stayInLevelAfterStar ~= 0 then
        if type == INTERACT_STAR_OR_KEY then
            local np = gNetworkPlayers[m.playerIndex]
            if np.currCourseNum >= COURSE_BOB and np.currCourseNum <= COURSE_RR then
                local starIndex = (obj.oBehParams >> 24) + 1
                if starIndex < 6 and starIndex == np.currActNum then
                    gGlobalSyncTable.lddActWarp[np.currCourseNum][np.currActNum] = np.globalIndex + 1
                end
            end
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_check_act_warp_and_advance)
hook_event(HOOK_ON_INTERACT, on_star_collect)

-- The star in "Spectral Spectacle" is supposed to warp Mario to "A Sweet Delight" after collection.
-- This obviously breaks for other players or if the star setting is set to "Stay in Level" or "Non-Stop".
-- To fix it, a warp spawns where the red star marker is as soon as the star is collected by any player,
-- so players can access "A Sweet Delight" without exiting the course and entering it again.
function mario_check_final_warp(m)
    if m.playerIndex == 0 then
        local np = gNetworkPlayers[m.playerIndex]
        if np.currLevelNum == LEVEL_BITFS and obj_get_first_with_behavior_id(id_bhvWarp) == nil then
            local redCoinManager = obj_get_first_with_behavior_id(id_bhvHiddenRedCoinStar)
            if redCoinManager.oAction == 1 and redCoinManager.oTimer > 3 then
                local redCoinStar = obj_get_first_with_behavior_id(id_bhvStarSpawnCoordinates)
                if redCoinStar == nil then
                    local warpToBits = spawn_non_sync_object(id_bhvWarp, E_MODEL_NONE, -500, find_floor_height(-500, 3000, 0), 0, nil)
                    warpToBits.oBehParams = 0x00F00000
                    warpToBits.oBehParams2ndByte = 0xF0
                    local redCoinsStarMarker = obj_get_first_with_behavior_id(id_bhvRedCoinStarMarker)
                    if redCoinsStarMarker == nil then
                        redCoinsStarMarker = spawn_non_sync_object(id_bhvRedCoinStarMarker, E_MODEL_TRANSPARENT_STAR, 0, 0, 0, nil)
                    end
                    redCoinsStarMarker.oPosX = warpToBits.oPosX
                    redCoinsStarMarker.oPosY = warpToBits.oPosY + 50
                    redCoinsStarMarker.oPosZ = warpToBits.oPosZ
                end
            end
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_check_final_warp)

-- In case some players don't want the "story mode" feature, they can disable it with the following command.
-- Only the host can change this setting.
function on_story_mode_command(msg)
    if not network_is_server() then
        djui_chat_message_create("Only the host can change this setting!")
        return true
    end
    if msg == "on" then
        djui_chat_message_create("\\#80ff80\\Story mode ON: Players now advance automatically to the next act of a main course after collecting the current act star.")
        gGlobalSyncTable.lddStoryMode = true
        return true
    elseif msg == "off" then
        djui_chat_message_create("\\#ff8080\\Story mode OFF: Players no longer advance to the next act of a main course after collecting the current act star.")
        gGlobalSyncTable.lddStoryMode = false
        return true
    end
    return false
end

hook_chat_command("ldd-story", "[on|off] Story mode: if enabled, players advance automatically to the next act of a main course after collecting the current act star.", on_story_mode_command)
