smlua_text_utils_course_acts_replace(COURSE_BOB, " 1 CHILLY PILLARS",
"CALL OF THE SUMMIT", "PENGUIN PANIC", "A REFRESHING SWIM",
"HEAVENLY BRIDGE", "8 HOT RED COINS", "PRISONER OF THE BRIDGE")

smlua_text_utils_course_acts_replace(COURSE_WF, " 2 LUMINARY TOWERS",
"REACH THE THIRD FLOOR", "OPEN SESAME", "TURTLE-LY SAFE SHELL RIDE",
"STAR HOPPER", "8 SPARKLING COINS", "JAILED!")

smlua_text_utils_course_acts_replace(COURSE_JRB, " 3 SHIFTY SHOW FLOOR",
"BOMBS AWAY!", "THE FRAGILE TOWER", "CHUCK THE MARIO!",
"COIN BONANZA", "PARKOUR PRESSURE", "THE SHOW MUST GO ON!")

smlua_text_utils_course_acts_replace(COURSE_CCM, " 4 ORGAN OASIS",
"HEARTBURN", "DIGESTIVE GASES", "ACROSS THE SLIPPERY ARTERY",
"CHEW YOUR FOOD PROPERLY!", "PALATAL ACROBATICS", "ERYTHROCYTES, THE RED BLOOD CELLS")

smlua_text_utils_course_acts_replace(COURSE_BBH, " 5 REMNANTS OF A TOWN",
"SHADOW PLAY", "WALK THE PLANK", "A DESTRUCTIVE MELODY",
"PRESERVED BELONGINGS", "SANTA IS A BIT TOO LATE", "GATHER THE REBUILDING FUNDS")

smlua_text_utils_course_acts_replace(COURSE_HMC, " 6 SCORCHING JAWS",
"A HARD PILL TO SWALLOW", "ACROSS THE SINKING DEBRIS", "IN THE PLUMBER TRAP",
"CRAZY JUMPS WITH CRAZY BOXES", "WINGS AND HORNS", "8 BURNING COINS")

smlua_text_utils_course_acts_replace(COURSE_LLL, " 7 LEVORA SPHERE",
"WELCOME BACK", "HORSESHOE RUINS", "FUNGAL INFESTATION",
"THE LONELY BATTLEMENT", "GRAB MY ARM", "COINS OF SORROW")

smlua_text_utils_secret_star_replace(COURSE_BITDW, "   QUANTUM QUBE - TILTED")
smlua_text_utils_secret_star_replace(COURSE_BITFS, "   SPECTRAL SPECTACLE")
smlua_text_utils_secret_star_replace(COURSE_BITS,  "   A SWEET DELIGHT")
smlua_text_utils_secret_star_replace(COURSE_PSS,   "   QUANTUM QUBE - YELLOW SIDE")
smlua_text_utils_secret_star_replace(COURSE_COTMC, "   QUANTUM QUBE - GREEN SIDE")
smlua_text_utils_secret_star_replace(COURSE_TOTWC, "   QUANTUM QUBE - RED SIDE")
smlua_text_utils_secret_star_replace(COURSE_VCUTM, "   QUANTUM QUBE - BLUE SIDE")
smlua_text_utils_secret_star_replace(COURSE_WMOTR, "   QUANTUM QUBE - PURPLE SIDE")
smlua_text_utils_secret_star_replace(COURSE_SA,    "   QUANTUM QUBE - ORANGE SIDE")
smlua_text_utils_secret_star_replace(COURSE_CAKE_END, "")

smlua_text_utils_castle_secret_stars_replace("   OTHER LEVELS")

smlua_text_utils_extra_text_replace(0, "A DELIGHTFUL STAR!")
smlua_text_utils_extra_text_replace(1, "")
smlua_text_utils_extra_text_replace(2, "")
smlua_text_utils_extra_text_replace(3, "")
smlua_text_utils_extra_text_replace(4, "")
smlua_text_utils_extra_text_replace(5, "")
smlua_text_utils_extra_text_replace(6, "")
