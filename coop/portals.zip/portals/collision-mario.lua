function __get_boundaries_mario(portal, pos)
    local bounds = {
        x  = pos.x,
        z  = pos.z,
        yl = pos.y,
        yh = pos.y + PORTAL_MARIO_HEIGHT,
    }
    if portal.flat == 1 then
        local dx = portal.pos.x - pos.x
        local dz = portal.pos.z - pos.z
        local dv = math.sqrt(dx * dx + dz * dz)
        bounds.x = bounds.x + PORTAL_MARIO_RADIUS * (dx / dv)
        bounds.z = bounds.z + PORTAL_MARIO_RADIUS * (dz / dv)
    else
        local sign = sign(portal.dir.x * (pos.x - portal.pos.x) + portal.dir.z * (pos.z - portal.pos.z))
        bounds.x = bounds.x - sign * PORTAL_MARIO_RADIUS * portal.dir.x
        bounds.z = bounds.z - sign * PORTAL_MARIO_RADIUS * portal.dir.z
    end
    return bounds
end

function __check_portal_plane_mario(portal, p0, p1)
    local v0 = {
        x = p0.x - portal.pos.x,
        y = p0.y - portal.pos.y,
        z = p0.z - portal.pos.z,
    }
    local v1 = {
        x = p1.x - portal.pos.x,
        y = p1.y - portal.pos.y,
        z = p1.z - portal.pos.z,
    }
    local dot0 = vec3f_dot(v0, portal.dir)
    local dot1 = vec3f_dot(v1, portal.dir)
    return (dot0 * dot1 <= 0)
end

function __get_portal_collision_mario(portal, p1, bounds0, bounds1, dy)
    local b0 = { x = bounds0.x, y = lerp(dy, bounds0.yl, bounds0.yh), z = bounds0.z }
    local b1 = { x = bounds1.x, y = lerp(dy, bounds1.yl, bounds1.yh), z = bounds1.z }
    if __check_portal_plane_mario(portal, b0, b1) then
        local b0d = vec3f_dist_to_plane(b0, portal.pos, portal.dir)
        local b1d = vec3f_dist_to_plane(b1, portal.pos, portal.dir)
        local bd = math.abs(b0d) + math.abs(b1d)
        local bp = {
            x = (b0.x * math.abs(b1d) / bd) + (b1.x * math.abs(b0d) / bd),
            y = (b0.y * math.abs(b1d) / bd) + (b1.y * math.abs(b0d) / bd),
            z = (b0.z * math.abs(b1d) / bd) + (b1.z * math.abs(b0d) / bd),
        }
        if vec3f_dist(bp, portal.pos) < PORTAL_HITBOX_RADIUS then
            return {
                index = portal.index,
                type = portal.type,
                pos = {
                    x = p1.x + (bp.x - b1.x),
                    y = p1.y + (bp.y - b1.y),
                    z = p1.z + (bp.z - b1.z),
                }
            }
        end
    end
    return nil
end

function __get_open_portals_mario(m)
    local portals = 0
    if sPortalOpenListCount ~= 0 then
        local mo = m.marioObj
        local distmax = vec3f_length(m.vel) + PORTAL_HITBOX_RADIUS + PORTAL_MARIO_HEIGHT
        for pi, _ in pairs(sPortalOpenList) do
            local portal0 = P(pi, 0)
            local portal1 = P(pi, 1)
            if dist_between_object_and_point(mo, portal0.pos.x, portal0.pos.y, portal0.pos.z) < distmax then
                portals = portals | (1 << (2 * pi + 0))
            end
            if dist_between_object_and_point(mo, portal1.pos.x, portal1.pos.y, portal1.pos.z) < distmax then
                portals = portals | (1 << (2 * pi + 1))
            end
        end
    end
    return portals
end

function __find_portal_collision_between_points_mario(portals, p0, p1)
    for b = 0, (2 * MAX_PLAYERS - 1) do
        if (portals & (1 << b)) ~= 0 then
            local pi = math.floor(b / 2)
            local pt = (b & 1)
            local portal = P(pi, pt)
            local portalO = P(pi, 1 - pt)
            if portalO.state == PORTAL_STATE_OPEN_SURFACE then
                local bounds0 = __get_boundaries_mario(portal, p0)
                local bounds1 = __get_boundaries_mario(portal, p1)
                for step = 0, 2 do
                    local col = __get_portal_collision_mario(portal, p1, bounds0, bounds1, step / 2)
                    if col ~= nil then
                        return col
                    end
                end
            end
        end
    end
    return nil
end

function find_portal_collision_mario(m)
    local portals = __get_open_portals_mario(m)
    if portals ~= 0 then

        -- Perform a fake step to check collision with portals
        local p0 = {
            x = m.pos.x,
            y = m.pos.y,
            z = m.pos.z,
        }
        local dv = {
            x = m.vel.x / 8,
            y = m.vel.y / 8,
            z = m.vel.z / 8,
        }
        for j = 1, 8 do
            local p1 = {
                x = p0.x + dv.x,
                y = p0.y + dv.y,
                z = p0.z + dv.z,
            }
            local col = __find_portal_collision_between_points_mario(portals, p0, p1)
            if col ~= nil then
                return col
            end
            p0 = p1
        end

        -- Check if the object is *literally* inside the portal
        local col = __find_portal_collision_between_points_mario(portals, {
            x = m.pos.x,
            y = m.pos.y,
            z = m.pos.z,
        }, {
            x = m.pos.x,
            y = m.pos.y + PORTAL_MARIO_HEIGHT,
            z = m.pos.z,
        })
        if col ~= nil then
            return col
        end

        -- Check if the object is crossing the portal
        col = __find_portal_collision_between_points_mario(portals, {
            x = m.pos.x - 10 * sins(m.faceAngle.y),
            y = m.pos.y,
            z = m.pos.z - 10 * coss(m.faceAngle.y),
        }, {
            x = m.pos.x + 10 * sins(m.faceAngle.y),
            y = m.pos.y,
            z = m.pos.z + 10 * coss(m.faceAngle.y),
        })
        if col ~= nil then
            return col
        end
    end
    return nil
end

function perform_portal_displacement_mario(m, col)

    -- Check if Mario hasn't teleported recently
    if sPlayerPortalCooldown == 0 then
        local portal0 = P(col.index, col.type)
        local portal1 = P(col.index, 1 - col.type)
        local surfType0 = SURF_TYPE(portal0.dir.y)
        local surfType1 = SURF_TYPE(portal1.dir.y)
        local surfType01 = SURF_TYPES_IN_OUT(surfType0, surfType1)

        -- Compute flat portals vectors
        for pt = 0, 1 do
            local portal = P(col.index, pt)
            if portal.flat == 1 then
                local xzVel = { x = m.vel.x, y = 0, z = m.vel.z }
                if vec3f_length(xzVel) < 1 then
                    portal.up.x = sins(m.faceAngle.y)
                    portal.up.y = 0
                    portal.up.z = coss(m.faceAngle.y)
                else
                    vec3f_copy(portal.up, xzVel)
                    vec3f_normalize(portal.up)
                end
                __compute_left_vector(portal)
                __compute_right_vector(portal)
                __compute_angles(portal)
            end
        end

        -- Translate position from entry to exit
        local pos2d = vec3f_to_2d_plane(col.pos, portal0.pos, portal0.up, portal0.left)
        local pos = vec2f_and_dist_to_3d(pos2d, 0, portal0.pos, portal0.dir, portal0.up, portal0.left)
        vec3f_sub(pos, portal0.pos)
        vec3f_mul(pos, math.min(vec3f_length(pos), PORTAL_HITBOX_RADIUS) / vec3f_length(pos))
        vec3f_add(pos, portal0.pos)
        pos2d = vec3f_to_2d_plane(pos, portal0.pos, portal0.up, portal0.left)
        pos = vec2f_and_dist_to_3d(pos2d, 0, portal1.pos, portal1.dir, portal1.up, if_then_else(sPortalInOutParams[surfType01].invertLR == 1, portal1.right, portal1.left))

        -- Offset translated position by applying floor, wall and ceiling logic
        pos.x = pos.x + (1.0 - math.abs(portal1.dir.y)) * PORTAL_MARIO_RADIUS * sins(portal1.angle.z)
        pos.y = pos.y - clamp(-portal1.dir.y, 0.0, 1.0) * PORTAL_MARIO_HEIGHT
        pos.z = pos.z + (1.0 - math.abs(portal1.dir.y)) * PORTAL_MARIO_RADIUS * coss(portal1.angle.z)

        -- Check out of bounds and water level before teleporting Mario
        local fy = find_floor_height(pos.x, pos.y, pos.z)
        local wl = find_water_level(pos.x, pos.z)
        if fy > -10000 and wl < pos.y + 80 then
            vec3f_copy(m.pos, pos)

            -- Compute Mario's new face yaw
            local prevFaceYaw = m.faceAngle.y
            if portal1.flat == 0 then
                if portal0.flat == 1 then
                    m.faceAngle.y = portal1.angle.z
                else
                    local diff = (math.floor(math.abs(m.faceAngle.y - portal0.angle.z)) & 0xFFFF)
                    if diff > 0x4000 then
                        m.faceAngle.y = m.faceAngle.y + 0x8000
                    end
                    m.faceAngle.y = m.faceAngle.y + (portal1.angle.z - portal0.angle.z)
                end
                if m.forwardVel < 0 then
                    m.faceAngle.y = m.faceAngle.y + 0x8000
                end
            end
            if sPlayerFirstPerson.enabled then
                sPlayerFirstPerson.yaw = sPlayerFirstPerson.yaw + m.faceAngle.y - prevFaceYaw
            end

            -- Compute Mario's new velocity
            local vel2d = vec3f_to_2d_plane(m.vel, VEC3_ZERO, portal0.up, portal0.left)
            local velDist = math.abs(vec3f_dist_to_plane(m.vel, VEC3_ZERO, portal0.dir))
            local newVel = vec2f_and_dist_to_3d(vel2d, velDist, VEC3_ZERO, portal1.dir, portal1.up, portal1.left)
            vec3f_copy(m.vel, newVel)
            mario_set_forward_vel(m, sign(m.forwardVel) * math.sqrt(m.vel.x * m.vel.x + m.vel.z * m.vel.z))

            -- Compute Mario's new heights
            m.floorHeight = find_floor_height(m.pos.x, m.pos.y, m.pos.z)
            m.ceilHeight = find_ceil_height(m.pos.x, m.pos.y, m.pos.z)
            m.waterLevel = find_water_level(m.pos.x, m.pos.z)
            if m.ceilHeight - 161 > m.floorHeight then
                m.pos.y = clamp(m.pos.y, m.floorHeight, m.ceilHeight - 161)
            else
                m.pos.y = math.max(m.pos.y, m.floorHeight)
            end
            m.peakHeight = m.pos.y
            m.quicksandDepth = 0

            -- Set Mario's action
            if sPortalInOutParams[surfType01].performAirAction == 1 and m.vel.y > 0 and (m.action & ACT_FLAG_AIR) == 0 then
                if m.riddenObj ~= nil then
                    set_mario_action(m, ACT_RIDING_SHELL_FALL, 0)
                elseif m.heldObj ~= nil then
                    set_mario_action(m, ACT_HOLD_FREEFALL, 0)
                else
                    set_mario_action(m, ACT_FREEFALL, 0)
                end
            end

            -- Activate portal teleportation
            play_sound(SOUND_ACTION_TELEPORT, m.marioObj.header.gfx.cameraToObject)
            sPlayerTeleported.pos.x = m.pos.x
            sPlayerTeleported.pos.y = m.pos.y
            sPlayerTeleported.pos.z = m.pos.z
            sPlayerTeleported.vel.x = m.vel.x
            sPlayerTeleported.vel.y = m.vel.y
            sPlayerTeleported.vel.z = m.vel.z
            sPlayerTeleported.angle.x = m.faceAngle.x
            sPlayerTeleported.angle.y = m.faceAngle.y
            sPlayerTeleported.angle.z = m.faceAngle.z
            sPlayerTeleported.t = 1
        end
    end

    -- Set cooldown
    sPlayerPortalCooldown = PORTAL_COOLDOWN
end
