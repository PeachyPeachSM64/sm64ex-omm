sPortalObjectBehaviors = {
    { bhvId = id_bhv1Up,                        checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhv1upJumpOnApproach,          checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhv1upRunningAway,             checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhv1upSliding,                 checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhv1upWalking,                 checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvBalconyBigBoo,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBigBoulder,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBigBully,                   checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBigBullyWithMinions,        checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvBigChillBully,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBigSnowmanWhole,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBlueBowserFlame,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBlueCoinJumping,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBlueCoinSliding,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBlueCoinSwitch,             checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBlueFlamesGroup,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBobomb,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBobombBuddy,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBobombBuddyOpensCannon,     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBoo,                        checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBooCage,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBooWithCage,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBouncingFireballFlame,      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBowlingBall,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBowser,                     checkVisible = true,  checkTangible = false },
    { bhvId = id_bhvBowserBomb,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBowserKey,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBreakableBox,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBreakableBoxSmall,          checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBub,                        checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBubba,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvBulletBill,                 checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvChuckya,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvCirclingAmp,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvClamShell,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvDoor,                       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvEnemyLakitu,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvExclamationBox,             checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvFallingPillar,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFirePiranhaPlant,           checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvFireSpitter,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlame,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlameBouncing,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlameBowser,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlameFloatingLanding,       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlameLargeBurningOut,       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlameMovingForwardGrowing,  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlyGuy,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFlyingBookend,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvFreeBowlingBall,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvGhostHuntBigBoo,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvGhostHuntBoo,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvGiantPole,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvGoomba,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvGrandStar,                  checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvGrindel,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvHauntedChair,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvHeaveHo,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvHidden1up,                  checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvHidden1upInPole,            checkVisible = true,  checkTangible = true  },
    { bhvId = id_bhvHiddenBlueCoin,             checkVisible = true,  checkTangible = false },
    { bhvId = id_bhvHomingAmp,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvHoot,                       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvHorizontalGrindel,          checkVisible = false, checkTangible = false },
    { bhvId = id_bhvJrbFloatingBox,             checkVisible = false, checkTangible = false },
    { bhvId = id_bhvJrbFloatingPlatform,        checkVisible = false, checkTangible = false },
    { bhvId = id_bhvJrbSlidingBox,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvJumpingBox,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvKickableBoard,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvKingBobomb,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvKlepto,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvKoopa,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvKoopaShell,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvKoopaShellUnderwater,       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMacroUkiki,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMadPiano,                   checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMantaRay,                   checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMerryGoRoundBigBoo,         checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMerryGoRoundBoo,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMessagePanel,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMetalCap,                   checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMips,                       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMoneybag,                   checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMoneybagHidden,             checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMovingBlueCoin,             checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMovingYellowCoin,           checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMrBlizzard,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvMrI,                        checkVisible = false, checkTangible = false },
    { bhvId = id_bhvNormalCap,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvOneCoin,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvPenguinBaby,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvPiranhaPlant,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvPitBowlingBall,             checkVisible = false, checkTangible = false },
    { bhvId = id_bhvPokey,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvPokeyBodyPart,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvPushableMetalBox,           checkVisible = false, checkTangible = false },
    { bhvId = id_bhvRacingPenguin,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvRecoveryHeart,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvRedCoin,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvScuttlebug,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSingleCoinGetsSpawned,      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSkeeter,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSLWalkingPenguin,           checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSmallBully,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSmallChillBully,            checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSmallPenguin,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSmallPiranhaFlame,          checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSmallWhomp,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSnowmansBottom,             checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSnufit,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSpawnedStar,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSpawnedStarNoLevelExit,     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSpindel,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSpindrift,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSpiny,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvStar,                       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvStarDoor,                   checkVisible = false, checkTangible = false },
    { bhvId = id_bhvStarSpawnCoordinates,       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSushiShark,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvSwoop,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvTemporaryYellowCoin,        checkVisible = false, checkTangible = false },
    { bhvId = id_bhvThwomp,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvThwomp2,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvToadMessage,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvToxBox,                     checkVisible = false, checkTangible = false },
    { bhvId = id_bhvTreasureChestBottom,        checkVisible = false, checkTangible = false },
    { bhvId = id_bhvTree,                       checkVisible = false, checkTangible = false },
    { bhvId = id_bhvTuxiesMother,               checkVisible = false, checkTangible = false },
    { bhvId = id_bhvUkiki,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvUnagi,                      checkVisible = false, checkTangible = false },
    { bhvId = id_bhvUnused20E0,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvVanishCap,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWaterBomb,                  checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWaterLevelDiamond,          checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWhompKingBoss,              checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWigglerBody,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWigglerHead,                checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWingCap,                    checkVisible = false, checkTangible = false },
    { bhvId = id_bhvWoodenPost,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvYellowCoin,                 checkVisible = false, checkTangible = false },
    { bhvId = id_bhvYoshi,                      checkVisible = false, checkTangible = false },
}

sPortalObjectLists = {
    OBJ_LIST_SURFACE,
    OBJ_LIST_POLELIKE,
    OBJ_LIST_LEVEL,
    OBJ_LIST_GENACTOR,
    OBJ_LIST_PUSHABLE,
    OBJ_LIST_DESTRUCTIVE,
}

sPortalObjectBehaviorLists = {}
for _, objList in pairs(sPortalObjectLists) do
    sPortalObjectBehaviorLists[objList] = {}
end
for _, objBhv in pairs(sPortalObjectBehaviors) do
    local ptrBhv = get_behavior_from_id(objBhv.bhvId)
    local objList = get_object_list_from_behavior(ptrBhv)
    sPortalObjectBehaviorLists[objList][ptrBhv._pointer] = { checkVisible = objBhv.checkVisible, checkTangible = objBhv.checkTangible }
end

function __check_object_collision(x0, y0, z0, x1, y1, z1, obj, checkVisible, checkTangible)
    if checkVisible and (obj.header.gfx.node.flags & (GRAPH_RENDER_ACTIVE | GRAPH_RENDER_INVISIBLE)) ~= GRAPH_RENDER_ACTIVE then return nil end
    if checkTangible and obj.oIntangibleTimer ~= 0 then return nil end
    local cx = obj.oPosX
    local cy = obj.oPosY - obj.hitboxDownOffset
    local cz = obj.oPosZ
    local cr = math.max(obj.hitboxRadius, obj.hurtboxRadius)
    local ch = math.max(obj.hitboxHeight, obj.hurtboxHeight)
    if check_line_cylinder_collision(x0, y0, z0, x1, y1, z1, cx, cy, cz, cr, ch) then
        return {
            hitPos = {
                x = cx,
                y = cy + ch / 2,
                z = cz,
            },
            surface = {
                normal = {
                    x = sins(obj.oFaceAngleYaw),
                    y = 0,
                    z = coss(obj.oFaceAngleYaw),
                },
            },
        }
    end
    return nil
end

function collision_find_object(x0, y0, z0, x1, y1, z1)
    for _, objList in pairs(sPortalObjectLists) do
        local obj = obj_get_first(objList)
        while obj ~= nil do
            local checks = sPortalObjectBehaviorLists[objList][obj.behavior._pointer]
            if checks ~= nil then
                local objCol = __check_object_collision(x0, y0, z0, x1, y1, z1, obj, checks.checkVisible, checks.checkTangible)
                if objCol ~= nil then
                    return objCol
                end
            end
            obj = obj_get_next(obj)
        end
    end
    return nil
end

function object_update(obj, checkVisible, checkTangible)
    if checkVisible and (obj.header.gfx.node.flags & (GRAPH_RENDER_ACTIVE | GRAPH_RENDER_INVISIBLE)) ~= GRAPH_RENDER_ACTIVE then return end
    if checkTangible and obj.oIntangibleTimer ~= 0 then return end
    obj.oUnk1A8 = math.max(0, obj.oUnk1A8 - 1)
    local col = find_portal_collision_object(obj)
    if col ~= nil then
        perform_portal_displacement_object(obj, col)
    end
end

function objects_update(m)
    if m.playerIndex == 0 then
        for _, objList in pairs(sPortalObjectLists) do
            local obj = obj_get_first(objList)
            while obj ~= nil do
                local checks = sPortalObjectBehaviorLists[objList][obj.behavior._pointer]
                if checks ~= nil then
                    object_update(obj, checks.checkVisible, checks.checkTangible)
                end
                obj = obj_get_next(obj)
            end
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, objects_update)
