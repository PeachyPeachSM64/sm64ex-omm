function before_mario_update(m)
    if gNetworkPlayers[m.playerIndex].connected then

        -- Update portal data
        for pt = 0, 1 do
            local portal = P(m.playerIndex, pt)
            portal_data_update(portal, nil)
            portal.timer = if_then_else(portal.state == PORTAL_STATE_CLOSED, 0, 1) * (portal.timer + if_then_else(portal.state == PORTAL_STATE_OPEN_SURFACE, 1, 2))
            if portal.state >= PORTAL_STATE_OPEN_OBJECT and portal.timer > 10 then portal.state = PORTAL_STATE_CLOSED end
        end

        -- Receive portal data from remote players
        if m.playerIndex ~= 0 then
            portal_data_receive(m.playerIndex)
            return
        end

-- The following code is local player only --

        -- On location change, spawn portal objects and close portals
        local location = get_location(m)
        if sPlayerLocation ~= location then
            for pi = 0, (MAX_PLAYERS - 1) do
                for pt = 0, 1 do
                    local o = spawn_non_sync_object(id_bhvPortal[pt], E_MODEL_PORTAL[pt], 0, 0, 0, nil)
                    if o == nil then return end
                    o.oBehParams2ndByte = pt
                    o.oAction = pi
                end
            end
            sPlayerLocation = location
            P(0, 0).state = PORTAL_STATE_CLOSED
            P(0, 1).state = PORTAL_STATE_CLOSED
            portal_data_send(0)
            portal_data_send(1)
            return
        end

        -- Enable surface object collision for portal shots
        if obj_get_first_with_behavior_id(id_bhvPortalShot) ~= nil then
            local obj = obj_get_first(OBJ_LIST_SURFACE)
            while obj ~= nil do
                obj.oCollisionDistance = 20000
                if (obj_has_behavior_id(obj, id_bhvLllRotatingHexagonalRing) or
                    obj_has_behavior_id(obj, id_bhvRotatingPlatform)) then
                    obj.oDistanceToMario = 0
                    obj.oFlags = obj.oFlags & ~OBJ_FLAG_COMPUTE_DIST_TO_MARIO
                end
                obj = obj_get_next(obj)
            end
        end

        -- Shoot portals, or close them
        if (m.controller.buttonPressed & L_JPAD) ~= 0 then
            spawn_portal_shot(m, 0)
        elseif (m.controller.buttonPressed & R_JPAD) ~= 0 then
            spawn_portal_shot(m, 1)
        elseif (m.controller.buttonPressed & D_JPAD) ~= 0 then
            P(0, 0).state = PORTAL_STATE_CLOSED
            P(0, 1).state = PORTAL_STATE_CLOSED
            portal_data_send(0)
            portal_data_send(1)
        elseif (m.controller.buttonPressed & U_JPAD) ~= 0 then
            if sPlayerFirstPerson.enabled then
                portal_disable_first_person()
            else
                portal_enable_first_person()
            end
        end

        -- Prevent Mario from teleporting during some specific actions
        if (m.action == ACT_BUBBLED or
            m.action == ACT_STAR_DANCE_EXIT or
            m.action == ACT_STAR_DANCE_NO_EXIT or
            m.action == ACT_STAR_DANCE_WATER or
            m.action == ACT_FALL_AFTER_STAR_GRAB or
            m.action == ACT_JUMBO_STAR_CUTSCENE or
            m.action == ACT_READING_AUTOMATIC_DIALOG or
            m.action == ACT_READING_NPC_DIALOG or
            m.action == ACT_READING_SIGN or
            m.action == ACT_WAITING_FOR_DIALOG or
            m.action == ACT_UNLOCKING_KEY_DOOR or
            m.action == ACT_UNLOCKING_STAR_DOOR or
            m.action == ACT_BBH_ENTER_JUMP or
            m.action == ACT_BBH_ENTER_SPIN or
            m.action == ACT_IN_CANNON) then
            sPlayerPortalCooldown = PORTAL_COOLDOWN
        end

        -- Check collision with portals only when Mario is above water
        sPlayerPortalCooldown = math.max(0, sPlayerPortalCooldown - 1)
        if (m.action & ACT_GROUP_MASK) ~= ACT_GROUP_SUBMERGED then

            -- If collision, try to teleport Mario
            local col = find_portal_collision_mario(m)
            if col ~= nil then
                perform_portal_displacement_mario(m, col)
            end
        end

        -- Update first person state
        djui_hud_set_mouse_locked(sPlayerFirstPerson.enabled)
        if sPlayerFirstPerson.enabled then
            portal_update_first_person(m)
        end
    end
end

function after_mario_update(m)
    if m.playerIndex == 0 then

        -- If Mario just teleported, cancel this frame's step
        if sPlayerTeleported.t == 1 then
            m.pos.x = sPlayerTeleported.pos.x
            m.pos.y = sPlayerTeleported.pos.y
            m.pos.z = sPlayerTeleported.pos.z
            m.vel.x = sPlayerTeleported.vel.x
            m.vel.y = sPlayerTeleported.vel.y
            m.vel.z = sPlayerTeleported.vel.z
            m.faceAngle.x = sPlayerTeleported.angle.x
            m.faceAngle.y = sPlayerTeleported.angle.y
            m.faceAngle.z = sPlayerTeleported.angle.z
            m.marioObj.header.gfx.pos.x = m.pos.x
            m.marioObj.header.gfx.pos.y = m.pos.y
            m.marioObj.header.gfx.pos.z = m.pos.z
            m.marioObj.header.gfx.angle.y = m.faceAngle.y
            m.marioObj.oPosX = m.pos.x
            m.marioObj.oPosY = m.pos.y
            m.marioObj.oPosZ = m.pos.z
            m.marioObj.oVelX = m.vel.x
            m.marioObj.oVelY = m.vel.y
            m.marioObj.oVelZ = m.vel.z
            m.marioObj.oFaceAnglePitch = m.marioObj.header.gfx.angle.x
            m.marioObj.oFaceAngleYaw = m.marioObj.header.gfx.angle.y
            m.marioObj.oFaceAngleRoll = m.marioObj.header.gfx.angle.z
            m.marioObj.oMoveAnglePitch = m.marioObj.header.gfx.angle.x
            m.marioObj.oMoveAngleYaw = m.marioObj.header.gfx.angle.y
            m.marioObj.oMoveAngleRoll = m.marioObj.header.gfx.angle.z
            m.marioObj.oAngleVelPitch = m.angleVel.x
            m.marioObj.oAngleVelYaw = m.angleVel.y
            m.marioObj.oAngleVelRoll = m.angleVel.z
            sPlayerTeleported.t = 0
        end

        -- If first person is enabled, hide Mario and apply a forward offset for the held object rendering
        -- Otherwise, make him transparent if the camera is too close
        if sPlayerFirstPerson.enabled then
            m.marioBodyState.modelState = 0x100
            if m.heldObj ~= nil then
                local camDir = {
                    x = m.area.camera.focus.x - m.area.camera.pos.x,
                    y = m.area.camera.focus.y - m.area.camera.pos.y,
                    z = m.area.camera.focus.z - m.area.camera.pos.z,
                }
                vec3f_normalize(camDir)
                vec3f_mul(camDir, 100)
                vec3f_sum(m.marioObj.header.gfx.pos, m.pos, camDir)
            end
        elseif vec3f_dist(m.pos, m.area.camera.pos) < 500 then
            m.marioBodyState.modelState = m.marioBodyState.modelState | MODEL_STATE_NOISE_ALPHA
        end

        -- Heal Mario after collecting a star
        if m.action == ACT_STAR_DANCE_EXIT or m.action == ACT_STAR_DANCE_NO_EXIT or m.action == ACT_STAR_DANCE_WATER then
            m.healCounter = 1
            m.hurtCounter = 0
        end
    end
end

-- Heal Mario after collecting a 1-up mushroom
function check_mushroom_heal(obj)
    local m = gMarioStates[0]
    if (obj.header.gfx.node.flags & GRAPH_RENDER_INVISIBLE) == 0 and (
        obj_has_behavior_id(obj, id_bhv1Up) == 1 or
        obj_has_behavior_id(obj, id_bhv1upJumpOnApproach) == 1 or
        obj_has_behavior_id(obj, id_bhv1upRunningAway) == 1 or
        obj_has_behavior_id(obj, id_bhv1upSliding) == 1 or
        obj_has_behavior_id(obj, id_bhv1upWalking) == 1 or
        obj_has_behavior_id(obj, id_bhvHidden1up) == 1 or
        obj_has_behavior_id(obj, id_bhvHidden1upInPole) == 1) and
        obj_check_hitbox_overlap(obj, m.marioObj) == 1 then
        m.healCounter = 31
        m.hurtCounter = 0
    end
end

sPortalReticleTex = get_texture_info("portal_reticle")

function on_hud_render()
    if sPlayerFirstPerson.enabled or gMarioStates[0].action == ACT_FIRST_PERSON then
        djui_hud_set_resolution(RESOLUTION_N64)
        local sw = djui_hud_get_screen_width()
        local sh = djui_hud_get_screen_height()
        djui_hud_set_color(255, 255, 255, 160)
        djui_hud_render_texture(sPortalReticleTex, (sw - 40) / 2, (sh - 40) / 2, 40 / 128, 40 / 128)
        djui_hud_set_color(50, 50, 50, 128)
        djui_hud_render_rect((sw - 1) / 2,     (sh - 1) / 2,     1, 1)
        djui_hud_render_rect((sw - 1) / 2 - 4, (sh - 1) / 2,     1, 1)
        djui_hud_render_rect((sw - 1) / 2 + 4, (sh - 1) / 2,     1, 1)
        djui_hud_render_rect((sw - 1) / 2,     (sh - 1) / 2 - 4, 1, 1)
        djui_hud_render_rect((sw - 1) / 2,     (sh - 1) / 2 + 4, 1, 1)
    end
end

hook_event(HOOK_BEFORE_MARIO_UPDATE, before_mario_update)
hook_event(HOOK_MARIO_UPDATE, after_mario_update)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_ON_OBJECT_UNLOAD, check_mushroom_heal)
