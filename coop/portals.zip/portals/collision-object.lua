function __get_boundaries_object(portal, pos, hbound, vbound)
    local bounds = {
        x  = pos.x,
        z  = pos.z,
        yl = pos.y,
        yh = pos.y + vbound,
    }
    if portal.flat == 1 then
        local dx = portal.pos.x - pos.x
        local dz = portal.pos.z - pos.z
        local dv = math.sqrt(dx * dx + dz * dz)
        bounds.x = bounds.x + hbound * (dx / dv)
        bounds.z = bounds.z + hbound * (dz / dv)
    else
        local sign = sign(portal.dir.x * (pos.x - portal.pos.x) + portal.dir.z * (pos.z - portal.pos.z))
        bounds.x = bounds.x - sign * hbound * portal.dir.x
        bounds.z = bounds.z - sign * hbound * portal.dir.z
    end
    return bounds
end

function __check_portal_plane_object(portal, p0, p1)
    local v0 = {
        x = p0.x - portal.pos.x,
        y = p0.y - portal.pos.y,
        z = p0.z - portal.pos.z,
    }
    local v1 = {
        x = p1.x - portal.pos.x,
        y = p1.y - portal.pos.y,
        z = p1.z - portal.pos.z,
    }
    local dot0 = vec3f_dot(v0, portal.dir)
    local dot1 = vec3f_dot(v1, portal.dir)
    return (dot0 * dot1 <= 0)
end

function __get_portal_collision_object(portal, p1, bounds0, bounds1, dy)
    local b0 = { x = bounds0.x, y = lerp(dy, bounds0.yl, bounds0.yh), z = bounds0.z }
    local b1 = { x = bounds1.x, y = lerp(dy, bounds1.yl, bounds1.yh), z = bounds1.z }
    if __check_portal_plane_object(portal, b0, b1) then
        local b0d = vec3f_dist_to_plane(b0, portal.pos, portal.dir)
        local b1d = vec3f_dist_to_plane(b1, portal.pos, portal.dir)
        local bd = math.abs(b0d) + math.abs(b1d)
        local bp = {
            x = (b0.x * math.abs(b1d) / bd) + (b1.x * math.abs(b0d) / bd),
            y = (b0.y * math.abs(b1d) / bd) + (b1.y * math.abs(b0d) / bd),
            z = (b0.z * math.abs(b1d) / bd) + (b1.z * math.abs(b0d) / bd),
        }
        if vec3f_dist(bp, portal.pos) < PORTAL_HITBOX_RADIUS then
            return {
                index = portal.index,
                type = portal.type,
                pos = {
                    x = p1.x + (bp.x - b1.x),
                    y = p1.y + (bp.y - b1.y),
                    z = p1.z + (bp.z - b1.z),
                }
            }
        end
    end
    return nil
end

function __get_open_portals_object(obj)
    local portals = 0
    if sPortalOpenListCount ~= 0 then
        local objVel = { x = obj.oVelX, y = obj.oVelY, z = obj.oVelZ }
        local distmax = vec3f_length(objVel) + PORTAL_HITBOX_RADIUS + math.max(math.max(obj.hitboxRadius, obj.hurtboxRadius), math.max(obj.hitboxHeight, obj.hurtboxHeight))
        for pi, _ in pairs(sPortalOpenList) do
            local portal0 = P(pi, 0)
            local portal1 = P(pi, 1)
            if dist_between_object_and_point(obj, portal0.pos.x, portal0.pos.y, portal0.pos.z) < distmax then
                portals = portals | (1 << (2 * pi + 0))
            end
            if dist_between_object_and_point(obj, portal1.pos.x, portal1.pos.y, portal1.pos.z) < distmax then
                portals = portals | (1 << (2 * pi + 1))
            end
        end
    end
    return portals
end

function __find_portal_collision_between_points_object(obj, portals, p0, p1)
    for b = 0, (2 * MAX_PLAYERS - 1) do
        if (portals & (1 << b)) ~= 0 then
            local pi = math.floor(b / 2)
            local pt = (b & 1)
            local portal = P(pi, pt)
            local portalO = P(pi, 1 - pt)
            if portalO.state == PORTAL_STATE_OPEN_SURFACE then
                local hbound = math.max(obj.hitboxRadius, obj.hurtboxRadius)
                local vbound = math.max(obj.hitboxHeight, obj.hurtboxHeight)
                local bounds0 = __get_boundaries_object(portal, p0, hbound, vbound)
                local bounds1 = __get_boundaries_object(portal, p1, hbound, vbound)
                local steps = 2 + math.floor(vbound / PORTAL_HITBOX_RADIUS)
                for step = 0, steps do
                    local col = __get_portal_collision_object(portal, p1, bounds0, bounds1, step / steps)
                    if col ~= nil then
                        return col
                    end
                end
            end
        end
    end
    return nil
end

function find_portal_collision_object(obj)
    local portals = __get_open_portals_object(obj)
    if portals ~= 0 then

        -- Perform a fake step to check collision with portals
        -- Kinda unecessary for objects, commenting this for now
        -- local p0 = {
        --     x = obj.oPosX,
        --     y = obj.oPosY,
        --     z = obj.oPosZ,
        -- }
        -- local dv = {
        --     x = obj.oVelX / 8,
        --     y = obj.oVelY / 8,
        --     z = obj.oVelZ / 8,
        -- }
        -- for j = 1, 8 do
        --     local p1 = {
        --         x = p0.x + dv.x,
        --         y = p0.y + dv.y,
        --         z = p0.z + dv.z,
        --     }
        --     local col = __find_portal_collision_between_points_object(obj, portals, p0, p1)
        --     if col ~= nil then
        --         return col
        --     end
        --     p0 = p1
        -- end

        -- Check if the object is *literally* inside the portal
        local col = __find_portal_collision_between_points_object(obj, portals, {
            x = obj.oPosX,
            y = obj.oPosY,
            z = obj.oPosZ,
        }, {
            x = obj.oPosX,
            y = obj.oPosY + math.max(obj.hitboxHeight, obj.hurtboxHeight),
            z = obj.oPosZ,
        })
        if col ~= nil then
            return col
        end

        -- Check if the object is crossing the portal
        col = __find_portal_collision_between_points_object(obj, portals, {
            x = obj.oPosX - 10 * sins(obj.oFaceAngleYaw),
            y = obj.oPosY,
            z = obj.oPosZ - 10 * coss(obj.oFaceAngleYaw),
        }, {
            x = obj.oPosX + 10 * sins(obj.oFaceAngleYaw),
            y = obj.oPosY,
            z = obj.oPosZ + 10 * coss(obj.oFaceAngleYaw),
        })
        if col ~= nil then
            return col
        end
    end
    return nil
end

function perform_portal_displacement_object(obj, col)

    -- Check if the object hasn't teleported recently
    if obj.oUnk1A8 == 0 then
        local portal0 = P(col.index, col.type)
        local portal1 = P(col.index, 1 - col.type)
        local surfType0 = SURF_TYPE(portal0.dir.y)
        local surfType1 = SURF_TYPE(portal1.dir.y)
        local surfType01 = SURF_TYPES_IN_OUT(surfType0, surfType1)

        -- Compute flat portals vectors
        for pt = 0, 1 do
            local portal = P(col.index, pt)
            if portal.flat == 1 then
                local xzVel = { x = obj.oVelX, y = 0, z = obj.oVelZ }
                if vec3f_length(xzVel) < 1 then
                    portal.up.x = sins(obj.oFaceAngleYaw)
                    portal.up.y = 0
                    portal.up.z = coss(obj.oFaceAngleYaw)
                else
                    vec3f_copy(portal.up, xzVel)
                    vec3f_normalize(portal.up)
                end
                __compute_left_vector(portal)
                __compute_right_vector(portal)
                __compute_angles(portal)
            end
        end

        -- Translate position from entry to exit
        local pos2d = vec3f_to_2d_plane(col.pos, portal0.pos, portal0.up, portal0.left)
        local pos = vec2f_and_dist_to_3d(pos2d, 0, portal0.pos, portal0.dir, portal0.up, portal0.left)
        vec3f_sub(pos, portal0.pos)
        vec3f_mul(pos, math.min(vec3f_length(pos), PORTAL_HITBOX_RADIUS) / vec3f_length(pos))
        vec3f_add(pos, portal0.pos)
        pos2d = vec3f_to_2d_plane(pos, portal0.pos, portal0.up, portal0.left)
        pos = vec2f_and_dist_to_3d(pos2d, 0, portal1.pos, portal1.dir, portal1.up, if_then_else(sPortalInOutParams[surfType01].invertLR == 1, portal1.right, portal1.left))

        -- Offset translated position by applying floor, wall and ceiling logic
        local hbound = math.max(obj.hitboxRadius, obj.hurtboxRadius)
        local vbound = math.max(obj.hitboxHeight, obj.hurtboxHeight)
        pos.x = pos.x + (1.0 - math.abs(portal1.dir.y)) * hbound * sins(portal1.angle.z)
        pos.y = pos.y - clamp(-portal1.dir.y, 0.0, 1.0) * vbound
        pos.z = pos.z + (1.0 - math.abs(portal1.dir.y)) * hbound * coss(portal1.angle.z)

        -- Check out of bounds before teleporting the object
        local fy = find_floor_height(pos.x, pos.y, pos.z)
        if fy > -10000 then
            obj_set_pos(obj, pos.x, pos.y, pos.z)

            -- Compute the object's new face yaw
            if portal1.flat == 0 then
                if portal0.flat == 1 then
                    obj.oFaceAngleYaw = portal1.angle.z
                else
                    local diff = (math.floor(math.abs(obj.oFaceAngleYaw - portal0.angle.z)) & 0xFFFF)
                    if diff > 0x4000 then
                        obj.oFaceAngleYaw = obj.oFaceAngleYaw + 0x8000
                    end
                    obj.oFaceAngleYaw = obj.oFaceAngleYaw + (portal1.angle.z - portal0.angle.z)
                end
                if obj.oForwardVel < 0 then
                    obj.oFaceAngleYaw = obj.oFaceAngleYaw + 0x8000
                end
            end

            -- Compute the objects's new velocity
            local objVel = { x = obj.oVelX, y = obj.oVelY, z = obj.oVelZ }
            local vel2d = vec3f_to_2d_plane(objVel, VEC3_ZERO, portal0.up, portal0.left)
            local velDist = math.abs(vec3f_dist_to_plane(objVel, VEC3_ZERO, portal0.dir))
            local newVel = vec2f_and_dist_to_3d(vel2d, velDist, VEC3_ZERO, portal1.dir, portal1.up, portal1.left)
            obj_set_vel(obj, newVel.x, newVel.y, newVel.z)
            obj.oForwardVel = sign(obj.oForwardVel) * math.sqrt(newVel.x * newVel.x + newVel.z * newVel.z)

            -- Compute the object's new heights
            obj.oFloorHeight = find_floor_height(obj.oPosX, obj.oPosY, obj.oPosZ)
            local ceilHeight = find_ceil_height(obj.oPosX, obj.oPosY, obj.oPosZ)
            if ceilHeight - vbound > obj.oFloorHeight then
                obj.oPosY = clamp(obj.oPosY, obj.oFloorHeight, ceilHeight - vbound)
            else
                obj.oPosY = math.max(obj.oPosY, obj.oFloorHeight)
            end

            -- Activate portal teleportation
            play_sound(SOUND_ACTION_TELEPORT, obj.header.gfx.cameraToObject)
            obj.header.gfx.pos.x = obj.oPosX
            obj.header.gfx.pos.y = obj.oPosY
            obj.header.gfx.pos.z = obj.oPosZ
            obj.header.gfx.angle.y = obj.oFaceAngleYaw
        end
    end

    -- Set cooldown
    obj.oUnk1A8 = PORTAL_COOLDOWN
end