sPlayerLocation         = 0
sPlayerPortalCooldown   = 0
sPlayerTeleported       = { pos = { x = 0, y = 0, z = 0 }, vel = { x = 0, y = 0, z = 0 }, angle = { x = 0, y = 0, z = 0 }, t = 0 }
sPlayerFirstPerson      = { enabled = false, freecam = camera_config_is_free_cam_enabled(), pitch = 0, yaw = 0, crouch = 0 }
sPortalData             = {}
sPortalOpenList         = {}
sPortalOpenListCount    = 0

for pi = 0, (MAX_PLAYERS - 1) do
    sPortalData[pi] = {}
    for pt = 0, 1 do
        sPortalData[pi][pt] = {
            index = pi,
            type  = pt,
            pos   = { x = 0, y = 0, z = 0 },
            dir   = { x = 0, y = 0, z = 0 },
            up    = { x = 0, y = 0, z = 0 },
            left  = { x = 0, y = 0, z = 0 },
            right = { x = 0, y = 0, z = 0 },
            angle = { x = 0, y = 0, z = 0 },
            flat  = 0,
            state = PORTAL_STATE_CLOSED,
            timer = 0,
            stamp = 0,
        }
    end
end

sPortalInOutParams = {
    [SURF_TYPES_IN_OUT(SURF_FLOOR, SURF_FLOOR)] = { invertLR = 0, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_FLOOR, SURF_CEIL )] = { invertLR = 1, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_FLOOR, SURF_WALL )] = { invertLR = 0, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_CEIL,  SURF_FLOOR)] = { invertLR = 1, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_CEIL,  SURF_CEIL )] = { invertLR = 0, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_CEIL,  SURF_WALL )] = { invertLR = 0, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_WALL,  SURF_FLOOR)] = { invertLR = 0, performAirAction = 1 },
    [SURF_TYPES_IN_OUT(SURF_WALL,  SURF_CEIL )] = { invertLR = 0, performAirAction = 0 },
    [SURF_TYPES_IN_OUT(SURF_WALL,  SURF_WALL )] = { invertLR = 1, performAirAction = 0 },
}

P = function(pi, pt) return sPortalData[pi][pt] end

function __compute_left_vector(portal)
    vec3f_cross(portal.left, portal.dir, portal.up)
    vec3f_normalize(portal.left)
end

function __compute_right_vector(portal)
    vec3f_copy(portal.right, portal.left)
    vec3f_mul(portal.right, -1)
end

function __compute_angles(portal)
    portal.angle.x = -atan2s(math.sqrt(portal.dir.x * portal.dir.x + portal.dir.z * portal.dir.z), portal.dir.y)
    portal.angle.y = atan2s(portal.dir.z, portal.dir.x)
    if portal.flat == 0 then
        portal.angle.z = atan2s(portal.dir.z, portal.dir.x)
    else
        portal.angle.z = atan2s(portal.up.z, portal.up.x)
    end
end

function portal_data_update(portal, info)
    if portal.state ~= PORTAL_STATE_CLOSED then

        -- Close portal if not in local player's location
        if get_location(gMarioStates[portal.index]) ~= sPlayerLocation then
            portal.state = PORTAL_STATE_CLOSED
            return
        end

        -- If info provided, update pos and dir
        -- Mark the portal as flat if its direction is purely vertical
        if info ~= nil then
            portal.pos.x = info.hitPos.x + PORTAL_DIR_OFFSET * info.surface.normal.x
            portal.pos.y = info.hitPos.y + PORTAL_DIR_OFFSET * info.surface.normal.y
            portal.pos.z = info.hitPos.z + PORTAL_DIR_OFFSET * info.surface.normal.z
            portal.dir.x = info.surface.normal.x
            portal.dir.y = info.surface.normal.y
            portal.dir.z = info.surface.normal.z
            portal.flat  = if_then_else(math.abs(portal.dir.y) > 0.99, 1, 0)

            -- If the portal is not flat, compute vectors
            if portal.flat == 0 then
                local pitch = -atan2s(math.sqrt(portal.dir.x * portal.dir.x + portal.dir.z * portal.dir.z), portal.dir.y)
                local yaw = atan2s(portal.dir.z, portal.dir.x)
                local transform = get_transform_matrix(portal.pos, pitch, yaw)
                vec3f_copy(portal.up, portal.pos)
                for a = 0, 0x7F do
                    local v = { x = PORTAL_HITBOX_RADIUS * sins(a * 0x200), y = PORTAL_HITBOX_RADIUS * coss(a * 0x200), z = 0 }
                    v = vec3f_transform(v, transform)
                    if v.y > portal.up.y then
                        vec3f_copy(portal.up, v)
                    end
                end
                vec3f_sub(portal.up, portal.pos)
                vec3f_normalize(portal.up)
                __compute_left_vector(portal)
                __compute_right_vector(portal)
            end

            -- Compute angles for the portal object to render properly
            __compute_angles(portal)
        end
    end
end

function portal_data_send(pt)
    local m = gMarioStates[0]
    local mo = m.marioObj
    local portal = P(0, pt)
    if pt == 0 then
        mo.oUnk94              = portal.state | (mo.oTimer << 5)
        mo.oHomeX              = portal.pos.x
        mo.oHomeY              = portal.pos.y
        mo.oHomeZ              = portal.pos.z
        mo.oUnkBC              = portal.dir.x
        mo.oUnkC0              = portal.dir.y
        mo.oDragStrength       = portal.dir.z
    elseif pt == 1 then
        mo.oUnk1A8             = portal.state | (mo.oTimer << 5)
        mo.oParentRelativePosX = portal.pos.x
        mo.oParentRelativePosY = portal.pos.y
        mo.oParentRelativePosZ = portal.pos.z
        mo.oBounciness         = portal.dir.x
        mo.oFriction           = portal.dir.y
        mo.oBuoyancy           = portal.dir.z
    end
end

function portal_data_receive(pi)
    local m = gMarioStates[pi]
    local mo = m.marioObj
    local pdata = {
        [0] = {
            state = mo.oUnk94 & 0x1F,
            stamp = mo.oUnk94 >> 5,
            pos = {
                x = mo.oHomeX,
                y = mo.oHomeY,
                z = mo.oHomeZ,
            },
            dir = {
                x = mo.oUnkBC,
                y = mo.oUnkC0,
                z = mo.oDragStrength,
            },
        },
        [1] = {
            state = mo.oUnk1A8 & 0x1F,
            stamp = mo.oUnk1A8 >> 5,
            pos = {
                x = mo.oParentRelativePosX,
                y = mo.oParentRelativePosY,
                z = mo.oParentRelativePosZ,
            },
            dir = {
                x = mo.oBounciness,
                y = mo.oFriction,
                z = mo.oBuoyancy,
            },
        },
    }
    for pt = 0, 1 do
        local ptdata = pdata[pt]
        local portal = P(pi, pt)
        if ptdata.stamp ~= portal.stamp then
            portal.stamp = ptdata.stamp
            portal.state = ptdata.state
            if ptdata.state ~= PORTAL_STATE_CLOSED then
                portal.timer = 0
                if portal.state >= PORTAL_STATE_OPEN_MARIO then
                    local gi = portal.state - PORTAL_STATE_OPEN_MARIO
                    local ms = gMarioStates[network_local_index_from_global(gi)]
                    portal_data_update(portal, {
                        hitPos = {
                            x = ms.pos.x,
                            y = ms.pos.y + ms.marioObj.hitboxHeight / 2,
                            z = ms.pos.z,
                        },
                        surface = {
                            normal = {
                                x = sins(ms.faceAngle.y),
                                y = 0,
                                z = coss(ms.faceAngle.y),
                            }
                        }
                    })
                else
                    portal_data_update(portal, {
                        hitPos = {
                            x = ptdata.pos.x - (PORTAL_DIR_OFFSET * ptdata.dir.x),
                            y = ptdata.pos.y - (PORTAL_DIR_OFFSET * ptdata.dir.y),
                            z = ptdata.pos.z - (PORTAL_DIR_OFFSET * ptdata.dir.z),
                        },
                        surface = {
                            normal = {
                                x = ptdata.dir.x,
                                y = ptdata.dir.y,
                                z = ptdata.dir.z,
                            }
                        }
                    })
                end
            end
        end
    end
end

function portal_data_get_open_list()
    sPortalOpenList = {}
    sPortalOpenListCount = 0
    for pi = 0, (MAX_PLAYERS - 1) do
        if gNetworkPlayers[pi].connected then
            if P(pi, 0).state ~= PORTAL_STATE_CLOSED and P(pi, 1).state ~= PORTAL_STATE_CLOSED then
                sPortalOpenList[pi] = true
                sPortalOpenListCount = sPortalOpenListCount + 1
            end
        end
    end
end
hook_event(HOOK_UPDATE, portal_data_get_open_list)
