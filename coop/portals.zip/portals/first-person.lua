function portal_update_first_person(m)
    local sensX = 0.3 * camera_config_get_x_sensitivity()
    local sensY = 0.4 * camera_config_get_y_sensitivity()
    local invX = if_then_else(camera_config_is_x_inverted(), 1, -1)
    local invY = if_then_else(camera_config_is_y_inverted(), 1, -1)

    -- Check cancels
    if (m.action & ACT_GROUP_MASK) == ACT_GROUP_CUTSCENE or
        m.action == ACT_FIRST_PERSON or
        m.action == ACT_DROWNING or
        m.action == ACT_WATER_DEATH or
        m.action == ACT_GRABBED or
        m.action == ACT_IN_CANNON or
        m.action == ACT_TORNADO_TWIRLING or
        m.action == ACT_BUBBLED then
        portal_disable_first_person()
        return
    end

    -- Update pitch
    sPlayerFirstPerson.pitch = sPlayerFirstPerson.pitch - sensY * (invY * m.controller.extStickY - 1.5 * djui_hud_get_raw_mouse_y())
    sPlayerFirstPerson.pitch = clamp(sPlayerFirstPerson.pitch, -0x3F00, 0x3F00)

    -- Update yaw
    if (m.controller.buttonPressed & L_TRIG) ~= 0 then sPlayerFirstPerson.yaw = m.faceAngle.y + 0x8000
    else sPlayerFirstPerson.yaw = sPlayerFirstPerson.yaw + sensX * (invX * m.controller.extStickX - 1.5 * djui_hud_get_raw_mouse_x()) end
    sPlayerFirstPerson.yaw = (sPlayerFirstPerson.yaw + 0x10000) % 0x10000

    -- Fix yaw for some specific actions
    -- If the left stick is held, use Mario's yaw to set the camera's yaw
    -- Otherwise, set Mario's yaw to the camera's yaw
    for _, flag in ipairs({ ACT_FLYING, ACT_HOLDING_BOWSER, ACT_FLAG_ON_POLE, ACT_FLAG_SWIMMING }) do
        if (m.action & flag) == flag then
            if math.abs(m.controller.stickX) > 4 then sPlayerFirstPerson.yaw = m.faceAngle.y + 0x8000
            else m.faceAngle.y = sPlayerFirstPerson.yaw - 0x8000 end
            break
        end
    end
    gLakituState.yaw = sPlayerFirstPerson.yaw
    m.area.camera.yaw = sPlayerFirstPerson.yaw

    -- Crouch
    if (m.action == ACT_START_CROUCHING or m.action == ACT_CROUCHING or m.action == ACT_STOP_CROUCHING or
        m.action == ACT_START_CRAWLING or m.action == ACT_CRAWLING or m.action == ACT_STOP_CRAWLING or
        m.action == ACT_CROUCH_SLIDE) then
        local inc = 10 * if_then_else((m.controller.buttonDown & Z_TRIG) ~= 0 or m.action == ACT_CROUCH_SLIDE, 1, -1)
        sPlayerFirstPerson.crouch = clamp(sPlayerFirstPerson.crouch + inc, 0, MARIO_HEAD_POS - MARIO_HEAD_POS_SHORT)
    else
        sPlayerFirstPerson.crouch = clamp(sPlayerFirstPerson.crouch - 10, 0, MARIO_HEAD_POS - MARIO_HEAD_POS_SHORT)
    end

    -- Update pos
    gLakituState.pos.x = m.pos.x + coss(sPlayerFirstPerson.pitch) * sins(sPlayerFirstPerson.yaw)
    gLakituState.pos.y = m.pos.y + sins(sPlayerFirstPerson.pitch) + (MARIO_HEAD_POS - sPlayerFirstPerson.crouch)
    gLakituState.pos.z = m.pos.z + coss(sPlayerFirstPerson.pitch) * coss(sPlayerFirstPerson.yaw)
    vec3f_copy(m.area.camera.pos, gLakituState.pos)
    vec3f_copy(gLakituState.curPos, gLakituState.pos)
    vec3f_copy(gLakituState.goalPos, gLakituState.pos)

    -- Update focus
    gLakituState.focus.x = m.pos.x - 100 * coss(sPlayerFirstPerson.pitch) * sins(sPlayerFirstPerson.yaw)
    gLakituState.focus.y = m.pos.y - 100 * sins(sPlayerFirstPerson.pitch) + (MARIO_HEAD_POS - sPlayerFirstPerson.crouch)
    gLakituState.focus.z = m.pos.z - 100 * coss(sPlayerFirstPerson.pitch) * coss(sPlayerFirstPerson.yaw)
    vec3f_copy(m.area.camera.focus, gLakituState.focus)
    vec3f_copy(gLakituState.curFocus, gLakituState.focus)
    vec3f_copy(gLakituState.goalFocus, gLakituState.focus)

    -- Set other values
    gLakituState.posHSpeed = 0
    gLakituState.posVSpeed = 0
    gLakituState.focHSpeed = 0
    gLakituState.focVSpeed = 0
end

function portal_enable_first_person()
    sPlayerFirstPerson.freecam = camera_config_is_free_cam_enabled()
    camera_config_enable_free_cam(false)
    camera_freeze()
    sPlayerFirstPerson.enabled = true
    sPlayerFirstPerson.crouch = 0
    sPlayerFirstPerson.pitch = 0
    sPlayerFirstPerson.yaw = gMarioStates[0].faceAngle.y + 0x8000
end

function portal_disable_first_person()
    camera_config_enable_free_cam(sPlayerFirstPerson.freecam)
    camera_unfreeze()
    sPlayerFirstPerson.enabled = false
    sPlayerFirstPerson.crouch = 0
    sPlayerFirstPerson.pitch = 0
    sPlayerFirstPerson.yaw = 0
end

function portal_update_camera_mode()
    if sPlayerFirstPerson.enabled then
        gLakituState.mode = CAMERA_MODE_FREE_ROAM
        gLakituState.defMode = CAMERA_MODE_FREE_ROAM
    elseif camera_config_is_free_cam_enabled() then
        gLakituState.mode = CAMERA_MODE_NEWCAM
        gLakituState.defMode = CAMERA_MODE_NEWCAM
    elseif gLakituState.mode == CAMERA_MODE_NEWCAM or gLakituState.defMode == CAMERA_MODE_NEWCAM then
        gLakituState.mode = CAMERA_MODE_FREE_ROAM
        gLakituState.defMode = CAMERA_MODE_FREE_ROAM
    end
end

function portal_reset_first_person()
    if sPlayerFirstPerson.enabled then
        portal_disable_first_person()
        portal_enable_first_person()
    end
end

hook_event(HOOK_UPDATE, portal_update_camera_mode)
hook_event(HOOK_ON_WARP, portal_reset_first_person)
