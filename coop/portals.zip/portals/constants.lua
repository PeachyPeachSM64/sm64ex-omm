PORTAL_HITBOX_RADIUS        = 200
PORTAL_MODEL_RADIUS         = 105
PORTAL_MARIO_RADIUS         = 55
PORTAL_MARIO_HEIGHT         = 161
PORTAL_DIR_OFFSET           = 2
PORTAL_COOLDOWN             = 5

PORTAL_STATE_CLOSED         = 0
PORTAL_STATE_OPEN_SURFACE   = 1
PORTAL_STATE_OPEN_OBJECT    = 2
PORTAL_STATE_OPEN_MARIO     = 3

PORTAL_SHOT_OFFSET          = 200
PORTAL_SHOT_VEL             = 200
PORTAL_SHOT_DURATION        = 45
PORTAL_SHOT_DURATION_INF    = 300

E_MODEL_PORTAL_0            = smlua_model_util_get_id("blue_portal_geo")
E_MODEL_PORTAL_1            = smlua_model_util_get_id("orange_portal_geo")
E_MODEL_PORTAL              = { [0] = E_MODEL_PORTAL_0, [1] = E_MODEL_PORTAL_1 }

E_MODEL_PORTAL_SHOT_0       = smlua_model_util_get_id("blue_shot_geo")
E_MODEL_PORTAL_SHOT_1       = smlua_model_util_get_id("orange_shot_geo")
E_MODEL_PORTAL_SHOT         = { [0] = E_MODEL_PORTAL_SHOT_0, [1] = E_MODEL_PORTAL_SHOT_1 }

SURF_FLOOR                  = 0
SURF_CEIL                   = 1
SURF_WALL                   = 2
SURF_TYPE                   = function(y) return if_then_else(y > 0.01, SURF_FLOOR, if_then_else(y < -0.01, SURF_CEIL, SURF_WALL)) end
SURF_TYPES_IN_OUT           = function(surfType0, surfType1) return ((surfType0 << 2) | surfType1) end

MARIO_HEAD_POS              = 120
MARIO_HEAD_POS_SHORT        = 60

VEC3_ZERO                   = { x = 0, y = 0, z = 0 }
