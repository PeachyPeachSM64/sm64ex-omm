function bhv_portal_init(o)
    o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    o.oSubAction = 0
end

function bhv_portal_loop(o)
    local portal = P(o.oAction, o.oBehParams2ndByte)
    if portal.state ~= PORTAL_STATE_CLOSED then
        obj_scale(o, (math.min(portal.timer, 10) * PORTAL_HITBOX_RADIUS) / (10 * PORTAL_MODEL_RADIUS))
        obj_set_pos(o, portal.pos.x, portal.pos.y, portal.pos.z)
        obj_set_angle(o, portal.angle.x + 0x4000, portal.angle.y, 0)
        o.oAnimState = o.oAnimState + 1
        o.activeFlags = o.activeFlags | ACTIVE_FLAG_INITIATED_TIME_STOP
        o.oSubAction = math.min(portal.timer, 10)
    else
        obj_scale(o, (o.oSubAction * PORTAL_HITBOX_RADIUS) / (10 * PORTAL_MODEL_RADIUS))
        o.oSubAction = math.max(0, o.oSubAction - 2)
    end
end

id_bhvPortal0 = hook_behavior(nil, OBJ_LIST_POLELIKE, true, bhv_portal_init, bhv_portal_loop)
id_bhvPortal1 = hook_behavior(nil, OBJ_LIST_POLELIKE, true, bhv_portal_init, bhv_portal_loop)
id_bhvPortal = { [0] = id_bhvPortal0, [1] = id_bhvPortal1 }
