function bhv_portal_shot_init(o)
    o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    o.header.gfx.node.flags = o.header.gfx.node.flags | GRAPH_RENDER_BILLBOARD
end

function bhv_portal_shot_open_portal(o, portal, state, info)
    portal.state = state
    portal.timer = 0
    portal_data_update(portal, info)
    portal_data_send(portal.type)
    play_sound(SOUND_OBJ_DEFAULT_DEATH, o.header.gfx.cameraToObject)
    obj_mark_for_deletion(o)
end

function bhv_portal_shot_loop(o)
    local x = o.oPosX
    local y = o.oPosY
    local z = o.oPosZ
    local dx = o.oVelX
    local dy = o.oVelY
    local dz = o.oVelZ
    local pt = o.oBehParams2ndByte
    local portal = P(0, pt)
    local portalO = P(0, 1 - pt)

    -- Check collision with objects (only if the other portal is already open)
    if portalO.state == PORTAL_STATE_OPEN_SURFACE then
        local objCol = collision_find_object(x, y, z, x + dx, y + dy, z + dz)
        if objCol ~= nil then
            bhv_portal_shot_open_portal(o, portal, PORTAL_STATE_OPEN_OBJECT, objCol)
            return
        end
    end

    -- Check collision with other Marios (only if the other portal is already open)
    if portalO.state == PORTAL_STATE_OPEN_SURFACE then
        local x1 = x + dx
        local y1 = y + dy
        local z1 = z + dz
        for pi = 1, (MAX_PLAYERS - 1) do
            local mi = gMarioStates[pi]
            if gNetworkPlayers[pi].connected and get_location(mi) == sPlayerLocation then
                local cx = mi.pos.x
                local cy = mi.pos.y
                local cz = mi.pos.z
                local cr = 50
                local ch = mi.marioObj.hitboxHeight
                if check_line_cylinder_collision(x, y, z, x1, y1, z1, cx, cy, cz, cr, ch) then
                    bhv_portal_shot_open_portal(o, portal, PORTAL_STATE_OPEN_MARIO + gNetworkPlayers[pi].globalIndex, {
                        hitPos = {
                            x = cx,
                            y = cy + ch / 2,
                            z = cz,
                        },
                        surface = {
                            normal = {
                                x = sins(mi.faceAngle.y),
                                y = 0,
                                z = coss(mi.faceAngle.y),
                            },
                        },
                    })
                    return
                end
            end
        end
    end

    -- Check collision with surfaces
    for _ = 1, 4 do
        local info = collision_find_surface_on_ray(x, y, z, dx, dy, dz)
        if info.surface ~= nil then
            bhv_portal_shot_open_portal(o, portal, PORTAL_STATE_OPEN_SURFACE, info)
            return
        end
        x = x + dx / 4
        y = y + dy / 4
        z = z + dz / 4
    end

    -- No collision, update the shot
    obj_scale(o, 1)
    cur_obj_move_using_vel()
    if o.oTimer > PORTAL_SHOT_DURATION then
        obj_mark_for_deletion(o)
    end
end

id_bhvPortalShot = hook_behavior(nil, OBJ_LIST_POLELIKE, true, bhv_portal_shot_init, bhv_portal_shot_loop)

function spawn_portal_shot(m, pt)
    if m.area ~= nil and m.area.camera ~= nil then
        local o = obj_get_first_with_behavior_id_and_field_s32(id_bhvPortalShot, 0x2F, pt)
        if o == nil then o = spawn_non_sync_object(id_bhvPortalShot, E_MODEL_PORTAL_SHOT[pt], 0, 0, 0, nil) end
        if o ~= nil then
            local dx = m.area.camera.focus.x - m.area.camera.pos.x
            local dy = m.area.camera.focus.y - m.area.camera.pos.y
            local dz = m.area.camera.focus.z - m.area.camera.pos.z
            local dv = math.sqrt(dx * dx + dy * dy + dz * dz)
            o.oBehParams2ndByte = pt
            o.oVelX = PORTAL_SHOT_VEL * (dx / dv)
            o.oVelY = PORTAL_SHOT_VEL * (dy / dv)
            o.oVelZ = PORTAL_SHOT_VEL * (dz / dv)
            o.oPosX = m.area.camera.pos.x + if_then_else(sPlayerFirstPerson.enabled, 0, PORTAL_SHOT_OFFSET) * (o.oVelX / PORTAL_SHOT_VEL)
            o.oPosY = m.area.camera.pos.y + if_then_else(sPlayerFirstPerson.enabled, 0, PORTAL_SHOT_OFFSET) * (o.oVelY / PORTAL_SHOT_VEL)
            o.oPosZ = m.area.camera.pos.z + if_then_else(sPlayerFirstPerson.enabled, 0, PORTAL_SHOT_OFFSET) * (o.oVelZ / PORTAL_SHOT_VEL)
            o.oTimer = 0
            play_sound(SOUND_OBJ_MRI_SHOOT, m.marioObj.header.gfx.cameraToObject)
        end
    end
end
