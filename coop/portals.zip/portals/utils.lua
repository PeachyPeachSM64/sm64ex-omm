function if_then_else(cond, if_true, if_false)
    if cond then return if_true end
    return if_false
end

function get_location(m)
    local np = gNetworkPlayers[m.playerIndex]
    return (
        (np.currLevelNum  << 8) |
        (np.currActNum    << 4) |
        (np.currAreaIndex << 0)
    )
end

function clamp(x, a, b)
    if x < a then return a end
    if x > b then return b end
    return x
end

function sign(x)
    if x < 0 then return -1 end
    return 1
end

function lerp(t, a, b)
    return a + (b - a) * t
end

function invlerp(x, a, b)
    return (x - a) / (b - a)
end

function get_transform_matrix(pos, pitch, yaw)
    local matrix = {}
    local sx = sins(pitch)
    local cx = coss(pitch)
    local sy = sins(yaw)
    local cy = coss(yaw)
    local sz = sins(0)
    local cz = coss(0)
    matrix.m00 = cy * cz + sx * sy * sz
    matrix.m10 = -cy * sz + sx * sy * cz
    matrix.m20 = cx * sy
    matrix.m30 = pos.x
    matrix.m01 = cx * sz
    matrix.m11 = cx * cz
    matrix.m21 = -sx
    matrix.m31 = pos.y
    matrix.m02 = -sy * cz + sx * cy * sz
    matrix.m12 = sy * sz + sx * cy * cz
    matrix.m22 = cx * cy
    matrix.m32 = pos.z
    matrix.m03 = 0
    matrix.m13 = 0
    matrix.m23 = 0
    matrix.m33 = 1
    return matrix
end

function vec3f_transform(vec, transform)
    return {
        x = vec.x * transform.m00 + vec.y * transform.m10 + vec.z * transform.m20 + transform.m30,
        y = vec.x * transform.m01 + vec.y * transform.m11 + vec.z * transform.m21 + transform.m31,
        z = vec.x * transform.m02 + vec.y * transform.m12 + vec.z * transform.m22 + transform.m32,
    }
end

function vec3f_cross(dest, a, b)
    dest.x = a.y * b.z - b.y * a.z
    dest.y = a.z * b.x - b.z * a.x
    dest.z = a.x * b.y - b.x * a.y
end

function vec3f_dist_to_plane(v3d, origin, n)
    local v = {
        x = v3d.x - origin.x,
        y = v3d.y - origin.y,
        z = v3d.z - origin.z,
    }
    return vec3f_dot(n, v)
end

function vec3f_to_2d_plane(v3d, origin, e1, e2)
    local v = {
        x = v3d.x - origin.x,
        y = v3d.y - origin.y,
        z = v3d.z - origin.z,
    }
    return {
        x = vec3f_dot(e1, v),
        y = vec3f_dot(e2, v),
    }
end

function vec2f_and_dist_to_3d(v2d, dist, origin, n, e1, e2)
    return {
        x = origin.x + v2d.x * e1.x + v2d.y * e2.x + dist * n.x,
        y = origin.y + v2d.x * e1.y + v2d.y * e2.y + dist * n.y,
        z = origin.z + v2d.x * e1.z + v2d.y * e2.z + dist * n.z,
    }
end

function vec2f_get_projected_point_on_line(px, py, ax, ay, bx, by)
    local e1x = bx - ax
    local e1y = by - ay
    local e2x = px - ax
    local e2y = py - ay
    local edp = e1x * e2x + e1y * e2y
    local e1s = e1x * e1x + e1y * e1y
    return {
        x = ax + edp * e1x / e1s,
        y = ay + edp * e1y / e1s,
    }
end

function vec3f_is_inside_cylinder(px, py, pz, cx, cy, cz, cr, ch)
    return cy < py and py < cy + ch and (px - cx)^2 + (pz - cz)^2 < cr^2
end

function check_line_cylinder_collision(ax, ay, az, bx, by, bz, cx, cy, cz, cr, ch)
    if vec3f_is_inside_cylinder(ax, ay, az, cx, cy, cz, cr, ch) then return true end
    if vec3f_is_inside_cylinder(bx, by, bz, cx, cy, cz, cr, ch) then return true end

    -- Add an offset for vertical lines
    if math.abs(bx - ax) < 0.01 and math.abs(bz - az) < 0.01 then
        az = bz + 0.1
    end

    -- Check line-circle intersection
    local q = vec2f_get_projected_point_on_line(cx, cz, ax, az, bx, bz)
    local qx = q.x
    local qz = q.y
    local qd2 = (qx - cx)^2 + (qz - cz)^2
    local cr2 = cr^2
    if qd2 > cr2 then
        return false
    end

    -- Check point in bounds
    local ty = 0
    if bz - az ~= 0 then ty = invlerp(qz, az, bz)
    else ty = invlerp(qx, ax, bx) end
    if ty < -0.01 or ty > 1.01 then
        return false
    end

    -- Check y coordinate
    local qy = lerp(ty, ay, by)
    return cy <= qy and qy <= cy + ch
end

