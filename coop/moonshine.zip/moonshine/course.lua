smlua_text_utils_course_acts_replace(COURSE_BOB, " 1 ARCHIPELAGO'S WATERFALLS",
"BIG BOB-OMB COMES BACK", "ON THE HIGHEST ROCK", "HIDDEN ON THE CLIFF",
"FIND THE 8 GREEN COINS", "IN THE BOBOMB'S CAVE", "HIDDEN IN THE CAVE")

smlua_text_utils_course_acts_replace(COURSE_WF, " 2 DOWN STREET",
"PROBLEMS IN THE TOWER", "HIDDEN IN THE TRASH", "BOX IN THE BUILDING",
"GREEN COINS IN THE CITY", "ON THE GREEN ROOF", "FLOATING IN THE AIR")

smlua_text_utils_course_acts_replace(COURSE_CCM, " 4 MELTED ICE",
"PENGUIN LOST, AGAIN!", "8 GREEN COINS IN THE SNOW", "THE COLD FLOATING ISLAND",
"SHINE IN THE MOUNTAIN TOP", "5 GREEN COINS IN THE LAVA", "STEPPING ON THE RED BLOCKS")

smlua_text_utils_course_acts_replace(COURSE_BBH, " 5 GREEN WOODS",
"HAUNTED FOREST", "UNDERWATER", "WALL JUMP BETWEEN THE WOODS",
"8 GREEN COINS IN THE FOREST", "ABOVE THE TREES", "HIDDEN PIPE")

smlua_text_utils_course_acts_replace(COURSE_HMC, " 6 SKYLAND FORTRESS",
"BOX IN THE TOP OF THE CASTLE", "FLOATING IN THE BOW", "IN THE HIGHEST TOWER",
"FIND THE 8 GREEN COINS", "CLIMBING THE FORTRESS", "THE MYSTERY PIPE")

smlua_text_utils_course_acts_replace(COURSE_LLL, " 7 SWEET SWEET RUSH",
"CLIMBING THE GIANT CAKE", "GREEN COINS IN THE SWEET PASS", "",
"", "", "")

smlua_text_utils_course_acts_replace(COURSE_WDW, "11 GREEN PLAINS",
"QUIET WALK", "WALL JUMPING", "LOOKING FOR DIAMONDS IN THE CAVE",
"GREEN COINS IN THE WAY", "", "")

smlua_text_utils_secret_star_replace(COURSE_BITFS, "   PURPLE SWAMPY SWAMP")
smlua_text_utils_secret_star_replace(COURSE_BITS,  "   MOONSHINE")
smlua_text_utils_secret_star_replace(COURSE_PSS,   "   FOREST VALLEY")

smlua_text_utils_castle_secret_stars_replace("   CASTLE SECRET STARS")

smlua_text_utils_extra_text_replace(0, "ONE OF THE CASTLE'S SECRET STARS!")
smlua_text_utils_extra_text_replace(1, "")
smlua_text_utils_extra_text_replace(2, "")
smlua_text_utils_extra_text_replace(3, "")
smlua_text_utils_extra_text_replace(4, "")
smlua_text_utils_extra_text_replace(5, "")
smlua_text_utils_extra_text_replace(6, "")
