----------
-- Data --
----------

sMoonshineAudioData = {
    [0x23] = { loopStart =  4.81, loopEnd =  48.83, volume = 0.80, filename = "sound/23_custom_chain.ogg"       },
    [0x24] = { loopStart = 13.31, loopEnd =  96.85, volume = 0.85, filename = "sound/24_custom_donk.ogg"        },
    [0x25] = { loopStart =  9.48, loopEnd = 116.87, volume = 0.80, filename = "sound/25_custom_gusty.ogg"       },
    [0x27] = { loopStart =  4.13, loopEnd =  37.80, volume = 0.80, filename = "sound/27_custom_land.ogg"        },
    [0x29] = { loopStart =  0.00, loopEnd =  62.50, volume = 0.65, filename = "sound/29_custom_castle.ogg"      },
    [0x2A] = { loopStart =  6.30, loopEnd = 105.80, volume = 0.80, filename = "sound/2A_custom_snowball.ogg"    },
    [0x2B] = { loopStart =  4.05, loopEnd = 160.06, volume = 0.80, filename = "sound/2B_custom_snow_lava.ogg"   },
    [0x2C] = { loopStart =  4.20, loopEnd = 112.56, volume = 0.80, filename = "sound/2C_custom_sweet.ogg"       },
    [0x2D] = { loopStart =  4.63, loopEnd =  60.00, volume = 0.85, filename = "sound/2D_custom_underground.ogg" },
    [0x2F] = { loopStart =  7.80, loopEnd =  86.70, volume = 0.75, filename = "sound/2F_custom_creek.ogg"       },
}

sMoonshineBackgroundSeqs = {
    [LEVEL_BOB]    = { [1] = 0x27 },
    [LEVEL_WF]     = { [1] = 0x24 },
    [LEVEL_CCM]    = { [1] = 0x2A, [2] = 0x2B },
    [LEVEL_HMC]    = { [1] = 0x25, [2] = 0x25 },
    [LEVEL_LLL]    = { [1] = 0x2C },
    [LEVEL_WDW]    = { [1] = 0x27, [2] = 0x2D },
    [LEVEL_BITFS]  = { [1] = 0x2F },
    [LEVEL_BITS]   = { [1] = 0x25 },
    [LEVEL_PSS]    = { [1] = 0x23 },
    [LEVEL_CASTLE] = { [1] = 0x29 }
}

-----------
-- State --
-----------

sMoonshineAudioState = {
    audio = nil,
    seq = 0x00,
    position = 0.0,
    volume = 0.0,
}

function moonshine_get_seq_to_play(level, area)
    if obj_get_first_with_behavior_id(id_bhvActSelector) == nil then
        local seq = sMoonshineBackgroundSeqs[level]
        if seq ~= nil and seq[area] ~= nil then
            return seq[area]
        end
    end
    return 0x00
end

function moonshine_get_audio_target_volume()
    if is_game_paused() then return 0.0 end
    if get_current_background_music() > 0 then return 0.0 end
    if get_current_background_music_target_volume() ~= 0 then return 0.0 end
    if get_current_background_music_max_target_volume() ~= 0 then return 0.0 end
    if is_current_background_music_volume_lowered() ~= 0 then return 0.5 end
    return 1.0
end

------------
-- Update --
-----------

function moonshine_update_audio()
    local m = gMarioStates[0]
    local np = gNetworkPlayers[m.playerIndex]
    local seq = moonshine_get_seq_to_play(np.currLevelNum, np.currAreaIndex)
    local data = sMoonshineAudioData[seq]

    -- Stop the current music
    if sMoonshineAudioState.seq ~= seq then
        if sMoonshineAudioState.audio ~= nil then
            audio_stream_stop(sMoonshineAudioState.audio)
            audio_stream_destroy(sMoonshineAudioState.audio)
        end
        sMoonshineAudioState.audio = nil
        sMoonshineAudioState.seq = 0x00
    end

    -- Start the music to play
    if sMoonshineAudioState.audio == nil and data ~= nil then
        sMoonshineAudioState.audio = audio_stream_load(data.filename)
        audio_stream_play(sMoonshineAudioState.audio, true, data.volume)
        audio_stream_set_looping(sMoonshineAudioState.audio, false)
        sMoonshineAudioState.volume = 1.0
        sMoonshineAudioState.position = 0.0
        sMoonshineAudioState.seq = seq
    end

    -- Update the playing music
    if sMoonshineAudioState.audio ~= nil then

        -- Loop if the music reached the end point
        local pos = audio_stream_get_position(sMoonshineAudioState.audio)
        if pos >= data.loopEnd then
            audio_stream_play(sMoonshineAudioState.audio, true, data.volume)
            audio_stream_set_position(sMoonshineAudioState.audio, data.loopStart)
            sMoonshineAudioState.position = data.loopStart
        end

        -- Update volume
        local targetVolume = moonshine_get_audio_target_volume()
        if sMoonshineAudioState.volume > targetVolume then
            local pirahnaPlant = obj_get_nearest_object_with_behavior_id(m.marioObj, id_bhvPiranhaPlant)
            if pirahnaPlant ~= nil and pirahnaPlant.oAction == PIRANHA_PLANT_ACT_SLEEPING and dist_between_objects(m.marioObj, pirahnaPlant) < 1000 then
                sMoonshineAudioState.volume = math.max(sMoonshineAudioState.volume - 0.02, targetVolume)
            else
                sMoonshineAudioState.volume = math.max(sMoonshineAudioState.volume - 0.10, targetVolume)
            end
            if sMoonshineAudioState.volume == 0.0 then
                sMoonshineAudioState.position = pos
            end
        elseif sMoonshineAudioState.volume < targetVolume then
            if sMoonshineAudioState.volume == 0.0 then
                audio_stream_set_position(sMoonshineAudioState.audio, sMoonshineAudioState.position)
            end
            sMoonshineAudioState.volume = math.min(sMoonshineAudioState.volume + 0.05, targetVolume)
        end
        audio_stream_set_volume(sMoonshineAudioState.audio, data.volume * sMoonshineAudioState.volume)
    end
end

hook_event(HOOK_UPDATE, moonshine_update_audio)
