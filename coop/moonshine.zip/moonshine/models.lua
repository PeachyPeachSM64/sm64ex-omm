E_MODEL_BEE = smlua_model_util_get_id("Bee_geo")
E_MODEL_MOLINE = smlua_model_util_get_id("Moline_geo")
E_MODEL_GOOMBONE = smlua_model_util_get_id("goombone_geo")
