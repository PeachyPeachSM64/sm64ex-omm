-- name: Super Mario 64 Moonshine
-- description: A complete PC port mod developed by TurnFlashed, S4ys and Fito.\nPorted to Coop by PeachyPeach.\n\nExplore 10 new huge and colorful worlds and collect a total of 50 Moons!
-- incompatible: romhack

------------------
-- level values --
------------------

gLevelValues.entryLevel = LEVEL_CASTLE
gLevelValues.exitCastleLevel = LEVEL_CASTLE
gLevelValues.exitCastleArea = 1
gLevelValues.exitCastleWarpNode = 0x1F
gLevelValues.skipCreditsAt = LEVEL_BOB

----------------------------------

hook_event(HOOK_GET_STAR_COLLECTION_DIALOG, function () return 0 end)
