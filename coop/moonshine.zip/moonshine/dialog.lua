smlua_text_utils_dialog_replace(DIALOG_000, 1, 3, 30, 200,
"Welcome! You're now in\
Archipelago's Watterfalls.\
\
Looks like Peach got\
kidnapped...again, and\
Bowser changed levels!\
Don't worry, if you hear\
my advice, everything's\
gonna be okay.\
First of all, you remember\
the guy with the mustache?\
No, not you...\
I mean the King Bob-omb.\
Well, he came back and he's\
causing a lot of troubles.\
So, what if you defeat him\
again? You know, like the\
old times!")

smlua_text_utils_dialog_replace(DIALOG_001, 1, 3, 95, 200,
"Hi there Mario! What a\
nice place, don't you\
think? it's very refreshing.\
Oh and hey, what are you\
doing here? Searching\
for moons?\
If it's that, I think\
I saw a couple of them\
up ahead.\
But there's a little\
problem, as you can see,\
it's a bit haunted here...\
Usually, this forest is\
full of Goombas, but right\
now, Boos are everywhere!\
You should go to see\
what is happening...\
What about me?\
I'm leaving now!\
I'm a little scared,\
good luck, Mario!")

smlua_text_utils_dialog_replace(DIALOG_002, 1, 4, 95, 200,
"Hey, Mario! It's you again,\
what are you doing here?\
It's a beautiful city,\
don't you think?\
Sadly right now is not the\
best moment to do a visit.\
As you can see the tower\
is having a bad time...\
Maybe you can do something.\
Try to reach the Moon,\
it is at the top.\
Usually, you can enter by\
the door but right now there\
are giant rocks blocking it,\
so you have to find another\
way to climb the tower.")

smlua_text_utils_dialog_replace(DIALOG_008, 1, 3, 30, 200,
"Welcome to the credits\
room. Here are all people\
who helped in the project.\
Ahead is S4YS. He's the main\
support, he set up and fixed\
all warps and the hub zone.\
On the left is Turnflashed,\
who made all levels and\
imported all models in game.\
And on the right is Fito,\
who imported the music.\
Thanks guys for all help!")

smlua_text_utils_dialog_replace(DIALOG_015, 1, 3, 30, 200,
"Hmm, you can't enter,\
right? Looks like you\
have to find another way.\
Let me give you a clue,\
up here is a thing\
that maybe can help you.\
Try to climb using those\
platforms, it's really easy!")

smlua_text_utils_dialog_replace(DIALOG_017, 1, 4, 30, 200,
"Wait what?! You again?\
ahhg what are you doing\
here! This is my new spot\
so... Get out of here!\
Oh wait, nevermind... It's\
my chance to get my revenge\
over you! HAHAHA your time\
has come, do you hear me?!\
You won't get out of this,\
not this time... My back\
still hurts since that day!\
\
Now I have a Moon! It's\
better than a Star, it\
makes me stronger!\
More than last time!\
Ohh, you want the Moon,\
right? Well, I'm sorry\
plumber, but that's not\
gonna happen!\
Enough talk, it's time to\
fight! Give your best!\
Get yourself ready!\
NOW!")

smlua_text_utils_dialog_replace(DIALOG_024, 1, 5, 95, 200,
"You need Moon power to\
open this door. Recover\
a Moon from an enemy\
inside one of the castle's\
paintings.")

smlua_text_utils_dialog_replace(DIALOG_025, 1, 4, 95, 200,
"It takes the power of\
3 Moons to open this\
door. You need [%] more\
Moons.")

smlua_text_utils_dialog_replace(DIALOG_026, 1, 4, 95, 200,
"It takes the power of\
8 Moons to open this\
door. You need [%] more\
Moons.")

smlua_text_utils_dialog_replace(DIALOG_027, 1, 4, 95, 200,
"It takes the power of\
30 Moons to open this\
door. You need [%] more\
Moons.")

smlua_text_utils_dialog_replace(DIALOG_064, 1, 5, 30, 200,
"Uff...It's boiling in\
here... Oh! You again!\
Like the last time, this\
place has 3 Moons as well,\
go and get them!\
But hey, be careful, this\
lava is burning and as\
you can see, there are\
some tough guys down\
there. Good luck!")

smlua_text_utils_dialog_replace(DIALOG_095, 1, 4, 30, 200,
"Welcome to the circuit!\
Jump on the cloud and\
use it to move.\
\
You'll have to pass\
the circuit and\
grab 4 green coins\
to get the Moon.\
But be careful...\
Bees and Flyguys are\
after you! Good luck!")

smlua_text_utils_dialog_replace(DIALOG_113, 1, 5, 30, 200,
"Brrrr... What a cold place!\
Oh hey, there must be 3\
Moons here, go and get\
them all, and you'll be\
able to enter the pipe.")

smlua_text_utils_dialog_replace(DIALOG_133, 1, 5, 30, 200,
"I am glad to see you\
again! Looks like there\
are a lot of moons out\
there, you should take\
a look.\
By the way, I haven't\
seen Peach around\
here and I'm a bit\
worried, not gonna\
lie.\
Please recover the Power\
Moons! As you find them,\
you can use their power\
to open the doors, that's\
gonna help you.\
There are 2 rooms here,\
and just up ahead is\
the warp pipe leading\
to the first World.\
\
You have to be careful!\
There are a lot of\
dangers, so go Mario,\
go and find all the\
Moons across the world.")

smlua_text_utils_dialog_replace(DIALOG_134, 1, 4, 30, 200,
"Ouh Mario, it's you!\
Exploring the castle?\
I love being here,\
it's really comfortable.\
Also, there are some\
rooms you can visit,\
but you'll need the power\
of the Moons to open them.\
You can go to the yard\
without Moons, there\
is a very special room\
you should visit :)")
