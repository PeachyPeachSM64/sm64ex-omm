function moonshine_update_behavior(bhv, func)
    local obj = obj_get_first_with_behavior_id(bhv)
    while obj ~= nil do
        func(obj)
        obj = obj_get_next_with_same_behavior_id(obj)
    end
end

function moonshine_update_behaviors()
    moonshine_update_behavior(id_bhvLllRotatingHexagonalPlatform, function (obj)
        obj.collisionData = smlua_collision_util_get("RotateDonut_collision")
    end)
    moonshine_update_behavior(id_bhvLllTiltingInvertedPyramid, function (obj)
        obj.collisionData = smlua_collision_util_get("TitlingC_collision")
    end)
    moonshine_update_behavior(id_bhvTtmRollingLog, function (obj)
        obj.collisionData = smlua_collision_util_get("SSLog_collision")
    end)
    moonshine_update_behavior(id_bhvUnused05A8, function (obj)
        obj.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
        obj.oFaceAnglePitch = obj.oFaceAnglePitch + 0x100
        obj.oAngleVelPitch = obj.oAngleVelPitch + 0x100
        obj.oMoveAnglePitch = obj.oMoveAnglePitch + 0x100
        obj_set_model_extended(obj, E_MODEL_MOLINE)
    end)
end
hook_event(HOOK_UPDATE, moonshine_update_behaviors)
