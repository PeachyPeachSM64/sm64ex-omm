-- name: Wanted!
-- incompatible: gamemode
-- description: Coop gamemode inspired by the Wanted! minigame from NSMB/SM64DS.\n\nCreated by PeachyPeach.

for i, _ in pairs(gActiveMods) do
    if i ~= 0 then
        djui_popup_create_global("\\#FF4040\\You can't play \\#FFC000\\Wanted!\\#FF4040\\ with other mods\nenabled. Please disable them first.\\#\\", 2)
        return 0
    end
end

------------
-- Locals --
------------

local table_insert = table.insert
local table_sort = table.sort

local math_floor = math.floor
local math_random = math.random

local djui_hud_set_resolution = djui_hud_set_resolution
local djui_hud_set_font = djui_hud_set_font
local djui_hud_set_color = djui_hud_set_color
local djui_hud_get_screen_width = djui_hud_get_screen_width
local djui_hud_get_screen_height = djui_hud_get_screen_height
local djui_hud_render_rect = djui_hud_render_rect
local djui_hud_render_texture = djui_hud_render_texture
local djui_hud_measure_text = djui_hud_measure_text
local djui_hud_print_text = djui_hud_print_text

local gNetworkPlayers = gNetworkPlayers
local gMarioStates = gMarioStates
local g = gGlobalSyncTable
local np0 = gNetworkPlayers[0]
local ps0 = gPlayerSyncTable[0]
local gGlobalSoundSource = { x = 0, y = 0, z = 0 }

---------------
-- Constants --
---------------

local STATE_ROUND_WAITING   = 0
local STATE_ROUND_BEGIN     = 1
local STATE_ROUND_STARTED   = 2
local STATE_ROUND_ENDED     = 3
local STATE_ROUND_GAME_OVER = 4

local TARGET_NONE  = 0
local TARGET_MARIO = 1
local TARGET_LUIGI = 2
local TARGET_WARIO = 3
local TARGET_TOAD  = 4
local TARGET_CT    = {
    [TARGET_NONE]  = CT_MARIO,
    [TARGET_MARIO] = CT_MARIO,
    [TARGET_LUIGI] = CT_LUIGI,
    [TARGET_WARIO] = CT_WARIO,
    [TARGET_TOAD]  = CT_TOAD,
}

local SOUND_TARGET_REVEALED = (SOUND_MENU_CLICK_CHANGE_VIEW | 0xFF00)
local SOUND_CORRECT         = (SOUND_GENERAL2_RIGHT_ANSWER | 0xFF00)
local SOUND_INCORRECT       = (SOUND_MENU_CAMERA_BUZZ | 0xFF00)
local SOUND_TIME_TICK       = (SOUND_GENERAL2_SWITCH_TICK_SLOW | 0xFE00)
local SOUND_CHAR_CORRECT    = {
    { sound = CHAR_SOUND_UH,       offset = 0 },
    { sound = CHAR_SOUND_WHOA,     offset = 0 },
    { sound = CHAR_SOUND_ATTACKED, offset = 0 },
    { sound = CHAR_SOUND_OOOF,     offset = 0 },
    { sound = CHAR_SOUND_OOOF2,    offset = 0 },
    { sound = CHAR_SOUND_WAAAOOOW, offset = 0 },
    { sound = CHAR_SOUND_MAMA_MIA, offset = 0 },
    { sound = CHAR_SOUND_DOH,      offset = 0 },
}
local SOUND_CHAR_INCORRECT = {
    { sound = CHAR_SOUND_YAHOO,             offset = 0 },
    { sound = CHAR_SOUND_YAHOO_WAHA_YIPPEE, offset = 2 },
    { sound = CHAR_SOUND_YAHOO_WAHA_YIPPEE, offset = 3 },
    { sound = CHAR_SOUND_YAHOO_WAHA_YIPPEE, offset = 4 },
    { sound = CHAR_SOUND_HERE_WE_GO,        offset = 0 },
    { sound = CHAR_SOUND_HAHA,              offset = 0 },
    { sound = CHAR_SOUND_HAHA_2,            offset = 0 },
}

local RANK_STRING = {
    [1] = "st",
    [2] = "nd",
    [3] = "rd",
    [4] = "th",
}

--------------
-- Textures --
--------------

local tex_wanted_wall    = get_texture_info("wanted_wall")
local tex_wanted_circle  = get_texture_info("wanted_circle")
local tex_wanted_m       = get_texture_info("wanted_m")
local tex_wanted_l       = get_texture_info("wanted_l")
local tex_wanted_w       = get_texture_info("wanted_w")
local tex_wanted_t       = get_texture_info("wanted_t")
local tex_hand_open      = get_texture_info("gd_texture_hand_open")
local tex_hand_closed    = get_texture_info("gd_texture_hand_closed")
local tex_target         = {
    [TARGET_MARIO]       = tex_wanted_m,
    [TARGET_LUIGI]       = tex_wanted_l,
    [TARGET_WARIO]       = tex_wanted_w,
    [TARGET_TOAD]        = tex_wanted_t,
}

-----------
-- Audio --
-----------

local stream_wanted          = audio_stream_load("wanted.ogg")
local sample_wanted_gameover = audio_sample_load("wanted_gameover.ogg")

----------
-- Sync --
----------

g.state = STATE_ROUND_WAITING
g.level = 0
g.time = 0 -- Multiplayer only
g.winner = nil
for i = 0, MAX_PLAYERS - 1 do
    local ps = gPlayerSyncTable[i]
    ps.score = 0   -- Score
    ps.handx = 160 -- Hand X pos
    ps.handy = 120 -- Hand Y pos
    ps.hands = 0   -- Hand state: 0 = open, 1 = closed
end

local function get_level() return (g.level >> 34) end
local function get_target() return (((g.level >> 32) & 0x3) + TARGET_MARIO) end
local function get_seed() return (g.level & 0xFFFFFFFF) end

local function generate_new_level(level)
    local target = math_random(TARGET_MARIO, TARGET_TOAD)
    local seed = math_random(0, 0xFFFFFFFF)
    return (seed | ((target - TARGET_MARIO) << 32) | (level << 34))
end

------------
-- Static --
------------

local sIsMultiPlayer = false

local sStateTimer = 0

local sPlayerTime          = 0
local sPlayerTimeDisplay   = 0
local sPlayerTimeSynced    = 0
local sPlayerStickX        = 0
local sPlayerStickY        = 0
local sPlayerStickMag      = 0
local sPlayerButtonPressed = 0
local sPlayerButtonDown    = 0
local sPlayerPrevMouseX    = 0
local sPlayerPrevMouseY    = 0

local sEventCorrect   = nil
local sEventIncorrect = nil
local sEventGameOver  = nil

local sScreenX = 0
local sScreenY = 0
local sScreenW = 0
local sScreenH = 0

local sLevelLayout = {}
local sLeaderboard = {}
local sHighScores = {}

-----------
-- Utils --
-----------

local function if_then_else(cond, ifTrue, ifFalse)
    if cond then return ifTrue end
    return ifFalse
end

local function clamp(x, a, b)
    if x < a then return a end
    if x > b then return b end
    return x
end

local function relerp(x, a, b, c, d)
    return c + (d - c) * clamp((x - a) / max(1, (b - a)), 0, 1)
end

local function sound_play(soundBits)
    play_sound(soundBits, gGlobalSoundSource)
end

local function play_sounds_correct()
    sound_play(SOUND_CORRECT)
    local sound = SOUND_CHAR_CORRECT[math_random(1, #SOUND_CHAR_CORRECT)]
    vec3f_copy(gMarioStates[0].marioObj.header.gfx.cameraToObject, gGlobalSoundSource)
    play_character_sound_offset(gMarioStates[0], sound.sound, sound.offset << 16)
end

local function play_sounds_incorrect()
    sound_play(SOUND_INCORRECT)
    local sound = SOUND_CHAR_INCORRECT[math_random(1, #SOUND_CHAR_INCORRECT)]
    vec3f_copy(gMarioStates[0].marioObj.header.gfx.cameraToObject, gGlobalSoundSource)
    play_character_sound_offset(gMarioStates[0], sound.sound, sound.offset << 16)
end

function get_uncolored_string(str)
    local s = ""
    local ignore = false
    for c in str:gmatch(".") do
        if c == "\\" then ignore = not ignore
        elseif not ignore then s = s .. c end
    end
    return s
end

---------------
-- Functions --
---------------

local function change_state(updateG, oldVal, newVal)
    if updateG or newVal ~= oldVal then
        sStateTimer = 0
        sPlayerTimeSynced = 0
        if newVal == STATE_ROUND_BEGIN then
            sEventCorrect = nil
        elseif newVal == STATE_ROUND_ENDED then
            play_sounds_correct()
        end
    end
    if updateG then
        g.state = newVal
    end
end

local function change_level(updateG, oldVal, newVal)
    if (updateG or newVal ~= oldVal) and newVal ~= 0 then
        local level = (newVal >> 34)
        local target = (((newVal >> 32) & 0x3) + TARGET_MARIO)
        local seed = (newVal & 0xFFFFFFFF)
        sLevelLayout = generate_level(level, target, seed)
    end
    if updateG then
        g.level = newVal
    end
end

local function change_time(updateG, oldVal, newVal)
    if updateG or (newVal ~= oldVal and sPlayerTimeSynced == 0) then
        sPlayerTime = newVal
        sPlayerTimeSynced = 1
    end
    if updateG then
        g.time = newVal
    end
end

local function init_player_state()
    if sIsMultiPlayer then
        sPlayerTime = g.time_multi
        sPlayerTimeDisplay = g.time_multi
    else
        sPlayerTime = g.time_start
        sPlayerTimeDisplay = g.time_start
    end
    sEventCorrect = nil
    sEventIncorrect = nil
    sEventGameOver = nil
    sLevelLayout = {}
    sLeaderboard = {}
    sHighScores = {}
    ps0.score = 0
    ps0.hands = 0
end

local function reset_player_state(m)
    if network_is_server() then
        local ps = gPlayerSyncTable[m.playerIndex]
        ps.score = 0
        ps.handx = 160
        ps.handy = 120
        ps.hands = 0
    end
end

local function get_character_index_at(x, y)
    local pos3 = { x = x, y = y, z = 0 }
    for i, v in ipairs(sLevelLayout) do
        local dist = vec3f_dist(pos3, { x = v.x, y = v.y, z = 0 })
        if dist < 16 then
            return i
        end
    end
    return 0
end

local function trigger_correct_event(index)

    -- Multi: Increase score
    if sIsMultiPlayer then
        ps0.score = ps0.score + 1
        sEventCorrect = { timer = 0, gain = 1, x = sLevelLayout[index].x, y = sLevelLayout[index].y }

    -- Single: Increase score and gain time
    else
        ps0.score = ps0.score + 1
        sPlayerTime = min(g.time_max, sPlayerTime + g.time_bonus)
        sEventCorrect = { timer = 0, gain = math_floor(g.time_bonus / 30), x = sLevelLayout[index].x, y = sLevelLayout[index].y }
    end

    -- End round
    g.winner = string.upper(get_uncolored_string(np0.name))
    change_state(true, nil, STATE_ROUND_ENDED)
end

local function trigger_incorrect_event(index)
    play_sounds_incorrect()

    -- Multi: Decrease score
    if sIsMultiPlayer then
        if index ~= 0 then
            ps0.score = max(0, ps0.score - 1)
            sEventIncorrect = { timer = 0, loss = 1, x = sLevelLayout[index].x, y = sLevelLayout[index].y, index = index }
        end

    -- Single: Lose time
    else
        sPlayerTime = max(0, sPlayerTime - g.time_penalty)
        if index ~= 0 then
            sEventIncorrect = { timer = 0, loss = math_floor(g.time_penalty / 30), x = sLevelLayout[index].x, y = sLevelLayout[index].y, index = index }
        end
    end

    -- If time is 0, game is over
    if sPlayerTime == 0 then
        sEventGameOver = { timer = 0 }
    end
end

local function get_num_players()
    local n = 0
    for i = 0, MAX_PLAYERS - 1 do
        local np = gNetworkPlayers[i]
        if np.connected then
            n = n + 1
        end
    end
    return n
end

local function update_leaderboard()
    if g.state ~= STATE_ROUND_GAME_OVER then
        sLeaderboard = {}
        for i = 0, MAX_PLAYERS - 1 do
            local np = gNetworkPlayers[i]
            local ps = gPlayerSyncTable[i]
            if np.connected then
                table_insert(sLeaderboard, {
                    index = i,
                    name = get_uncolored_string(np.name),
                    score = math_floor(ps.score),
                    rank = 0,
                })
            end
        end
        table_sort(sLeaderboard, function (v1, v2) return v1.score > v2.score end)
        local rank, score = 1, sLeaderboard[1].score
        for i, v in ipairs(sLeaderboard) do
            if v.score == score then
                v.rank = rank
            else
                v.rank = i
                rank = i
                score = v.score
            end
        end
    end
end

local function load_high_scores()
    sHighScores = {}
    for i = 1, 5 do
        local scoreStr = mod_storage_load("high_score_" .. tostring(i))
        if scoreStr ~= nil then
            local score = tonumber(scoreStr)
            if score ~= nil then
                table_insert(sHighScores, score)
            else
                table_insert(sHighScores, 0)
            end
        else
            table_insert(sHighScores, 0)
        end
    end
end

local function save_high_scores()
    for i = 1, 5 do
        mod_storage_save("high_score_" .. tostring(i), tostring(math_floor(sHighScores[i])))
    end
end

--------------
-- Settings --
--------------

local SETTINGS = {
    level_start  = { default =    1, min = 1, max =   9999, seconds = false }, -- Starting level
    time_start   = { default =  300, min = 1, max = 299970, seconds =  true }, -- Starting time
    time_max     = { default = 1800, min = 1, max = 299970, seconds =  true }, -- Maximum time
    time_bonus   = { default =  150, min = 0, max = 299970, seconds =  true }, -- Time gained by finding the wanted character
    time_penalty = { default =  300, min = 0, max = 299970, seconds =  true }, -- Time lost by clicking on the wrong character
    time_multi   = { default =  900, min = 1, max = 299970, seconds =  true }, -- Multiplayer mode starting time
}

local SETTINGS_NAME = {
    "level_start",
    "time_start",
    "time_max",
    "time_bonus",
    "time_penalty",
    "time_multi",
}

local function value_to_string(setting, v)
    if setting.seconds then return tostring(v / 30) end
    return tostring(math_floor(v))
end

local function string_to_value(setting, s)
    local v = tonumber(s)
    if v ~= nil then
        if setting.seconds then return math_floor(v * 30) end
        return math_floor(v)
    end
    return nil
end

local function load_setting(name, def)
    if network_is_server() then
        local valueStr = mod_storage_load(name)
        if valueStr ~= nil then
            local value = tonumber(valueStr)
            if value ~= nil then
                local setting = SETTINGS[name]
                if setting.min <= value and value <= setting.max then
                    return math_floor(value)
                end
            end
        end
    end
    return def
end

local function save_setting(name, value)
    if network_is_server() then
        mod_storage_save(name, tostring(math_floor(value)))
    end
end

local function on_wanted_command(msg)

    -- No message: help command
    if msg == nil or msg == "" then
        msg = "\\#00FF00\\---- HELP ----\\#\\\n"
        msg = msg .. "\\#008000\\/wanted scores \\#FFFFFF\\- Display scores\\#\\\n"
        msg = msg .. "\\#008000\\/wanted settings \\#FFFFFF\\- Display current settings\\#\\\n"
        if network_is_server() then
            msg = msg .. "\\#008000\\/wanted <setting> <value> \\#FFFFFF\\- Set <setting> to <value>\\#\\\n"
            msg = msg .. "\\#008000\\/wanted reset \\#FFFFFF\\- Reset all settings to their default value\\#\\\n"
        end
        djui_chat_message_create(msg)
        return true
    end

    -- Retrieve arguments
    local args = {}
    for s in string.gmatch(msg, "%S+") do
        table_insert(args, s)
    end

    -- Check for the scores command
    if #args == 1 and args[1] == "scores" then
        load_high_scores()
        msg = "\\#FFFF40\\---- HIGH SCORES ----\\#\\\n"
        for i, score in ipairs(sHighScores) do
            msg = msg .. "\\#FFFFFF\\" .. tostring(i) .. RANK_STRING[min(i, 4)] .. ":  " .. tostring(score) .. "\\#\\\n"
        end
        djui_chat_message_create(msg)
        return true
    end

    -- Check for the settings command
    if #args == 1 and args[1] == "settings" then
        msg = "\\#8080FF\\---- GAME SETTINGS ----\\#\\\n"
        for _, name in ipairs(SETTINGS_NAME) do
            msg = msg .. "\\#40C0FF\\" .. name .. ": \\#FFFF40\\" .. value_to_string(SETTINGS[name], g[name]) .. "\\#\\\n"
        end
        djui_chat_message_create(msg)
        return true
    end

    -- [Host only] Modify settings
    if network_is_server() then
        if g.state == STATE_ROUND_WAITING then

            -- Check for the reset command
            if #args == 1 and args[1] == "reset" then
                for _, name in pairs(SETTINGS_NAME) do
                    local setting = SETTINGS[name]
                    on_wanted_command(name .. " " .. value_to_string(setting, setting.default))
                end
                return true
            end

            -- Check number of args
            if #args < 2 then
                djui_chat_message_create("\\#FF4040\\Not enough arguments. Requires setting name and value.\\#\\")
                return true
            end
            if #args > 2 then
                djui_chat_message_create("\\#FF4040\\Too many arguments. Requires only setting name and value.\\#\\")
                return true
            end

            -- Check setting name
            local name = args[1]
            local setting = SETTINGS[name]
            if setting == nil then
                djui_chat_message_create("\\#FF4040\\Unknown setting: " .. name .. "\\#\\")
                return true
            end

            -- Check value type
            local valueStr = args[2]
            local value = string_to_value(setting, valueStr)
            if value == nil then
                djui_chat_message_create("\\#FF4040\\" .. valueStr .. " is not a number.\\#\\")
                return true
            end

            -- Check value validity
            if value < setting.min or value > setting.max then
                djui_chat_message_create("\\#FF4040\\" .. valueStr .. " is not valid for setting " .. name .. ":\nValue must be between " .. value_to_string(setting, setting.min) .. " and " .. value_to_string(setting, setting.max) .. ".\\#\\")
                return true
            end

            -- Ok
            g[name] = value
            save_setting(name, value)
            djui_chat_message_create("\\#20C020\\" .. name .. " set to " .. value_to_string(setting, value) .. ".\\#\\")
            return true
        else
            djui_chat_message_create("\\#FF4040\\Game settings cannot be modified during the game.\\#\\")
            return true
        end
    end
    return false
end

if network_is_server() then
    hook_chat_command("wanted", "- View high scores, show or modify game settings.", on_wanted_command)
else
    hook_chat_command("wanted", "- View high scores or show game settings.", on_wanted_command)
end

for name, setting in pairs(SETTINGS) do
    g[name] = load_setting(name, setting.default)
end

-------------
-- Updates --
-------------

local function disable_inputs(m)
    m.controller.rawStickX = 0
    m.controller.rawStickY = 0
    m.controller.stickX = 0
    m.controller.stickY = 0
    m.controller.stickMag = 0
    m.controller.buttonPressed = 0
    m.controller.buttonDown = (m.controller.buttonDown & (A_BUTTON | START_BUTTON))
    m.controller.extStickX = 0
    m.controller.extStickY = 0
    set_mario_action(m, ACT_IDLE, 0)
    m.actionState = 0
    m.actionTimer = 0
end

local function clear_screen()
    for _, behaviorId in ipairs({ id_bhvTree, id_bhvBird, id_bhvBirdsSoundLoop }) do
        local obj = obj_get_first_with_behavior_id(behaviorId)
        while obj ~= nil do
            obj_mark_for_deletion(obj)
            obj = obj_get_next_with_same_behavior_id(obj)
        end
    end
    for i = 0, 99 do stop_background_music(i) end
    stop_shell_music()
    stop_cap_music()
    hud_hide()
    djui_hud_set_resolution(RESOLUTION_DJUI)
    djui_hud_set_color(0x00, 0x00, 0x00, 0xFF)
    djui_hud_set_font(FONT_HUD)
    djui_hud_render_rect(-1, -1, djui_hud_get_screen_width() + 2, djui_hud_get_screen_height() + 2)
    djui_hud_set_resolution(RESOLUTION_N64)
end

local function split_screen()
    local sw = djui_hud_get_screen_width() - 80
    if sw < 320 then
        sScreenW = sw
        sScreenH = (sw * 240) / 320
        sScreenX = 80
        sScreenY = (240 - sScreenH) / 2
    else
        sScreenW = 320
        sScreenH = 240
        sScreenX = 80 + (sw - 320) / 2
        sScreenY = 0
    end
end

local function render_screen_left()
    djui_hud_set_font(FONT_HUD)

    -- Background
    djui_hud_set_color(0x00, 0x00, 0x00, 0xFF)
    djui_hud_render_rect(0, 0, 80, 240)

    -- Wanted wall
    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
    djui_hud_render_texture(tex_wanted_wall, 0, 0, 80 / tex_wanted_wall.width, 80 / tex_wanted_wall.height)

    -- Don't draw anything else if the game has not started yet
    local state = g.state
    if state == STATE_ROUND_WAITING then
        return
    end

    -- Target's face
    local target = get_target()
    if target ~= TARGET_NONE and (state ~= STATE_ROUND_BEGIN or sStateTimer >= 20) then
        local tex = tex_target[target]
        djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
        djui_hud_render_texture(tex, 25, 21, 30 / tex.width, 30 / tex.height)
    end

    -- Black circle
    local circle_radius
    if state == STATE_ROUND_BEGIN then
        circle_radius = if_then_else(sStateTimer < 20, relerp(sStateTimer, 0, 15, 60, 0), relerp(sStateTimer, 20, 25, 0, 25))
    elseif state == STATE_ROUND_STARTED then
        circle_radius = 25
    elseif state == STATE_ROUND_ENDED then
        circle_radius = relerp(sStateTimer, 0, 15, 25, 60)
    else
        circle_radius = 60
    end
    local circle_xy = 40 - circle_radius
    djui_hud_set_color(0x00, 0x00, 0x00, 0xFF)
    djui_hud_render_texture(tex_wanted_circle, circle_xy, circle_xy, 2 * circle_radius / tex_wanted_circle.width, 2 * circle_radius / tex_wanted_circle.height)
    if circle_xy > 0 then
        djui_hud_render_rect(0, 0, 80, circle_xy)
        djui_hud_render_rect(0, 80 - circle_xy, 80, circle_xy)
        djui_hud_render_rect(0, 0, circle_xy, 80)
        djui_hud_render_rect(80 - circle_xy, 0, circle_xy, 80)
    end

    -- Update time display
    if sIsMultiPlayer then
        sPlayerTimeDisplay = sPlayerTime
    elseif sPlayerTimeDisplay < sPlayerTime and (sStateTimer > 30 or state ~= STATE_ROUND_ENDED) and (sStateTimer % 2) == 0 then
        sPlayerTimeDisplay = min(sPlayerTimeDisplay + 30, sPlayerTime)
        sound_play(SOUND_GENERAL_COIN)
    elseif sPlayerTimeDisplay > sPlayerTime then
        sPlayerTimeDisplay = sPlayerTime
    end

    -- Time
    local time_text = "TIME"
    local time_text_w = djui_hud_measure_text(time_text)
    local time_text_x = 40 - time_text_w / 2
    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
    djui_hud_print_text(time_text, time_text_x, 110, 1)
    local time = tostring(math_floor((sPlayerTimeDisplay + 29) / 30))
    local time_w = djui_hud_measure_text(time)
    local time_x = 40 - time_w / 2
    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
    djui_hud_print_text(time, time_x, 130, 1)

    -- Score
    local score_text = "SCORE"
    local score_text_w = djui_hud_measure_text(score_text)
    local score_text_x = 40 - score_text_w / 2
    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
    djui_hud_print_text(score_text, score_text_x, 170, 1)
    local score = "* " .. tostring(max(0, math_floor(ps0.score)))
    local score_w = djui_hud_measure_text(score)
    local score_x = 40 - score_w / 2
    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
    djui_hud_print_text(score, score_x, 190, 1)
end

local function render_screen_right()
    local host = network_is_server()
    local ratio = sScreenH / 240
    local state = g.state

    -- Game is over
    if state == STATE_ROUND_GAME_OVER then

        -- Display high scores
        if not sIsMultiPlayer then
            if sStateTimer <= 1 then
                load_high_scores()
                table_insert(sHighScores, math_floor(ps0.score))
                table_sort(sHighScores, function (v1, v2) return v1 > v2 end)
                save_high_scores()
            end
            local new_high_score = 0

            -- High scores
            djui_hud_set_font(FONT_HUD)
            local highscores_text = "HIGH SCORES"
            local highscores_text_w = djui_hud_measure_text(highscores_text)
            local highscores_text_x = (djui_hud_get_screen_width() + 80 - highscores_text_w) / 2
            djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
            djui_hud_print_text(highscores_text, highscores_text_x, 55, 1)
            for i = 1, 5 do
                if sStateTimer >= (5 - i) * 15 then
                    local score = sHighScores[i]
                    local score_text = tostring(score)
                    local score_text_w = djui_hud_measure_text(score_text)
                    local score_text_x = (djui_hud_get_screen_width() + 180) / 2 - score_text_w
                    if sStateTimer >= 80 and ps0.score > 0 and ps0.score == score and (new_high_score == 0 or new_high_score == i) then
                        new_high_score = i
                        djui_hud_set_color(0xFF, 0xFF, 0xFF, if_then_else(sStateTimer % 30 < 15, 0xFF, 0x00))
                    else
                        djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
                    end
                    djui_hud_print_text(score_text, score_text_x, 60 + 20 * i, 1)
                    djui_hud_print_text("* x", (djui_hud_get_screen_width() - 20) / 2, 60 + 20 * i, 1)
                end
            end

            -- New high score
            if new_high_score ~= 0 then
                if sStateTimer == 80 then play_star_fanfare() end
                local newhs_text = "NEW HIGH SCORE"
                local newhs_scale = 1.5 * sins(0x6000 * relerp(sStateTimer, 80, 100, 0, 1))
                local newhs_text_w = djui_hud_measure_text(newhs_text) * newhs_scale
                local newhs_text_x = (djui_hud_get_screen_width() + 80 - newhs_text_w) / 2
                djui_hud_set_color(0xFF, 0xFF, 0xFF, if_then_else(sStateTimer < 100 or sStateTimer % 30 < 15, 0xFF, 0x00))
                djui_hud_print_text(newhs_text, newhs_text_x, 20, newhs_scale)
            end

            -- Press Start to play again
            if sStateTimer > 150 then
                sStateTimer = sStateTimer + 900
                djui_hud_set_font(FONT_MENU)
                local wait_text = "PRESS START TO PLAY AGAIN"
                local wait_text_w = djui_hud_measure_text(wait_text) * 0.3
                local wait_text_x = (djui_hud_get_screen_width() + 80 - wait_text_w) / 2
                djui_hud_set_color(0xFF, 0xFF, 0xFF, if_then_else(sStateTimer % 30 < 15, 0xFF, 0x00))
                djui_hud_print_text(wait_text, wait_text_x, 200, 0.3)
                return
            end

        -- Display final leaderboard
        else
            local framesToWait = 20 + (#sLeaderboard - 1) * 10
            local isWinning = false

            -- Leaderboard
            djui_hud_set_font(FONT_HUD)
            local leaderboard_text = "LEADERBOARD"
            local leaderboard_text_w = djui_hud_measure_text(leaderboard_text)
            local leaderboard_text_x = (djui_hud_get_screen_width() + 80 - leaderboard_text_w) / 2
            djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
            djui_hud_print_text(leaderboard_text, leaderboard_text_x, 15, 1)
            djui_hud_set_font(FONT_NORMAL)
            for i, v in ipairs(sLeaderboard) do
                if sStateTimer >= (#sLeaderboard - i) * 10 then
                    local score_text = tostring(v.score)
                    local score_text_w = djui_hud_measure_text(score_text) * 0.3
                    local score_text_x = (djui_hud_get_screen_width() + 220) / 2 - score_text_w
                    local score_text_b = if_then_else(v.rank == 1, 0x00, 0xFF)
                    local score_text_a = if_then_else(v.index == 0, if_then_else(sStateTimer % 30 < 15, 0xFF, 0x00), 0xFF)
                    local rank_text = tostring(v.rank) .. RANK_STRING[min(v.rank, 4)]
                    local rank_text_x = (djui_hud_get_screen_width() - 60) / 2
                    djui_hud_set_color(0xFF, 0xFF, score_text_b, score_text_a)
                    djui_hud_print_text(rank_text, rank_text_x, 30 + 10 * i, 0.3)
                    djui_hud_print_text(v.name, rank_text_x + 20, 30 + 10 * i, 0.3)
                    djui_hud_print_text(score_text, score_text_x, 30 + 10 * i, 0.3)
                    if v.index == 0 and v.rank == 1 then
                        isWinning = true
                    end
                end
            end

            -- Winner/loser
            if sStateTimer >= framesToWait and sStateTimer < framesToWait + 120 then
                if sStateTimer == framesToWait then
                    if isWinning then
                        play_star_fanfare()
                    else
                        audio_sample_play(sample_wanted_gameover, gGlobalSoundSource, 1.0)
                    end
                end
                djui_hud_set_font(FONT_MENU)
                local winlose_text = if_then_else(isWinning, "YOU WIN!", "YOU LOSE")
                local winlose_scale = 1.25 * sins(0x6000 * relerp(sStateTimer, framesToWait, framesToWait + 20, 0, 1))
                local winlose_text_w = djui_hud_measure_text(winlose_text) * winlose_scale
                local winlose_text_x = sScreenX + (sScreenW - winlose_text_w) / 2
                local winlose_text_y = sScreenY + (sScreenH - 64 * winlose_scale) / 2
                if isWinning then
                    djui_hud_set_color(0xFF, 0x40, 0x40, 0xFF)
                else
                    djui_hud_set_color(0x00, 0x80, 0xFF, 0xFF)
                end
                djui_hud_print_text(winlose_text, winlose_text_x, winlose_text_y, winlose_scale)
            end

            -- Press Start to play again
            if host and sStateTimer > framesToWait + 120 then
                sStateTimer = sStateTimer + 900
                djui_hud_set_font(FONT_MENU)
                local wait_text = "PRESS START TO PLAY AGAIN"
                local wait_text_w = djui_hud_measure_text(wait_text) * 0.3
                local wait_text_x = (djui_hud_get_screen_width() + 80 - wait_text_w) / 2
                djui_hud_set_color(0xFF, 0xFF, 0xFF, if_then_else(sStateTimer % 30 < 15, 0xFF, 0x00))
                djui_hud_print_text(wait_text, wait_text_x, 210, 0.3)
                return
            end
        end
        return
    end

    -- Wait for the host to press Start
    if state == STATE_ROUND_WAITING then
        djui_hud_set_font(FONT_MENU)
        local wait_text = if_then_else(host, "PRESS START TO PLAY", "WAITING FOR THE HOST TO START")
        local wait_text_w = djui_hud_measure_text(wait_text) * 0.3
        local wait_text_x = (djui_hud_get_screen_width() + 80 - wait_text_w) / 2
        djui_hud_set_color(0xFF, 0xFF, 0xFF, if_then_else(sStateTimer % 30 < 15, 0xFF, 0x00))
        djui_hud_print_text(wait_text, wait_text_x, 110, 0.3)
        return
    end

    -- Background
    if state == STATE_ROUND_ENDED then
        djui_hud_set_color(0xFF, 0xFF, 0x40, 0xFF)
        djui_hud_render_rect(sScreenX, sScreenY, sScreenW, sScreenH)
    else
        djui_hud_set_color(0x00, 0x00, 0x00, 0xFF)
        djui_hud_render_rect(sScreenX, sScreenY, sScreenW, sScreenH)
    end

    -- Render sprites
    if state == STATE_ROUND_STARTED or state == STATE_ROUND_ENDED then
        for i, v in ipairs(sLevelLayout) do
            if state ~= STATE_ROUND_ENDED or v.c == get_target() then
                local tex = tex_target[v.c]
                local sx = ratio * 40 / tex.width
                local sy = ratio * 40 / tex.height
                local x = sScreenX + v.x * ratio
                local y = sScreenY + v.y * ratio
                local dx = sx * tex.width / 2
                local dy = sy * tex.height / 2
                if sEventIncorrect ~= nil and sEventIncorrect.index == i then
                    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF * (math_floor(sEventIncorrect.timer / 2) % 2))
                else
                    djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF)
                end
                djui_hud_render_texture(tex, x - dx, y - dy, sx, sy)
            end
        end
    end

    -- Draw borders
    djui_hud_set_color(0x00, 0x00, 0x00, 0xFF)
    if sScreenX > 80 then
        local border_w = sScreenX - 80
        djui_hud_render_rect(80, -1, border_w, 242)
        djui_hud_render_rect(djui_hud_get_screen_width() - border_w, -1, border_w + 1, 242)
    end
    if sScreenY > 0 then
        local border_h = sScreenY
        djui_hud_render_rect(80, 0, djui_hud_get_screen_width() - 79, border_h)
        djui_hud_render_rect(80, 240 - border_h, djui_hud_get_screen_width() - 79, border_h + 1)
    end

    -- Render hands
    for i = MAX_PLAYERS - 1, 0, -1 do
        local np = gNetworkPlayers[i]
        local ps = gPlayerSyncTable[i]
        if np.connected then
            local x = sScreenX + ps.handx * ratio
            local y = sScreenY + ps.handy * ratio
            local s = if_then_else(i == 0, 0.5, 0.4) * ratio
            local t = if_then_else(ps.hands == 1, tex_hand_closed, tex_hand_open)
            local a = if_then_else(i == 0, 0xFF, 0x80)
            djui_hud_set_color(0xFF, 0xFF, 0xFF, a)
            djui_hud_render_texture(t, x - 2 * ratio, y - 4 * ratio, s, s)
        end
    end

    -- Render gain effect
    if sEventCorrect ~= nil then
        sEventCorrect.timer = sEventCorrect.timer + 1
        if sEventCorrect.timer <= 30 then
            djui_hud_set_font(FONT_MENU)
            local n_text = "+" .. tostring(sEventCorrect.gain)
            local n_text_w = djui_hud_measure_text(n_text) * 0.4
            local n_text_x = clamp(sScreenX + ratio * sEventCorrect.x - n_text_w / 1.6, 0, djui_hud_get_screen_width() - 30)
            local n_text_y = clamp(sScreenY + ratio * sEventCorrect.y - 32 * 0.4 - relerp(sEventCorrect.timer, 0, 10, 0, 20), 0, 215)
            djui_hud_set_color(0xFF, 0x40, 0x40, 0xFF)
            djui_hud_print_text(n_text, n_text_x, n_text_y, 0.4)
        end
    end

    -- Render loss effect
    if sEventIncorrect ~= nil then
        sEventIncorrect.timer = sEventIncorrect.timer + 1
        if sEventIncorrect.timer <= 30 then
            djui_hud_set_font(FONT_MENU)
            local n_text = "-" .. tostring(sEventIncorrect.loss)
            local n_text_w = djui_hud_measure_text(n_text) * 0.4
            local n_text_x = clamp(sScreenX + ratio * sEventIncorrect.x - n_text_w / 1.6, 0, djui_hud_get_screen_width() - 30)
            local n_text_y = clamp(sScreenY + ratio * sEventIncorrect.y - 32 * 0.4 - relerp(sEventIncorrect.timer, 0, 10, 20, 0), 0, 215)
            djui_hud_set_color(0x00, 0x80, 0xFF, 0xFF)
            djui_hud_print_text(n_text, n_text_x, n_text_y, 0.4)
        else
            sEventIncorrect = nil
        end
    end

    -- Render round ended message
    if sIsMultiPlayer and state == STATE_ROUND_ENDED and sStateTimer > 30 then
        djui_hud_set_font(FONT_MENU)
        local winner_text1
        if sEventCorrect ~= nil then
            winner_text1 = "YOU"
            djui_hud_set_color(0xFF, 0xE0, 0xE0, 0xFF)
        elseif g.winner ~= nil then
            winner_text1 = g.winner
            djui_hud_set_color(0xC0, 0xE0, 0xFF, 0xFF)
        else
            winner_text1 = "SOMEONE"
            djui_hud_set_color(0xC0, 0xE0, 0xFF, 0xFF)
        end
        winner_text1 = winner_text1 .. " WON THE ROUND!"
        winner_text2 = string.upper(sLeaderboard[1].name) ..  " IS LEADING WITH " .. tostring(sLeaderboard[1].score) .. " POINTS!"
        local winner_text1_w = djui_hud_measure_text(winner_text1) * 0.35
        local winner_text2_w = djui_hud_measure_text(winner_text2) * 0.25
        local winner_text1_x = (djui_hud_get_screen_width() + 80 - winner_text1_w) / 2
        local winner_text2_x = (djui_hud_get_screen_width() + 80 - winner_text2_w) / 2
        djui_hud_print_text(winner_text1, winner_text1_x, 95, 0.35)
        djui_hud_set_color(0xFF, 0xFF, 0x80, 0xFF)
        djui_hud_print_text(winner_text2, winner_text2_x, 125, 0.25)
    end

    -- Render Game Over effect
    if sEventGameOver ~= nil then
        sEventGameOver.timer = sEventGameOver.timer + 1
        if sEventGameOver.timer >= 150 then
            if host then
                change_state(true, nil, STATE_ROUND_GAME_OVER)
            end
        elseif sEventGameOver.timer == 60 then
            audio_sample_play(sample_wanted_gameover, gGlobalSoundSource, 1.0)
        elseif sEventGameOver.timer > 60 then
            djui_hud_set_font(FONT_MENU)
            local gameover_text = "GAME OVER"
            local gameover_scale = 1.2 * sins(0x6000 * relerp(sEventGameOver.timer, 60, 80, 0, 1))
            local gameover_text_w = djui_hud_measure_text(gameover_text) * gameover_scale
            local gameover_text_x = sScreenX + (sScreenW - gameover_text_w) / 2
            local gameover_text_y = sScreenY + (sScreenH - 64 * gameover_scale) / 2
            djui_hud_set_color(0xB0, 0x80, 0xC0, 0xFF)
            djui_hud_print_text(gameover_text, gameover_text_x, gameover_text_y, gameover_scale)
        end
    end
end

local function update_game()
    local host = network_is_server()
    local state = g.state
    local target = get_target()
    np0.overrideModelIndex = TARGET_CT[target]
    sStateTimer = sStateTimer + 1

    -- Tell the game to switch immediately to multiplayer mode as soon as another player joins
    if host then
        if state == STATE_ROUND_WAITING then
            sIsMultiPlayer = get_num_players() > 1
        elseif not sIsMultiPlayer and get_num_players() > 1 then
            change_state(true, nil, STATE_ROUND_WAITING)
            sIsMultiPlayer = true
        end
    else
        sIsMultiPlayer = true
    end

    -- Process controller inputs
    if sPlayerStickMag > 0 then
        ps0.handx = clamp(ps0.handx + sPlayerStickX / 4, 0, 319)
        ps0.handy = clamp(ps0.handy - sPlayerStickY / 4, 0, 239)
    end
    if ps0.hands ~= 2 then
        ps0.hands = if_then_else((sPlayerButtonDown & A_BUTTON) ~= 0, 1, 0)
    end

    -- Process mouse inputs
    djui_hud_set_resolution(RESOLUTION_DJUI)
    local mx = djui_hud_get_mouse_x() / djui_hud_get_screen_width()
    local my = djui_hud_get_mouse_y() / djui_hud_get_screen_height()
    if sPlayerPrevMouseX ~= mx or sPlayerPrevMouseY ~= my then
        sPlayerPrevMouseX = mx
        sPlayerPrevMouseY = my
        if sStateTimer > 1 then
            djui_hud_set_resolution(RESOLUTION_N64)
            mx = mx * djui_hud_get_screen_width()
            my = my * djui_hud_get_screen_height()
            ps0.handx = clamp((mx - sScreenX) * (240 / sScreenH), 0, 319)
            ps0.handy = clamp((my - sScreenY) * (240 / sScreenH), 0, 239)
        end
    end
    djui_hud_set_resolution(RESOLUTION_N64)

    -- Wait for the host to press Start
    if state == STATE_ROUND_WAITING then
        init_player_state()
        if host and (sPlayerButtonPressed & START_BUTTON) ~= 0 then
            change_state(true, nil, STATE_ROUND_BEGIN)
            change_time(true, nil, sPlayerTime)
        end

    -- Generate level and reveal target
    elseif state == STATE_ROUND_BEGIN then
        if host and sStateTimer == 1 then
            local level = generate_new_level(max(g.level_start, get_level() + 1))
            change_level(true, nil, level)
        end
        if sStateTimer == 20 then
            sound_play(SOUND_TARGET_REVEALED)
        end
        if host and sStateTimer > 25 then
            change_state(true, nil, STATE_ROUND_STARTED)
        end

    -- Round
    elseif state == STATE_ROUND_STARTED then
        if sPlayerTime > 0 then
            sPlayerTime = max(0, sPlayerTime - 1)
            if sPlayerTime > 0 and (sPlayerButtonPressed & A_BUTTON) ~= 0 then
                local index = get_character_index_at(ps0.handx, ps0.handy)
                if index ~= 0 then
                    if sLevelLayout[index].c == target then
                        trigger_correct_event(index)
                    else
                        trigger_incorrect_event(index)
                    end
                end
            end
            if sPlayerTime == 0 then
                trigger_incorrect_event(0)
            else
                local x = (sPlayerTime % 30)
                if x == 0 or (sPlayerTime < 90 and (x == 27 or x == 24)) then
                    sound_play(SOUND_TIME_TICK)
                end
            end
        elseif sIsMultiPlayer and sEventGameOver == nil then
            trigger_incorrect_event(0)
        end
        change_time(true, nil, sPlayerTime)
        update_level(sLevelLayout, sStateTimer)

    -- Target found
    elseif state == STATE_ROUND_ENDED then
        if host and sStateTimer > if_then_else(sIsMultiPlayer, 90, 60) then
            change_state(true, nil, STATE_ROUND_BEGIN)
            change_time(true, nil, sPlayerTime)
        end

    -- Game is over
    elseif state == STATE_ROUND_GAME_OVER then
        if host and sStateTimer > 1000 and (sPlayerButtonPressed & START_BUTTON) ~= 0 then
            change_state(true, nil, STATE_ROUND_WAITING)
            change_level(true, nil, 0)
        end
    end

    -- Update leaderboard
    if sIsMultiPlayer then
        update_leaderboard()
        for _, v in ipairs(sLeaderboard) do
            local np = gNetworkPlayers[v.index]
            local desc = tostring(v.rank) .. RANK_STRING[min(v.rank, 4)] .. " - " .. tostring(v.score)
            if v.rank == 1 then
                network_player_set_description(np, desc, 0xFF, 0xFF, 0x00, 0xFF)
            else
                network_player_set_description(np, desc, 0xFF, 0xFF, 0xFF, 0xFF)
            end
        end
    end
end

----------
-- Init --
----------

audio_stream_play(stream_wanted, true, 0.75)
audio_stream_set_looping(stream_wanted, true)

-----------
-- Hooks --
-----------

local function before_mario_update(m)
    if m.playerIndex == 0 then
        sPlayerStickX = m.controller.stickX
        sPlayerStickY = m.controller.stickY
        sPlayerStickMag = m.controller.stickMag
        sPlayerButtonPressed = m.controller.buttonPressed
        sPlayerButtonDown = m.controller.buttonDown
    end
    disable_inputs(m)
end

local function mario_update(m)
    disable_inputs(m)
end

local function on_hud_render()
    update_game()
    clear_screen()
    split_screen()
    local state = g.state
    if state == STATE_ROUND_BEGIN or state == STATE_ROUND_ENDED or state == STATE_ROUND_GAME_OVER then
        render_screen_left()
        render_screen_right()
    else
        render_screen_right()
        render_screen_left()
    end
end

hook_event(HOOK_BEFORE_MARIO_UPDATE, before_mario_update)
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_ON_PLAYER_CONNECTED, reset_player_state)
hook_event(HOOK_ON_PLAYER_DISCONNECTED, reset_player_state)
hook_on_sync_table_change(gGlobalSyncTable, "state", false, change_state)
hook_on_sync_table_change(gGlobalSyncTable, "level", false, change_level)
hook_on_sync_table_change(gGlobalSyncTable, "time", false, change_time)
