------------
-- Locals --
------------

local table_insert = table.insert
local math_floor = math.floor
local math_random = math.random
local coss = coss
local sins = sins

---------------
-- Constants --
---------------

local MT_NONE = 0
local MT_LINE = 1
local MT_SIN  = 2

-- Density increases every 10 levels
local LEVEL_DENSITY = {
    [1] = { [true] = { from =  96, to = 128 }, [false] = { from =  96, to = 128 } }, -- level 21 to 30
    [2] = { [true] = { from =  96, to = 128 }, [false] = { from =  96, to = 160 } }, -- level 31 to 40
    [3] = { [true] = { from =  96, to = 160 }, [false] = { from = 128, to = 160 } }, -- level 41 to 50
    [4] = { [true] = { from = 128, to = 160 }, [false] = { from = 128, to = 180 } }, -- level 51 to 60
    [5] = { [true] = { from = 128, to = 180 }, [false] = { from = 140, to = 180 } }, -- level 61 to 70
    [6] = { [true] = { from = 140, to = 180 }, [false] = { from = 140, to = 200 } }, -- level 71 to 80
    [7] = { [true] = { from = 140, to = 200 }, [false] = { from = 160, to = 200 } }, -- level 81 to 90
    [8] = { [true] = { from = 160, to = 200 }, [false] = { from = 180, to = 200 } }, -- level 91 to 100
    [9] = { [true] = { from = 180, to = 200 }, [false] = { from = 180, to = 200 } }, -- level 101+
}

---------------
-- Functions --
---------------

local function default(x, def)
    if x == nil then return def end
    return x
end

local function new_spot(x, y)
    return {
        x = x,
        y = y,
    }
end

local function new_template(c, mt, b, v, a, sa, sf)
    return {
        c = c,
        mt = default(mt, MT_NONE),
        b = default(b, false),
        v = default(v, 0),
        a = default(a, 0),
        sa = default(sa, 0),
        sf = default(sf, 0),
    }
end

local function generate_templates(templates, f)
    for c = 1, 4 do
        table_insert(templates, f(c))
    end
end

local function from_spot_and_template(spot, template)
    return {
        x = spot.x,
        y = spot.y,
        c = template.c,
        mt = template.mt,
        b = template.b,
        v = type(template.v) == "function" and template.v() or template.v,
        a = type(template.a) == "function" and template.a() or template.a,
        sa = type(template.sa) == "function" and template.sa() or template.sa,
        sf = type(template.sf) == "function" and template.sf() or template.sf,
    }
end

local function table_shuffle(t)
    for i = #t, 2, -1 do
        local j = math_random(#t)
        t[i], t[j] = t[j], t[i]
    end
end

local function random_speed()
    return 1.0 + 1.5 * math_random()
end

local function random_angle(angles)
    if angles == nil then return math_random(0, 0xFFFF) end
    return angles[math_random(#angles)]
end

local function random_sine_amplitude()
    return 10 + 20 * math_random()
end

local function random_sine_frequency()
    return math_random(0x200, 0x400)
end

local function random_spot(spots)
    local x, y, ok = 0, 0, false
    while not ok do
        ok = true
        x, y = math_random(0, 319), math_random(0, 239)
        for _, spot in ipairs(spots) do
            local d2 = (x - spot.x)^2 + (y - spot.y)^2
            if d2 < 250 then
                ok = false
                break
            end
        end
    end
    return new_spot(x, y)
end

local function generate_random_spots(count)
    spots = {}
    for _ = 1, count do
        table_insert(spots, random_spot(spots))
    end
    return spots
end

local function generate_layout(level, target, spots, templates)
    layout = {}
    table_shuffle(spots)
    table_shuffle(templates)

    -- Move the target template to first position
    for i = 2, #templates do
        if templates[i].c == target then
            templates[i], templates[1] = templates[1], templates[i]
        end
    end

    -- Add target
    table_insert(layout, from_spot_and_template(spots[1], templates[1]))

    -- Generate layout
    for i = 2, #spots do
        local j = 2 + (i % (#templates - 1)) -- Don't select the target template
        table_insert(layout, from_spot_and_template(spots[i], templates[j]))
    end

    -- From level 1 to 7, target is rendered above all other characters
    if level <= 7 then
        table_insert(layout, from_spot_and_template(spots[1], templates[1]))
    end

    -- Done
    return layout
end

function generate_level(level, target, seed)
    math.randomseed(seed)
    spots = {}
    templates = {}
    if level < 21 then

        -- 2x2
        if level == 1 then
            generate_templates(templates, function (c) return new_template(c) end)
            for x = 140, 180, 40 do
                for y = 100, 140, 40 do
                    table_insert(spots, new_spot(x, y))
                end
            end

        -- 4x4
        elseif level == 2 then
            generate_templates(templates, function (c) return new_template(c) end)
            for x = 100, 220, 40 do
                for y = 60, 180, 40 do
                    table_insert(spots, new_spot(x, y))
                end
            end

        -- 8x6
        elseif level == 3 then
            generate_templates(templates, function (c) return new_template(c) end)
            for x = 20, 300, 40 do
                for y = 20, 220, 40 do
                    table_insert(spots, new_spot(x, y))
                end
            end

        -- Random non moving spots
        elseif level == 4 or level == 5 or level == 7 or level == 9 or level == 13 or level == 15 or level == 17 or level == 18 or level == 20 then
            generate_templates(templates, function (c) return new_template(c) end)
            spots = generate_random_spots(4 * (12 + level))

        -- 8x6 + 7x5
        elseif level == 6 then
            generate_templates(templates, function (c) return new_template(c) end)
            for x = 20, 300, 40 do
                for y = 20, 220, 40 do
                    table_insert(spots, new_spot(x, y))
                end
            end
            for x = 40, 280, 40 do
                for y = 40, 200, 40 do
                    table_insert(spots, new_spot(x, y))
                end
            end

        -- 8x1, but only the top half of the faces can be seen
        elseif level == 8 then
            generate_templates(templates, function (c) return new_template(c) end)
            for x = 20, 300, 40 do
                table_insert(spots, { x = x, y = 245 })
            end

        -- 8x1, but only the bottom half of the faces can be seen
        elseif level == 10 then
            generate_templates(templates, function (c) return new_template(c) end)
            for x = 20, 300, 40 do
                table_insert(spots, { x = x, y = -5 })
            end

        -- Random spots moving in a straight line
        elseif level == 11 or level == 16 then
            generate_templates(templates, function (c) return new_template(c, MT_LINE, false, random_speed(), random_angle()) end)
            spots = generate_random_spots(4 * (12 + level))

        -- Random spots moving in a sine wave (up or down)
        elseif level == 12 then
            generate_templates(templates, function (c) return new_template(c, MT_SIN, false, random_speed(), random_angle({ 0x4000 }), random_sine_amplitude(), random_sine_frequency()) end)
            spots = generate_random_spots(4 * (12 + level))

        -- Random spots moving in a straight line but bounce on edges
        elseif level == 14 then
            generate_templates(templates, function(c) return new_template(c, MT_LINE, true, random_speed(), random_angle) end)
            spots = generate_random_spots(4 * (12 + level))

        -- Random spots moving in a sine wave (any direction)
        elseif level == 19 then
            generate_templates(templates, function (c) return new_template(c, MT_SIN, false, random_speed(), random_angle(), random_sine_amplitude(), random_sine_frequency()) end)
            spots = generate_random_spots(4 * (12 + level))
        end
    else
        local levelType = math_random(level >= 41 and 100 or 60)
        local levelDensity = LEVEL_DENSITY[min(math_floor((level - 11) / 10), 8)][levelType <= 20]
        local numSpots = math_random(levelDensity.from, levelDensity.to)

        -- 1 - 20: Random non moving spots
        if levelType <= 20 then
            generate_templates(templates, function(c) return new_template(c) end)
            spots = generate_random_spots(numSpots)

        -- 21 - 35: Random spots moving in a straight line
        elseif levelType <= 35 then
            generate_templates(templates, function (c) return new_template(c, MT_LINE, false, random_speed(), random_angle()) end)
            spots = generate_random_spots(numSpots)

        -- 36 - 50: Random spots moving in a sine wave
        elseif levelType <= 50 then
            generate_templates(templates, function (c) return new_template(c, MT_SIN, false, random_speed(), random_angle(), random_sine_amplitude(), random_sine_frequency()) end)
            spots = generate_random_spots(numSpots)

        -- 51 - 60: Random spots moving in a straight line but bounce on edges
        elseif levelType <= 60 then
            generate_templates(templates, function(c) return new_template(c, MT_LINE, true, random_speed(), random_angle) end)
            spots = generate_random_spots(numSpots)

        -- 61 - 70: Random spots moving in a sine wave but bounce on edges
        elseif levelType <= 70 then
            generate_templates(templates, function (c) return new_template(c, MT_SIN, true, random_speed(), random_angle, random_sine_amplitude(), random_sine_frequency()) end)
            spots = generate_random_spots(numSpots)

        -- 71 - 80: Random spots moving in a straight line but velocity and angle are random per spot
        elseif levelType <= 80 then
            generate_templates(templates, function (c) return new_template(c, MT_LINE, false, random_speed, random_angle) end)
            spots = generate_random_spots(numSpots)

        -- 81 - 90: Random spots moving in a sine wave but velocity and angle are random per spot
        elseif levelType <= 90 then
            generate_templates(templates, function (c) return new_template(c, MT_SIN, false, random_speed, random_angle, random_sine_amplitude(), random_sine_frequency()) end)
            spots = generate_random_spots(numSpots)

        -- 91 - 95: Random spots moving in a straight line but bounce on edges and velocity and angle are random per spot
        elseif levelType <= 95 then
            generate_templates(templates, function(c) return new_template(c, MT_LINE, true, random_speed, random_angle) end)
            spots = generate_random_spots(numSpots)

        -- 96 - 99: Random spots moving in a sine wave but bounce on edges and velocity and angle are random per spot
        elseif levelType <= 99 then
            generate_templates(templates, function (c) return new_template(c, MT_SIN, true, random_speed, random_angle, random_sine_amplitude(), random_sine_frequency()) end)
            spots = generate_random_spots(numSpots)

        -- 100: Chaos
        else
            generate_templates(templates, function (c) return new_template(c, MT_SIN, true, random_speed, random_angle, random_sine_amplitude, random_sine_frequency) end)
            spots = generate_random_spots(numSpots)
        end
    end
    return generate_layout(level, target, spots, templates)
end

function update_level(layout, t)
    for _, v in ipairs(layout) do
        v.a = (math_floor(v.a) + 0x10000) & 0xFFFF

        -- Update pos
        if v.mt == MT_LINE then
            v.x = v.x + (v.v * coss(v.a))
            v.y = v.y + (v.v * sins(v.a))
        elseif v.mt == MT_SIN then
            dv = { x = v.v, y = v.sa * (sins(t * v.sf) - sins((t - 1) * v.sf)) }
            v.x = v.x + (dv.x * coss(v.a) - dv.y * sins(v.a))
            v.y = v.y + (dv.x * sins(v.a) + dv.y * coss(v.a))
        end

        -- Bounce or wrap
        if v.b then
            if v.x < 0   then v.x, v.a = 1,   0x8000 - v.a end
            if v.x > 320 then v.x, v.a = 319, 0x8000 - v.a end
            if v.y < 0   then v.y, v.a = 1,   0x0000 - v.a end
            if v.y > 240 then v.y, v.a = 239, 0x0000 - v.a end
        else
            if v.x < -15 then v.x = 335 end
            if v.x > 335 then v.x = -15 end
            if v.y < -15 then v.y = 255 end
            if v.y > 255 then v.y = -15 end
        end
    end
end
