#!/usr/bin/env bash

function builder {

BASEROM_FILENAME="baserom.us.z64"
OMM_PATCH_FILENAME="omm.patch"
OMM_PATCH_URL="https://raw.githubusercontent.com/PeachyPeachSM64/sm64ex-omm/refs/heads/patch/omm.patch"

RESOURCES_PATH=".resources"
RESOURCES_TEXTURES_PATH="$RESOURCES_PATH/textures"
RESOURCES_MODELS_PATH="$RESOURCES_PATH/models"
RESOURCES_LEVELS_PATH="$RESOURCES_PATH/levels"
RESOURCES_MOONSHINE_PATH="$RESOURCES_PATH/moonshine"
RESOURCES_OMM_PATCH_PATH="$RESOURCES_PATH/$OMM_PATCH_FILENAME"

REPOS_PATH="repos"

#
# Utils
#

function exists {
    command -v "$1" >/dev/null 2>&1
}

function exit_on_failure {
    if ! $@; then
        exit 1
    fi
}

function exit_error {
    printf "\n\033[31mERROR: $1\033[0m\n"
    printf "\033[33mPress [ENTER] to quit...\033[0m"
    read enter
    exit 1
}

function print_header {
    clear
    printf "\033[1m\033[33m                                   _                  \n"
    printf "\033[1m\033[33m  ____ __    ___    __  _____     |_|_    _           \n"
    printf "\033[1m\033[33m / __ \| \  / | \  / |  | __ \_  _ _| | _| | ___  _ __\n"
    printf "\033[1m\033[33m/ /  \ \  \/  |  \/  |  | |/ / || | | |/   |/ _ \| '_/\n"
    printf "\033[1m\033[33m\ \__/ / \  / | \  / |  | |) \ \/ | | | (] |  __/| |  \n"
    printf "\033[1m\033[33m \____/|_|\/|_|_|\/|_|  |____/\__/|_|_|\___|\___/|_|  \n"
    printf "\033[1m\033[0m\n"
}

function highlight_selection {
    [ "$1" == "$2" ] && printf "\033[7m" || printf "\033[96m"
}

function print_selection {
    local s="$1"; shift
    local q="$1"; shift
    local d="$1"; shift
    local n="$#"
    if ! [ -z "$game_name" ]; then
        printf "\033[1mGame: $game_name\033[0m\n"
        if ! [ -z "$rapi_name" ]; then
            printf "\033[1mRAPI: $rapi_name\033[0m\n"
            if ! [ -z "$speed_name" ]; then
                printf "\033[1mSpeed: $speed_name\033[0m\n"
                if ! [ -z "$install_textures" ]; then
                    printf "\033[1mTextures: $install_textures\033[0m\n"
                    if ! [ -z "$install_models" ]; then
                        printf "\033[1mModels: $install_models\033[0m\n"
                        if ! [ -z "$install_levels" ]; then
                            printf "\033[1mLevels: $install_levels\033[0m\n"
                        fi
                    fi
                fi
            fi
        fi
        printf "\n"
    fi
    printf "\033[94m$q\033[0m\n"
    printf "\033[94mUse arrow keys or digits (1-$n) to select, then press enter to confirm.\033[0m\n"
    printf "\n"
    if [ "$d" != "." ]; then
        printf "$d\n"
        printf "\n"
    fi
    local i="1"
    for choice in "$@"; do
        printf "\033[96m%s  %-40s  \033[0m\n" $(highlight_selection "$s" "$i") "$choice"
        i=$(( $i + 1 ))
    done
    printf "\n"
}

function update_selection {
    local v="$1"
    local n="$2"
    local c="${!v}"
    while true; do
        read -rsn 1 key
        case $key in
            A) c=$(( (($c + $n - 2) % $n) + 1 )); break ;;
            B) c=$(( (($c         ) % $n) + 1 )); break ;;
            1) c="1"; break ;;
            2) c="2"; break ;;
            3) c="3"; break ;;
            4) c="4"; break ;;
            5) c="5"; break ;;
            6) c="6"; break ;;
            7) c="7"; break ;;
            8) c="8"; break ;;
            9) c="9"; break ;;
            "") return 0 ;;
        esac
    done
    if [ $c -le $n ]; then
        eval $v="$c"
    fi
    return 1
}

function do_select {
    local v="$1"; shift
    local q="$1"; shift
    local d="$1"; shift
    local n="$#"
    while true; do
        print_header
        print_selection "${!v}" "$q" "$d" "$@"
        if update_selection $v $n; then
            break
        fi
    done
}

#
# Check dependencies
#

for dep in git curl arepack make zip 7z python python3 gcc; do
    if ! exists $dep; then
        print_header
        printf "Installing dependencies...\n"

        if ! [ -f /etc/os-release ]; then
            exit_error "Could not identify operating system."
        fi

        . /etc/os-release
        case $ID in
            msys2)
                exit_on_failure pacman -Syu --noconfirm
                exit_on_failure pacman -S --noconfirm atool make git zip unzip p7zip python mingw-w64-i686-gcc mingw-w64-x86_64-gcc mingw-w64-i686-glew mingw-w64-x86_64-glew mingw-w64-i686-SDL mingw-w64-x86_64-SDL mingw-w64-i686-SDL2 mingw-w64-x86_64-SDL2
                ;;

            ubuntu)
                exit_on_failure sudo apt-get update -y
                exit_on_failure sudo apt install -y build-essential atool curl git python3 libglew-dev libsdl2-dev libz-dev zip p7zip*
                ;;

            debian)
                exit_on_failure apt-get update -y
                exit_on_failure apt install -y build-essential bsdmainutils atool curl git python3 libglew-dev libsdl2-dev libz-dev zip p7zip*
                ;;

            fedora)
                exit_on_failure dnf install --assumeyes util-linux atool curl git-all make gcc gcc-c++ python glew-devel SDL2-devel zlib-devel zip unzip p7zip p7zip-plugins
                ;;

            arch)
                exit_on_failure pacman -Syu --noconfirm
                exit_on_failure pacman -S --noconfirm base-devel atool curl git python sdl2 glew zip unzip p7zip
                ;;

            *) exit_error "Unsupported operating system: $ID" ;;
        esac
        break
    fi
done

#
# Check baserom
#

if ! [ -f "$BASEROM_FILENAME" ]; then
    print_header
    printf "A valid Super Mario 64 US ROM is needed to build the game.\n"
    printf "Enter the location of the file '$BASEROM_FILENAME' or drag and drop it here: \033[90m\n"
    read baserom
    printf "\033[0m\n"
    if [ -f "$baserom" ] && [ "${baserom##*.}" = "z64" ]; then
        cp -f "$baserom" "$BASEROM_FILENAME"
    else
        exit_error "The provided location is not a valid .z64 file."
    fi
fi

#
# Game
#

if [ -z "$1" ]; then
    game="1"
    do_select game \
        "Which game should be built?" \
        "Each game is unique and uses its own save file.

\033[1mSuper Mario 64\033[0m: The original game, levels and musics.
\033[1mSuper Mario 64 Moonshine\033[0m: Developed by TurnFlashed, S4ys and Fito, features 10 new worlds for a total of 50 Moons.
\033[1mSuper Mario 74 + Extreme Edition\033[0m: Lugmillord's ROM-hack. Has both Normal and Extreme Editions, packing more than 300 stars.
\033[1mSuper Mario Star Road\033[0m: Skelux's ROM-hack. Features 120 main stars and 10 extra stars.
\033[1mSuper Mario 64: The Green Stars\033[0m: Kampel125's ROM-hack. Contains 131 unique stars.
\033[1mRender96\033[0m: Super Mario 64 with the look of '96 renders, a new audio system and playable Luigi and Wario." \
        "Super Mario 64" \
        "Super Mario 64 Moonshine" \
        "Super Mario 74 + Extreme Edition" \
        "Super Mario Star Road" \
        "Super Mario 64: The Green Stars" \
        "Render96"
else
    game="$1"
fi

case $game in
    1) game="smex"; game_name="Super Mario 64" ;;
    2) game="smms"; game_name="Super Mario 64 Moonshine" ;;
    3) game="sm74"; game_name="Super Mario 74 + Extreme Edition" ;;
    4) game="smsr"; game_name="Super Mario Star Road" ;;
    5) game="smgs"; game_name="Super Mario 64: The Green Stars" ;;
    6) game="r96x"; game_name="Render96" ;;
    *) exit_error "Invalid game choice: $game" ;;
esac

#
# Render API
#

if [ -z "$2" ]; then
    rapi="1"
    do_select rapi \
        "Which render API should be used?" \
        "OpenGL 2.1 is better tested and has more features.\nUse DirectX 11 only if you notice graphical glitches or slowdowns." \
        "OpenGL 2.1 (recommended)" \
        "DirectX 11"
else
    rapi="$2"
fi

case $rapi in
    1) rapi="gl"; rapi_name="OpenGL 2.1" ;;
    2) rapi="dx"; rapi_name="DirectX 11" ;;
    *) exit_error "Invalid render API choice: $rapi" ;;
esac

#
# Building speed
#

if [ -z "$3" ]; then
    speed="2"
    do_select speed \
        "Which building speed should be used?" \
        "Affects building process duration. The faster, the more power-consuming." \
        "Slow" \
        "Fast" \
        "Faster" \
        "Fastest"
else
    speed="$3"
fi

case $speed in
    1) speed=""; speed_name="Slow" ;;
    2) speed="-j4"; speed_name="Fast" ;;
    3) speed="-j8"; speed_name="Faster" ;;
    4) speed="-j"; speed_name="Fastest" ;;
    *) exit_error "Invalid building speed choice: $speed" ;;
esac

#
# Texture packs
#

if [ -z "$4" ]; then
    textures="1"
    do_select textures \
        "Install texture packs?" \
        "Texture packs enhance the game visually, but can consume more power and memory." \
        "Yes" \
        "No"
else
    textures="$4"
fi

case $textures in
    1) install_textures="Yes" ;;
    2) install_textures="No" ;;
    *) exit_error "Invalid textures choice: $textures" ;;
esac

#
# Model packs
#

if [ -z "$5" ]; then
    models="1"
    do_select models \
        "Install model packs?" \
        "Model packs enhance the game visually, but can consume more power and memory.\nModel packs can be turned on/off in-game." \
        "Yes" \
        "No"
else
    models="$5"
fi

case $models in
    1) install_models="Yes" ;;
    2) install_models="No" ;;
    *) exit_error "Invalid models choice: $models" ;;
esac

#
# Render96 Levels
#

if [ "$game" == "smex" ] || [ "$game" == "r96x" ]; then
    if [ -z "$6" ]; then
        levels="2"
        do_select levels \
            "Install Render96 levels?" \
            "Render96 levels greatly enhance the game visually, but consume significantly more power and memory.\nIt is not recommended to install them on low-end computers." \
            "Yes" \
            "No"
    else
        levels="$6"
    fi
else
    levels="2"
fi

case $levels in
    1) install_levels="Yes" ;;
    2) install_levels="No" ;;
    *) exit_error "Invalid levels choice: $levels" ;;
esac

#
# Confirm
#

confirm="1"
if [ -z "$6" ]; then
    do_select confirm \
        "Is everything OK?" \
        "." \
        "Yes" \
        "No"
fi

if [ "$confirm" == "2" ]; then
    clear
    exit 0
fi

#
# Download resources
#

function check_model_pack {
    local url="$1"
    local filepath="${url##*/}"
    local filename="${filepath%.*}"
    local extension="${filepath##*.}"
    mkdir -p "$RESOURCES_MODELS_PATH"
    if ! [ -f "$RESOURCES_MODELS_PATH/$filename.zip" ]; then
        printf "\nDownloading $filename from: $url\n\n"
        exit_on_failure curl -L -o "$RESOURCES_MODELS_PATH/$filepath" "$url"
    fi
    if ! [ "$extension" == "zip" ] && [ -f "$RESOURCES_MODELS_PATH/$filepath" ]; then
        exit_on_failure arepack -e -f -F zip "$RESOURCES_MODELS_PATH/$filepath"
        rm -f "$RESOURCES_MODELS_PATH/$filepath"
    fi
}

function check_texture_pack {
    local repository="$1"
    local branch="$2"
    local filename="$3"
    mkdir -p "$RESOURCES_TEXTURES_PATH"
    if ! [ -f "$RESOURCES_TEXTURES_PATH/$filename.zip" ]; then
        if ! [ -d "$RESOURCES_TEXTURES_PATH/$filename" ]; then
            printf "\nDownloading $filename from: $repository\n\n"
            exit_on_failure git clone --single-branch --depth 1 "$repository" -b "$branch" "$RESOURCES_TEXTURES_PATH/$filename"
        fi
        cd "$RESOURCES_TEXTURES_PATH/$filename"
        ls -a | grep -vE "^.$|^..$|^gfx$|^sound$" | xargs rm -rf
        exit_on_failure zip -r "$filename.zip" .
        cp "$filename.zip" ..
        cd -
        rm -rf "$RESOURCES_TEXTURES_PATH/$filename"
    fi
}

function check_levels {
    local repository="$1"
    local branch="$2"
    mkdir -p "$RESOURCES_PATH"
    if ! [ -d "$RESOURCES_LEVELS_PATH" ]; then
        printf "\nDownloading $branch from: $repository\n\n"
        exit_on_failure git clone --single-branch --depth 1 "$repository" -b "$branch" "$RESOURCES_LEVELS_PATH"
        rm -rf "$RESOURCES_LEVELS_PATH/.git" "$RESOURCES_LEVELS_PATH/README.md"
    fi
}

function check_moonshine {
    local repository="$1"
    local branch="$2"
    mkdir -p "$RESOURCES_PATH"
    if ! [ -d "$RESOURCES_MOONSHINE_PATH" ]; then
        printf "\nDownloading $branch from: $repository\n\n"
        exit_on_failure git clone --single-branch --depth 1 "$repository" -b "$branch" "$RESOURCES_MOONSHINE_PATH"
        rm -rf "$RESOURCES_MOONSHINE_PATH/.git" "$RESOURCES_MOONSHINE_PATH/README.md"
    fi
}

function check_omm_patch {
    mkdir -p "$RESOURCES_PATH"
    printf "\nDownloading OMM patch from: $OMM_PATCH_URL\n\n"
    exit_on_failure curl -L -o "$RESOURCES_OMM_PATCH_PATH" "$OMM_PATCH_URL"
}

print_header
printf "\033[94mChecking resources...\033[0m\n\n"
if [ "$install_models" == "Yes" ]; then
    check_model_pack "https://github.com/PeachyPeachSM64/sm64ex-omm-resources/raw/packs/Render96_Mario_(Color_Support).zip"
    check_model_pack "https://github.com/PeachyPeachSM64/sm64ex-omm-resources/raw/packs/Render96_Luigi_(Color_Support).zip"
    check_model_pack "https://github.com/PeachyPeachSM64/sm64ex-omm-resources/raw/packs/Render96_Wario_(Color_Support).zip"
    check_model_pack "https://github.com/Render96/ModelPack/releases/download/3.2/Render96_DynOs_v3.2.7z"
fi
if [ "$install_textures" == "Yes" ]; then
    check_texture_pack "https://github.com/PeachyPeachSM64/sm64ex-omm-resources.git" "omm-hd" "OMM_HD"
    check_texture_pack "https://github.com/pokeheadroom/RENDER96-HD-TEXTURE-PACK.git" "master" "Render96_HD"
    if [ "$game" == "sm74" ]; then
        check_texture_pack "https://github.com/aspieweeb759/Super-Mario-74-HD-Texture-Pack.git" "main" "hd.sm74"
    fi
    if [ "$game" == "smsr" ]; then
        check_texture_pack "https://github.com/aspieweeb759/Star-Road-HD.git" "main" "hd.smsr"
    fi
fi
if [ "$install_levels" == "Yes" ]; then
    check_levels "https://github.com/PeachyPeachSM64/sm64ex-omm-resources.git" "levels"
fi
if [ "$game" == "smms" ]; then
    check_moonshine "https://github.com/PeachyPeachSM64/sm64ex-omm-resources.git" "moonshine"
fi
check_omm_patch

#
# Build game
#

print_header
printf "\033[94mBuilding game: %s...\033[0m\n\n" "$game_name"
mkdir -p "$REPOS_PATH"
cd "$REPOS_PATH"

# Reset repository
if [ -d "$game" ]; then
    cd "$game"
    exit_on_failure git reset --hard
    exit_on_failure git clean -fdx
else
    case $game in
        smex) exit_on_failure git clone --single-branch --depth 1 https://github.com/sm64pc/sm64ex.git -b nightly "$game" ;;
        smms) exit_on_failure git clone --single-branch --depth 1 https://github.com/sm64pc/sm64ex.git -b nightly "$game" ;;
        sm74) exit_on_failure git clone --single-branch --depth 1 https://github.com/PeachyPeachSM64/sm64ex-omm-romhacks.git -b sm74 "$game" ;;
        smsr) exit_on_failure git clone --single-branch --depth 1 https://github.com/PeachyPeachSM64/sm64ex-omm-romhacks.git -b smsr "$game" ;;
        smgs) exit_on_failure git clone --single-branch --depth 1 https://github.com/PeachyPeachSM64/sm64ex-omm-romhacks.git -b smgs "$game" ;;
        r96x) exit_on_failure git clone --single-branch --depth 1 https://github.com/Render96/Render96ex.git -b tester "$game" ;;
    esac
    cd "$game"
fi

# Copy Render96 levels
if [ "$install_levels" == "Yes" ]; then
    for dir in ../../$RESOURCES_LEVELS_PATH/*; do
        if [ -d $dir ]; then
            cp -rf $dir/. .
        fi
    done
fi

# Copy Moonshine content and fix building issues
if [ "$game" == "smms" ]; then
    cp -rf ../../$RESOURCES_MOONSHINE_PATH/. .
    sed -i 's/Goombone/goombone/g' actors/common0.c
    sed -i 's/Goombone/goombone/g' actors/common0.h
    sed -i '1s|^|#include "game/object_helpers.h"\n|' src/game/texscroll.c
fi

# Copy and apply OMM patch
cp -f ../../$RESOURCES_OMM_PATCH_PATH .
git apply --reject $OMM_PATCH_FILENAME

# Run make
cp -f ../../$BASEROM_FILENAME .
chmod 755 extract_assets.py
case $rapi in
    gl) exit_on_failure make $speed RENDER_API=GL WINDOW_API=SDL2 AUDIO_API=SDL2 CONTROLLER_API=SDL2 GRUCODE=f3dex2e ;;
    dx) exit_on_failure make $speed RENDER_API=D3D11 WINDOW_API=DXGI AUDIO_API=SDL2 CONTROLLER_API=SDL2 GRUCODE=f3dex2e ;;
esac

# Done? Install textures and models
if [ -f "build/us_pc/sm64.$game.exe" ] || [ -f "build/us_pc/sm64.$game" ]; then
    if [ "$install_textures" == "Yes" ]; then
        for file in ../../$RESOURCES_TEXTURES_PATH/*.zip; do
            cp -f "$file" "build/us_pc/res"
        done
        if ! [ "$game" == "sm74" ]; then
            rm -f "build/us_pc/res/hd.sm74.zip"
        fi
        if ! [ "$game" == "smsr" ]; then
            rm -f "build/us_pc/res/hd.smsr.zip"
        fi
    fi
    if [ "$install_models" == "Yes" ]; then
        mkdir -p "build/us_pc/res/packs"
        for file in ../../$RESOURCES_MODELS_PATH/*.zip; do
            cp -f "$file" "build/us_pc/res/packs"
        done
    fi
    printf "\n\033[32mGame built successfully!\033[0m\n"
    printf "Game executable location: $(pwd)/$REPOS_PATH/$game/build/us_pc\n"
    if exists explorer; then
        cd "build/us_pc"
        explorer .
    fi
else
    exit_error "An error occurred. Aborting building process."
fi

}

builder "$@" 2>&1 | tee logs.txt
