_G.OmmApi.omm_register_game("Super Mario 74 (+EE)", function () return is_mod_active("Super Mario 74 (+EE)", nil) end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(1, 2, LEVEL_PSS, true, true, 0xFFFF00, 150)
_G.OmmApi.omm_register_game_data(2, 2, LEVEL_PSS, true, true, 0xFF0000, 150)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
