_G.OmmApi.omm_register_game("Lug's Delightful Dioramas", function () return is_mod_active("Lug's Delightful Dioramas", nil) end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 0, LEVEL_PSS, true, false, 0xFFFFFF, 250)
_G.OmmApi.omm_disable_feature(_G.OmmApi.OMM_FEATURE_TRUE_NON_STOP, true)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
