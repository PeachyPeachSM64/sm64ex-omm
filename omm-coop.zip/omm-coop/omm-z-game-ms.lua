_G.OmmApi.omm_register_game("Super Mario 64 Moonshine", function () return is_mod_active("Super Mario 64 Moonshine", "moonshine") end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 0, LEVEL_PSS, true, false, 0, 250)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
