_G.OmmApi.omm_register_game("King Boo's Revenge 2", function () return is_mod_active("King Boo's Revenge 2", "King Boo's Revenge 2") end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 2, LEVEL_TOTWC, true, false, 0x800080, 250)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
