--
--  -------------
--  -- OMM API --
--  -------------
--
--  This OMM API is intended for:
--  > Detecting if OMM is on, checking the active version of OMM
--  > Adding support for romhacks that are unsupported by default (many of OMM's main features are disabled by default if an unsupported romhack is enabled)
--  > Providing other mods access to OMM's internals
--
--  Most of OMM constants are exposed through the API, use them instead of raw values with: _G.OmmApi.CONSTANT_NAME
--    Mario actions             ACT_OMM_*                           OMM custom actions
--    Mario animations          MARIO_ANIM_OMM_*                    OMM custom animations
--    Camera dist modes         OMM_CAMERA_DIST_MODE_*              Last parameter of _G.OmmApi.omm_register_camera_init_preset
--    World update flags        OMM_WORLD_UPDATE_*                  2nd parameter of _G.OmmApi.omm_register_world_update
--    Settings and values       OMM_SETTING_*                       OMM settings names and values
--    Features                  OMM_FEATURE_*                       OMM features names
--
--  To understand how to register properly a rom-hack, take a look at the omm-z-game-*.lua files:
--    omm-z-game-0.lua          Super Mario 64                      True Non-Stop mode full support, OMM camera presets and fixes
--    omm-z-game-1.lua          Unregistered rom-hack               Fallback for unregistered rom-hacks
--    omm-z-game-gs.lua         Super Mario 64: The Green Stars     Disable stars in VCUTM, since it's not accessible
--    omm-z-game-kbr2.lua       King Boo's Revenge 2                Change the default course for the PSS slide star
--    omm-z-game-ldd.lua        Lug's Delightful Dioramas           Disable true Non-Stop mode to not break the "Story" mode
--    omm-z-game-ms.lua         Super Mario 64 Moonshine            No Mips star in this hack
--    omm-z-game-sm74.lua       Super Mario 74 + EE                 Register each area separately (to differenciate Normal/Extreme edition)
--    omm-z-game-smsr.lua       Super Mario Star Road               Register custom star behaviors, true Non-Stop mode support
--    omm-z-game-smtu.lua       Super Mario 64: The Underworld      Disable features that could break the original layout of this hack
--

local sOmmRegisteredGames = {}

_G.OmmEnabled = true
_G.OmmVersion = OMM_COOP_VERSION
_G.OmmGame = nil
_G.OmmApi = {

    -----------------------
    -- Register rom-hack --
    -----------------------

    omm_register_game = function(name, condition, callback)
        sOmmRegisteredGames[#sOmmRegisteredGames + 1] = { name = name, condition_f = condition, callback_f = callback, loaded = false }
    end,

    omm_register_game_data = function (areaIndex, numMips, slideLevelNum, levelStars, coloredStars, hudStarsColor, levelExitDistance)
        omm_register_game_data(areaIndex, numMips, slideLevelNum, levelStars, coloredStars, hudStarsColor, levelExitDistance)
    end,

    omm_register_level_stars = function (levelNum, starBits)
        omm_register_level_stars(levelNum, starBits)
    end,

    omm_register_star_behavior = function (bhvId, name, nameCaps, condition)
        omm_register_star_behavior(bhvId, name, nameCaps, condition)
    end,

    omm_register_camera_init_preset = function (level, area, pitch, yaw, cameraDistMode)
        omm_register_camera_init_preset(level, area, pitch, yaw, cameraDistMode)
    end,

    omm_register_camera_no_collision_box = function (level, area, xMin, xMax, yMin, yMax, zMin, zMax)
        omm_register_camera_no_collision_box(level, area, xMin, xMax, yMin, yMax, zMin, zMax)
    end,

    omm_register_warp_pipe = function (level, id, area, node, dest, x, y, z, pitch, yaw, roll, exit)
        omm_register_warp_pipe(level, id, area, node, dest, x, y, z, pitch, yaw, roll, exit)
    end,

    omm_register_world_update = function (course, worldUpdateFlags, update)
        omm_register_world_update(course, worldUpdateFlags, update)
    end,

    ------------------------
    -- Cappy interactions --
    ------------------------

    omm_allow_cappy_object_interaction = function (m, obj)
        return false
    end,

    omm_resolve_cappy_object_interaction = function (m, cappy, obj)
        return false
    end,

    omm_allow_cappy_mario_interaction = function (cappyPlayerIndex, cappySetting)
        return true
    end,

    omm_resolve_cappy_mario_interaction = function (cappyPlayerIndex, cappySetting)
    end,

    --------------
    -- Settings --
    --------------

    omm_get_setting = function (m, setting)
        return omm_data_get_settings(m)[setting]:get()
    end,

    omm_force_setting = function (setting, value)
        gOmmSettingForceValues[setting] = value
    end,

    omm_get_forced_setting = function (setting)
        return gOmmSettingForceValues[setting]
    end,

    --------------
    -- Features --
    --------------

    omm_disable_feature = function (feature, disable)
        gOmmDisableFeatures[feature] = disable
    end,

    omm_is_feature_disabled = function (feature)
        return gOmmDisableFeatures[feature]
    end,

    ---------------
    -- Constants --
    ---------------

    -- Stationary
    ["ACT_OMM_SPIN_GROUND"]                         = ACT_OMM_SPIN_GROUND,
    ["ACT_OMM_SPIN_POUND_LAND"]                     = ACT_OMM_SPIN_POUND_LAND,
    ["ACT_OMM_FIRST_PERSON"]                        = ACT_OMM_FIRST_PERSON,

    -- Moving
    ["ACT_OMM_ROLL"]                                = ACT_OMM_ROLL,
    ["ACT_OMM_CAPPY_THROW_GROUND"]                  = ACT_OMM_CAPPY_THROW_GROUND,

    -- Airborne
    ["ACT_OMM_GROUND_POUND_JUMP"]                   = ACT_OMM_GROUND_POUND_JUMP,
    ["ACT_OMM_WALL_SLIDE"]                          = ACT_OMM_WALL_SLIDE,
    ["ACT_OMM_ROLL_AIR"]                            = ACT_OMM_ROLL_AIR,
    ["ACT_OMM_SPIN_AIR"]                            = ACT_OMM_SPIN_AIR,
    ["ACT_OMM_SPIN_JUMP"]                           = ACT_OMM_SPIN_JUMP,
    ["ACT_OMM_SPIN_POUND"]                          = ACT_OMM_SPIN_POUND,
    ["ACT_OMM_MIDAIR_SPIN"]                         = ACT_OMM_MIDAIR_SPIN,
    ["ACT_OMM_RAINBOW_SPIN"]                        = ACT_OMM_RAINBOW_SPIN,
    ["ACT_OMM_FLYING"]                              = ACT_OMM_FLYING,
    ["ACT_OMM_CAPPY_THROW_AIRBORNE"]                = ACT_OMM_CAPPY_THROW_AIRBORNE,
    ["ACT_OMM_CAPPY_BOUNCE"]                        = ACT_OMM_CAPPY_BOUNCE,
    ["ACT_OMM_CAPPY_VAULT"]                         = ACT_OMM_CAPPY_VAULT,
    ["ACT_OMM_AIR_KNOCKBACK"]                       = ACT_OMM_AIR_KNOCKBACK,

    -- Submerged
    ["ACT_OMM_WATER_GROUND_POUND"]                  = ACT_OMM_WATER_GROUND_POUND,
    ["ACT_OMM_WATER_GROUND_POUND_LAND"]             = ACT_OMM_WATER_GROUND_POUND_LAND,
    ["ACT_OMM_WATER_GROUND_POUND_JUMP"]             = ACT_OMM_WATER_GROUND_POUND_JUMP,
    ["ACT_OMM_WATER_DASH"]                          = ACT_OMM_WATER_DASH,
    ["ACT_OMM_CAPPY_THROW_WATER"]                   = ACT_OMM_CAPPY_THROW_WATER,

    -- Cutscene
    ["ACT_OMM_STAR_DANCE"]                          = ACT_OMM_STAR_DANCE,
    ["ACT_OMM_DEATH_DEFAULT"]                       = ACT_OMM_DEATH_DEFAULT,
    ["ACT_OMM_DEATH_WATER"]                         = ACT_OMM_DEATH_WATER,
    ["ACT_OMM_DEATH_FALL"]                          = ACT_OMM_DEATH_FALL,
    ["ACT_OMM_DEATH_FROZEN"]                        = ACT_OMM_DEATH_FROZEN,
    ["ACT_OMM_DEATH_EATEN_BY_BUBBA"]                = ACT_OMM_DEATH_EATEN_BY_BUBBA,
    ["ACT_OMM_DEATH_QUICKSAND"]                     = ACT_OMM_DEATH_QUICKSAND,
    ["ACT_OMM_DEATH_SQUISHED"]                      = ACT_OMM_DEATH_SQUISHED,
    ["ACT_OMM_TRANSITION_WF_TOWER"]                 = ACT_OMM_TRANSITION_WF_TOWER,
    ["ACT_OMM_ENTER_WARP_PIPE"]                     = ACT_OMM_ENTER_WARP_PIPE,

    -- Metal
    ["ACT_OMM_METAL_WATER_IDLE"]                    = ACT_OMM_METAL_WATER_IDLE,
    ["ACT_OMM_METAL_WATER_WALKING"]                 = ACT_OMM_METAL_WATER_WALKING,
    ["ACT_OMM_METAL_WATER_START_CROUCHING"]         = ACT_OMM_METAL_WATER_START_CROUCHING,
    ["ACT_OMM_METAL_WATER_CROUCHING"]               = ACT_OMM_METAL_WATER_CROUCHING,
    ["ACT_OMM_METAL_WATER_STOP_CROUCHING"]          = ACT_OMM_METAL_WATER_STOP_CROUCHING,
    ["ACT_OMM_METAL_WATER_START_CRAWLING"]          = ACT_OMM_METAL_WATER_START_CRAWLING,
    ["ACT_OMM_METAL_WATER_CRAWLING"]                = ACT_OMM_METAL_WATER_CRAWLING,
    ["ACT_OMM_METAL_WATER_STOP_CRAWLING"]           = ACT_OMM_METAL_WATER_STOP_CRAWLING,
    ["ACT_OMM_METAL_WATER_JUMP"]                    = ACT_OMM_METAL_WATER_JUMP,
    ["ACT_OMM_METAL_WATER_JUMP_LAND"]               = ACT_OMM_METAL_WATER_JUMP_LAND,
    ["ACT_OMM_METAL_WATER_DOUBLE_JUMP"]             = ACT_OMM_METAL_WATER_DOUBLE_JUMP,
    ["ACT_OMM_METAL_WATER_DOUBLE_JUMP_LAND"]        = ACT_OMM_METAL_WATER_DOUBLE_JUMP_LAND,
    ["ACT_OMM_METAL_WATER_TRIPLE_JUMP"]             = ACT_OMM_METAL_WATER_TRIPLE_JUMP,
    ["ACT_OMM_METAL_WATER_TRIPLE_JUMP_LAND"]        = ACT_OMM_METAL_WATER_TRIPLE_JUMP_LAND,
    ["ACT_OMM_METAL_WATER_BACKFLIP"]                = ACT_OMM_METAL_WATER_BACKFLIP,
    ["ACT_OMM_METAL_WATER_BACKFLIP_LAND"]           = ACT_OMM_METAL_WATER_BACKFLIP_LAND,
    ["ACT_OMM_METAL_WATER_SIDE_FLIP"]               = ACT_OMM_METAL_WATER_SIDE_FLIP,
    ["ACT_OMM_METAL_WATER_SIDE_FLIP_LAND"]          = ACT_OMM_METAL_WATER_SIDE_FLIP_LAND,
    ["ACT_OMM_METAL_WATER_LONG_JUMP"]               = ACT_OMM_METAL_WATER_LONG_JUMP,
    ["ACT_OMM_METAL_WATER_LONG_JUMP_LAND"]          = ACT_OMM_METAL_WATER_LONG_JUMP_LAND,
    ["ACT_OMM_METAL_WATER_FREEFALL"]                = ACT_OMM_METAL_WATER_FREEFALL,
    ["ACT_OMM_METAL_WATER_FREEFALL_LAND"]           = ACT_OMM_METAL_WATER_FREEFALL_LAND,
    ["ACT_OMM_METAL_WATER_WALL_SLIDE"]              = ACT_OMM_METAL_WATER_WALL_SLIDE,
    ["ACT_OMM_METAL_WATER_WALL_KICK_AIR"]           = ACT_OMM_METAL_WATER_WALL_KICK_AIR,
    ["ACT_OMM_METAL_WATER_PUNCHING"]                = ACT_OMM_METAL_WATER_PUNCHING,
    ["ACT_OMM_METAL_WATER_JUMP_KICK"]               = ACT_OMM_METAL_WATER_JUMP_KICK,
    ["ACT_OMM_METAL_WATER_DIVE"]                    = ACT_OMM_METAL_WATER_DIVE,
    ["ACT_OMM_METAL_WATER_GROUND_POUND"]            = ACT_OMM_METAL_WATER_GROUND_POUND,
    ["ACT_OMM_METAL_WATER_GROUND_POUND_LAND"]       = ACT_OMM_METAL_WATER_GROUND_POUND_LAND,
    ["ACT_OMM_METAL_WATER_GROUND_POUND_LAND_STOP"]  = ACT_OMM_METAL_WATER_GROUND_POUND_LAND_STOP,
    ["ACT_OMM_METAL_WATER_GROUND_POUND_JUMP"]       = ACT_OMM_METAL_WATER_GROUND_POUND_JUMP,
    ["ACT_OMM_METAL_WATER_BACKWARD_GROUND_KB"]      = ACT_OMM_METAL_WATER_BACKWARD_GROUND_KB,
    ["ACT_OMM_METAL_WATER_BACKWARD_AIR_KB"]         = ACT_OMM_METAL_WATER_BACKWARD_AIR_KB,
    ["ACT_OMM_METAL_WATER_SPIN_GROUND"]             = ACT_OMM_METAL_WATER_SPIN_GROUND,
    ["ACT_OMM_METAL_WATER_SPIN_AIR"]                = ACT_OMM_METAL_WATER_SPIN_AIR,
    ["ACT_OMM_METAL_WATER_SPIN_JUMP"]               = ACT_OMM_METAL_WATER_SPIN_JUMP,
    ["ACT_OMM_METAL_WATER_SPIN_POUND"]              = ACT_OMM_METAL_WATER_SPIN_POUND,
    ["ACT_OMM_METAL_WATER_SPIN_POUND_LAND"]         = ACT_OMM_METAL_WATER_SPIN_POUND_LAND,
    ["ACT_OMM_METAL_WATER_CAPPY_THROW_GROUND"]      = ACT_OMM_METAL_WATER_CAPPY_THROW_GROUND,
    ["ACT_OMM_METAL_WATER_CAPPY_THROW_AIRBORNE"]    = ACT_OMM_METAL_WATER_CAPPY_THROW_AIRBORNE,
    ["ACT_OMM_METAL_WATER_CAPPY_BOUNCE"]            = ACT_OMM_METAL_WATER_CAPPY_BOUNCE,
    ["ACT_OMM_METAL_WATER_CAPPY_VAULT"]             = ACT_OMM_METAL_WATER_CAPPY_VAULT,

    -- Animations
    ["MARIO_ANIM_OMM_CAPPY_VAULT"]                  = 241,
    ["MARIO_ANIM_OMM_CAPPY_UP_THROW"]               = 242,
    ["MARIO_ANIM_OMM_CAPPY_DOWN_THROW"]             = 243,
    ["MARIO_ANIM_OMM_CAPPY_SPIN_THROW"]             = 244,
    ["MARIO_ANIM_OMM_CAPPY_THROW"]                  = 245,
    ["MARIO_ANIM_OMM_CAPPY_RAINBOW_SPIN"]           = 246,
    ["MARIO_ANIM_OMM_DROWN"]                        = 247,
    ["MARIO_ANIM_OMM_DEATH"]                        = 248,
    ["MARIO_ANIM_OMM_FREEZE"]                       = 249,
    ["MARIO_ANIM_OMM_STARDANCE"]                    = 250,

    -- Camera
    ["OMM_CAMERA_DIST_MODE_LOWEST"]                 = 1,
    ["OMM_CAMERA_DIST_MODE_LOW"]                    = 2,
    ["OMM_CAMERA_DIST_MODE_MEDIUM"]                 = 3,
    ["OMM_CAMERA_DIST_MODE_HIGH"]                   = 4,
    ["OMM_CAMERA_DIST_MODE_HIGHER"]                 = 5,
    ["OMM_CAMERA_DIST_MODE_HIGHEST"]                = 6,

    -- World updates
    ["OMM_WORLD_UPDATE_STARS_CLASSIC"]              = 1,
    ["OMM_WORLD_UPDATE_STARS_ODYSSEY"]              = 2,
    ["OMM_WORLD_UPDATE_STARS_NON_STOP"]             = 4,
    ["OMM_WORLD_UPDATE_NOT_CLASSIC"]                = 6,
    ["OMM_WORLD_UPDATE_ALWAYS"]                     = 7,

    -- Settings
    ["OMM_SETTING_MOVESET"]                         = "moveset",
    ["OMM_SETTING_CAPPY"]                           = "cappy",
    ["OMM_SETTING_PLAYER"]                          = "player",
    ["OMM_SETTING_DAMAGE"]                          = "damage",
    ["OMM_SETTING_STARS"]                           = "stars",
    ["OMM_SETTING_POWER_UPS"]                       = "powerups",
    ["OMM_SETTING_BUBBLE"]                          = "bubble",
    ["OMM_SETTING_ANIMS"]                           = "anims",
    ["OMM_SETTING_HUD"]                             = "hud",
    ["OMM_SETTING_COLORED_STARS"]                   = "color",
    ["OMM_SETTING_CAMERA"]                          = "cam",

    -- Settings values
    ["OMM_SETTING_MOVESET_CLASSIC"]                 = 0,
    ["OMM_SETTING_MOVESET_ODYSSEY"]                 = 1,
    ["OMM_SETTING_CAPPY_NONE"]                      = 0,
    ["OMM_SETTING_CAPPY_PLAYER"]                    = 1,
    ["OMM_SETTING_CAPPY_BOUNCE"]                    = 2,
    ["OMM_SETTING_CAPPY_DAMAGE"]                    = 3,
    ["OMM_SETTING_PLAYER_NONE"]                     = 0,
    ["OMM_SETTING_PLAYER_SOLID"]                    = 1,
    ["OMM_SETTING_PLAYER_PVP"]                      = 2,
    ["OMM_SETTING_DAMAGE_WEAK"]                     = 10,
    ["OMM_SETTING_DAMAGE_MEDIUM"]                   = 25,
    ["OMM_SETTING_DAMAGE_HIGH"]                     = 60,
    ["OMM_SETTING_STARS_CLASSIC"]                   = 0,
    ["OMM_SETTING_STARS_ODYSSEY"]                   = 1,
    ["OMM_SETTING_STARS_NON_STOP"]                  = 2,
    ["OMM_SETTING_POWER_UPS_CLASSIC"]               = 0,
    ["OMM_SETTING_POWER_UPS_IMPROVED"]              = 1,
    ["OMM_SETTING_BUBBLE_ON"]                       = 1,
    ["OMM_SETTING_BUBBLE_OFF"]                      = 0,
    ["OMM_SETTING_ANIMS_ON"]                        = 1,
    ["OMM_SETTING_ANIMS_OFF"]                       = 0,
    ["OMM_SETTING_HUD_CLASSIC"]                     = 0,
    ["OMM_SETTING_HUD_ODYSSEY"]                     = 1,
    ["OMM_SETTING_HUD_VANISHING"]                   = 2,
    ["OMM_SETTING_HUD_NONE"]                        = 3,
    ["OMM_SETTING_COLORED_STARS_ON"]                = 1,
    ["OMM_SETTING_COLORED_STARS_OFF"]               = 0,
    ["OMM_SETTING_CAMERA_ON"]                       = 1,
    ["OMM_SETTING_CAMERA_OFF"]                      = 0,

    -- Features
    ["OMM_FEATURE_ODYSSEY_DEATH"]                   = "odysseyDeath",
    ["OMM_FEATURE_LOST_COINS"]                      = "lostCoins",
    ["OMM_FEATURE_SPIN_SHORTCUT"]                   = "spinShortcut",
    ["OMM_FEATURE_TRUE_NON_STOP"]                   = "trueNonStop",
    ["OMM_FEATURE_STARS_DISPLAY"]                   = "starsDisplay",

    ---------------
    -- Functions --
    ---------------

    omm_camera_is_available           = omm_camera_is_available,
    omm_camera_get_intended_yaw       = omm_camera_get_intended_yaw, ---@param m MarioState
    omm_camera_get_mode               = omm_camera_get_mode,
    omm_camera_get_relative_dist_mode = omm_camera_get_relative_dist_mode,
    omm_camera_init                   = omm_camera_init,
}

hook_event(0, function ()
    for _, game in ipairs(sOmmRegisteredGames) do
        if not game.loaded and game.condition_f() then
            omm_clear_game_data()
            omm_clear_level_stars()
            omm_clear_star_behaviors()
            omm_clear_camera_init_presets()
            omm_clear_camera_no_collision_boxes()
            omm_clear_warp_pipes()
            omm_clear_world_updates()
            game.callback_f()
            game.loaded = true
            _G.OmmGame = game.name
        end
    end
end)
