_G.OmmApi.omm_register_game("Super Mario 64", function () return true end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 2, LEVEL_PSS, true, true, 0xFFFF00, 500)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

_G.OmmApi.omm_register_camera_init_preset(LEVEL_BITDW,            1, 0x1000, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_BITFS,            1, 0x1000, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_BITS,             1, 0x1000, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_WF,               1, 0x0C00, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_MEDIUM)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_CCM,              1, 0x0C00, 0x8000, _G.OmmApi.OMM_CAMERA_DIST_MODE_MEDIUM)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_BBH,              1, 0x0C00, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_SSL,              2, 0x0C00, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_MEDIUM)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_WDW,              1, 0x0C00, 0x2000, _G.OmmApi.OMM_CAMERA_DIST_MODE_MEDIUM)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_TTM,              1, 0x0C00, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_RR,               1, 0x0C00, 0xE000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_VCUTM,            1, 0x0C00, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_HIGH)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_CASTLE_COURTYARD, 1, 0x0C00, 0x8000, _G.OmmApi.OMM_CAMERA_DIST_MODE_MEDIUM)
_G.OmmApi.omm_register_camera_init_preset(LEVEL_CASTLE_GROUNDS,   1, 0x0C00, 0x0000, _G.OmmApi.OMM_CAMERA_DIST_MODE_MEDIUM)

-------------------------
-- Camera no-col boxes --
-------------------------

_G.OmmApi.omm_register_camera_no_collision_box(LEVEL_WDW,   1,  450, 1400,   100, 3600, -2350, -1100)
_G.OmmApi.omm_register_camera_no_collision_box(LEVEL_BITFS, 1, 2950, 4550, -1450, -600,  -350,   950)
_G.OmmApi.omm_register_camera_no_collision_box(LEVEL_BITFS, 1, 2500, 3200, -1250,  450, -1200,  1200)

----------------
-- Warp pipes --
----------------

_G.OmmApi.omm_register_warp_pipe(LEVEL_JRB, 0x01, 1, 0x0A, 0x02,  4900,  1440,  2500, 0x0000, 0x0000, 0x0000, 0)
_G.OmmApi.omm_register_warp_pipe(LEVEL_JRB, 0x02, 2, 0x0A, 0x01,     0,  -351, -1100, 0x0000, 0x0000, 0x0000, 0)
_G.OmmApi.omm_register_warp_pipe(LEVEL_LLL, 0x01, 1, 0x0A, 0x02,  2040,   307,  3760, 0x0000, 0x8000, 0x0000, 1)
_G.OmmApi.omm_register_warp_pipe(LEVEL_LLL, 0x02, 2, 0x0A, 0x01, -1560,    90,   620, 0x0000, 0x0000, 0x0000, 0)
_G.OmmApi.omm_register_warp_pipe(LEVEL_SSL, 0x01, 1, 0x0A, 0x02, -2040,   256,   714, 0x0000, 0x0000, 0x0000, 1)
_G.OmmApi.omm_register_warp_pipe(LEVEL_SSL, 0x02, 2, 0x0A, 0x01,     0,     0,  2880, 0x0000, 0x0000, 0x0000, 0)
_G.OmmApi.omm_register_warp_pipe(LEVEL_DDD, 0x01, 2, 0x00, 0x02,  6160,   110,  4430, 0x0000, 0xA000, 0x0000, 1)
_G.OmmApi.omm_register_warp_pipe(LEVEL_DDD, 0x02, 2, 0x00, 0x01,  2030, -4088, -2780, 0x0000, 0x0000, 0x0000, 0)
_G.OmmApi.omm_register_warp_pipe(LEVEL_WDW, 0x01, 1, 0x0A, 0x02, -3450,  3584, -3450, 0x0000, 0x2000, 0x0000, 1)
_G.OmmApi.omm_register_warp_pipe(LEVEL_WDW, 0x02, 2, 0x0A, 0x01,  -767,  -332,  1792, 0x0000, 0x0000, 0x0000, 0)
_G.OmmApi.omm_register_warp_pipe(LEVEL_THI, 0x01, 1, 0x0A, 0x02,  2590,  3226, -2085, 0x0000, 0xC000, 0x0000, 1)
_G.OmmApi.omm_register_warp_pipe(LEVEL_THI, 0x02, 3, 0x0A, 0x01,     0,  2560,     0, 0x0000, 0x0000, 0x0000, 0)

-------------------
-- Non-Stop mode --
-------------------

local np0 = gNetworkPlayers[0]

gGlobalSyncTable.sunken = true
local prevLevel = np0.currLevelNum
hook_event(HOOK_ON_LEVEL_INIT, function()
    if np0.currLevelNum ~= prevLevel then
        if prevLevel == LEVEL_JRB then
            for i = 0, MAX_PLAYERS - 1 do
                local np = gNetworkPlayers[i]
                if np.connected and np.currLevelNum == LEVEL_JRB then
                    prevLevel = np0.currLevelNum
                    return
                end
            end
            gGlobalSyncTable.sunken = true
        end
        prevLevel = np0.currLevelNum
    end
end)

-- Bob-omb Battlefield
--- Remove one bowling ball spawner
--- Hide water bomb cannons
--- Hide bob-omb buddies post King Bob-omb
_G.OmmApi.omm_register_world_update(COURSE_BOB, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    omm_world_behavior_set_dormant(id_bhvTtmBowlingBallSpawner, true)
    omm_world_behavior_set_dormant(id_bhvWaterBombCannon, true)
    omm_world_behavior_set_dormant_params(id_bhvBobombBuddy, 0x00020000, true)
    omm_world_behavior_set_dormant_params(id_bhvBobombBuddy, 0x00030000, true)
end)

-- Whomp's Fortress
--- Hide all objects related to the tower until Whomp King is defeated
--- Hide the 6th star until the right wall is broken
_G.OmmApi.omm_register_world_update(COURSE_WF, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    local wkb = (obj_get_first_with_behavior_id(id_bhvWhompKingBoss) ~= nil)
    local bwr = (obj_get_first_with_behavior_id(id_bhvWfBreakableWallRight) ~= nil)
    omm_world_behavior_set_dormant(id_bhvKickableBoard, wkb)
    omm_world_behavior_set_dormant(id_bhv1Up, wkb)
    omm_world_behavior_set_dormant(id_bhvBulletBill, wkb)
    omm_world_behavior_set_dormant(id_bhvTower, wkb)
    omm_world_behavior_set_dormant(id_bhvBulletBillCannon, wkb)
    omm_world_behavior_set_dormant(id_bhvTowerPlatformGroup, wkb)
    omm_world_behavior_set_dormant(id_bhvTowerDoor, wkb)
    omm_world_behavior_set_dormant(id_bhvWfSolidTowerPlatform, wkb)
    omm_world_behavior_set_dormant(id_bhvWfSlidingTowerPlatform, wkb)
    omm_world_behavior_set_dormant(id_bhvWfElevatorTowerPlatform, wkb)
    omm_world_behavior_set_dormant_params(id_bhvStar, 0x01000000, wkb)
    omm_world_behavior_set_dormant_params(id_bhvStar, 0x05000000, bwr)
end)

-- Jolly Roger Bay
--- Hide some specific parts of the ship, depending on its state
--- Keep only the Unagi with a star
--- Update the whirlpools
_G.OmmApi.omm_register_world_update(COURSE_JRB, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    if np0.currAreaIndex ~= 1 then
        if gGlobalSyncTable.sunken then
            if get_environment_region(1) == -335 then
                gGlobalSyncTable.sunken = false
            end
        else
            set_environment_region(1, -335)
        end
    end
    omm_world_behavior_set_dormant_params(id_bhvUnagi, 0x00000000, true)
    omm_world_behavior_set_dormant_params(id_bhvUnagi, 0x02020000, true)
    omm_world_behavior_set_dormant(id_bhvInSunkenShip, not gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvSunkenShipPart, not gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvSunkenShipPart2, not gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvInSunkenShip, not gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvInSunkenShip2, not gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvShipPart3, gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvInSunkenShip3, gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvJrbSlidingBox, gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvJetStream, gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant(id_bhvOmmWarpPipe, gGlobalSyncTable.sunken)
    omm_world_behavior_set_dormant_params(id_bhvStar, 0x05000000, gGlobalSyncTable.sunken)
    local jetstream = obj_get_first_with_behavior_id(id_bhvJetStream)
    if jetstream ~= nil and not obj_is_dormant(jetstream) then
        set_whirlpools(jetstream.oPosX, jetstream.oPosY, jetstream.oPosZ, -30, np0.currAreaIndex, 0)
    end
end)

_G.OmmApi.omm_register_world_update(COURSE_JRB, _G.OmmApi.OMM_WORLD_UPDATE_STARS_CLASSIC, function ()
    omm_world_behavior_set_dormant(id_bhvOmmWarpPipe, true)
end)

-- Big Boo's Haunt
--- Hide the main room stairs
--- Hide the regular Boos (replaced by Ghost Hunt Boos)
_G.OmmApi.omm_register_world_update(COURSE_BBH, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    omm_world_behavior_set_dormant(id_bhvHiddenStaircaseStep, true)
    omm_world_behavior_set_dormant(id_bhvBoo, true)
end)

-- Shifting Sand Land
--- Hide the late stars tweesters
_G.OmmApi.omm_register_world_update(COURSE_SSL, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    omm_world_behavior_set_dormant_params(id_bhvTweester, 0x00190000, true)
end)

-- Tiny-Huge Island
--- Hide the warp pipe inside Wiggler's room until Wiggler is defeated
_G.OmmApi.omm_register_world_update(COURSE_THI, _G.OmmApi.OMM_WORLD_UPDATE_ALWAYS, function ()
    if np0.currAreaIndex == 3 then
        local wiggler = obj_get_first_with_behavior_id(id_bhvWigglerHead)
        omm_world_behavior_set_dormant(id_bhvOmmWarpPipe, (wiggler ~= nil and wiggler.oHealth > 1))
    end
end)

end)
