_G.OmmApi.omm_register_game("Star Road", function () return is_mod_active("Star Road", "star-road") end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 1, LEVEL_SA, true, true, 0xFFFF00, 500)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

_G.OmmApi.omm_register_star_behavior(bhvSMSRBigBully, nil, nil, function (bhvParams) return true end)
_G.OmmApi.omm_register_star_behavior(bhvSMSRBigChillBully, nil, nil, function (bhvParams) return true end)
_G.OmmApi.omm_register_star_behavior(bhvSMSRHiddenStar, nil, nil, function (bhvParams) return true end)
_G.OmmApi.omm_register_star_behavior(bhvSMSRStarMoving, nil, nil, function (bhvParams) return true end)
_G.OmmApi.omm_register_star_behavior(bhvSMSRStarReplica, "Star Replica", "STAR REPLICA", function (bhvParams) return true end)
_G.OmmApi.omm_register_star_behavior(bhvSMSRWigglerHead, nil, nil, function (bhvParams) return true end)

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

-- Bob-omb Islands
--- Hide bob-omb buddies post King Bob-omb
_G.OmmApi.omm_register_world_update(COURSE_BOB, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    omm_world_behavior_set_dormant_params(id_bhvBobombBuddy, 0x009E0000, true)
end)

-- Sky Land Resort
--- Hide bob-omb buddies post King Whomp
_G.OmmApi.omm_register_world_update(COURSE_WF, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function()
    omm_world_behavior_set_dormant_params(id_bhvBobombBuddy, 0x009F0000, true)
end)

-- Chuckya Harbor
--- Remove the stone block before the entrance of the underwater maze
--- Add two Vanish cap boxes to collect the 6th star
_G.OmmApi.omm_register_world_update(COURSE_CCM, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    local box = obj_get_first_with_behavior_id_and_field_f32(id_bhvPushableMetalBox, 0x06, 3968)
    if box and not obj_is_dormant(box) then
        spawn_object_abs_with_rot(E_MODEL_EXCLAMATION_BOX, id_bhvExclamationBox, 3800, 3800, -2900, 0, 0xC000, 0).oBehParams2ndByte = 0x02
        spawn_object_abs_with_rot(E_MODEL_EXCLAMATION_BOX, id_bhvExclamationBox, -4200, 1720, -4300, 0, 0xE93E, 0).oBehParams2ndByte = 0x02
        obj_set_dormant(box, true)
    end
end)

-- Gloomy Garden
--- Remove the inverted layer of wave platforms
_G.OmmApi.omm_register_world_update(COURSE_BBH, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    for_each_object_with_behavior(bhvSMSRRedWavePlatform, function(obj)
        obj_set_dormant(obj, (obj.oFaceAnglePitch & 0xFFFF) ~= 0)
    end)
end)

-- Colorful Coral Caverns
--- Remove the rocks that block the path to Star 4
_G.OmmApi.omm_register_world_update(COURSE_HMC, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    for_each_object_with_behavior(bhvSMSRBreakableFloor, function(obj)
        obj_set_dormant(obj, obj.oPosZ == 3275)
    end)
end)

-- Koopa Canyon
--- Remove the metal boxes blocking the entrance of the pyramid
_G.OmmApi.omm_register_world_update(COURSE_LLL, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    for_each_object_with_behavior(id_bhvPushableMetalBox, function(obj)
        obj_set_dormant(obj, (obj.oFaceAngleRoll & 0xFFFF) ~= 0)
    end)
end)

-- Large Leaf Forest
--- Hide mips post Wiggler
_G.OmmApi.omm_register_world_update(COURSE_SSL, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    omm_world_behavior_set_dormant_params(bhvSMSRMipsMessage, 0x008B0000, true)
end)

-- Colossal Candy Clutter
--- Hide the penguin at the end of the race
_G.OmmApi.omm_register_world_update(COURSE_WDW, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    omm_world_behavior_set_dormant(id_bhvSLWalkingPenguin, true)
end)

-- Bob-omb Battle Factory
--- Move the 6th star to another place
_G.OmmApi.omm_register_world_update(COURSE_TTC, _G.OmmApi.OMM_WORLD_UPDATE_NOT_CLASSIC, function ()
    local box = obj_get_first_with_behavior_id_and_field_s32(id_bhvExclamationBox, 0x40, 0x050E0000)
    if box and not obj_is_dormant(box) then
        obj_scale_xyz(spawn_object_abs_with_rot(E_MODEL_METAL_BOX, id_bhvPushableMetalBox, 4679, -1350, -6850, 0x200, 0, -0x300), 1.0, 1.5, 1.0)
        obj_scale_xyz(spawn_object_abs_with_rot(E_MODEL_METAL_BOX, id_bhvPushableMetalBox, 4679, -1150, -7200, -0x400, 0, 0x580), 1.0, 1.5, 1.0)
        spawn_object_abs_with_rot(E_MODEL_EXCLAMATION_BOX, id_bhvExclamationBox, 4679, -600, -7200, 0, 0, 0).oBehParams2ndByte = 0x0E
        obj_set_dormant(box, true)
    end
end)

end)
