_G.OmmApi.omm_register_game("Rom-hack", function () return is_romhack_active() end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 2, LEVEL_PSS, false, false, 0, 250)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

if bhvFlipswitch_Panel_StarSpawn_MOP then
    _G.OmmApi.omm_register_star_behavior(bhvFlipswitch_Panel_StarSpawn_MOP, "Flipswitch Panel", "FLIPSWITCH PANEL", function (bhvParams) return true end)
end

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
