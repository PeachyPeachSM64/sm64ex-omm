_G.OmmApi.omm_register_game("Super Mario 64: The Underworld", function () return is_mod_active("The Underworld", "underworld") end, function ()

gLevelValues.showStarNumber = 0

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 0, LEVEL_PSS, false, false, 0, 250)
_G.OmmApi.omm_force_setting_value(_G.OmmApi.OMM_SETTING_STARS, _G.OmmApi.OMM_SETTING_STARS_NON_STOP)
_G.OmmApi.omm_force_setting_value(_G.OmmApi.OMM_SETTING_HUD, _G.OmmApi.OMM_SETTING_HUD_NONE)
_G.OmmApi.omm_force_setting_value(_G.OmmApi.OMM_SETTING_COLORED_STARS, _G.OmmApi.OMM_SETTING_COLORED_STARS_OFF)
_G.OmmApi.omm_force_setting_value(_G.OmmApi.OMM_SETTING_CAMERA, _G.OmmApi.OMM_SETTING_CAMERA_OFF)
_G.OmmApi.omm_disable_feature(_G.OmmApi.OMM_FEATURE_ODYSSEY_DEATH, true)
_G.OmmApi.omm_disable_feature(_G.OmmApi.OMM_FEATURE_LOST_COINS, true)
_G.OmmApi.omm_disable_feature(_G.OmmApi.OMM_FEATURE_TRUE_NON_STOP, true)
_G.OmmApi.omm_disable_feature(_G.OmmApi.OMM_FEATURE_STARS_DISPLAY, true)

-----------------
-- Level stars --
-----------------

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
