_G.OmmApi.omm_register_game("Super Mario 64: The Green Stars", function () return is_mod_active("The Green Stars", "green-stars") end, function ()

---------------
-- Game data --
---------------

_G.OmmApi.omm_register_game_data(-1, 2, LEVEL_PSS, true, true, 0x00FF00, 250)

-----------------
-- Level stars --
-----------------

_G.OmmApi.omm_register_level_stars(LEVEL_VCUTM, 0x0000000)

--------------------
-- Star behaviors --
--------------------

--------------------
-- Camera presets --
--------------------

-------------------------
-- Camera no-col boxes --
-------------------------

----------------
-- Warp pipes --
----------------

-------------------
-- Non-Stop mode --
-------------------

end)
